--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: backups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backups (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.backups OWNER TO postgres;

--
-- Name: backups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.backups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backups_id_seq OWNER TO postgres;

--
-- Name: backups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.backups_id_seq OWNED BY public.backups.id;


--
-- Name: class_rooms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.class_rooms (
    id bigint NOT NULL,
    class_name character varying(255) NOT NULL,
    grade_id bigint NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.class_rooms OWNER TO postgres;

--
-- Name: class_rooms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.class_rooms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.class_rooms_id_seq OWNER TO postgres;

--
-- Name: class_rooms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.class_rooms_id_seq OWNED BY public.class_rooms.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.failed_jobs_id_seq OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: grades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grades (
    id bigint NOT NULL,
    "Grade_Name" character varying(255) NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.grades OWNER TO postgres;

--
-- Name: grades_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.grades_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.grades_id_seq OWNER TO postgres;

--
-- Name: grades_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.grades_id_seq OWNED BY public.grades.id;


--
-- Name: images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.images (
    id bigint NOT NULL,
    filename character varying(255) NOT NULL,
    imageable_id integer NOT NULL,
    imageable_type character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.images OWNER TO postgres;

--
-- Name: images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.images_id_seq OWNER TO postgres;

--
-- Name: images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.images_id_seq OWNED BY public.images.id;


--
-- Name: ltu_contributors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ltu_contributors (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    avatar character varying(255),
    role smallint,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.ltu_contributors OWNER TO postgres;

--
-- Name: ltu_contributors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ltu_contributors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ltu_contributors_id_seq OWNER TO postgres;

--
-- Name: ltu_contributors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ltu_contributors_id_seq OWNED BY public.ltu_contributors.id;


--
-- Name: ltu_invites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ltu_invites (
    id bigint NOT NULL,
    email character varying(255) NOT NULL,
    token character varying(32) NOT NULL,
    role smallint DEFAULT '2'::smallint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.ltu_invites OWNER TO postgres;

--
-- Name: ltu_invites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ltu_invites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ltu_invites_id_seq OWNER TO postgres;

--
-- Name: ltu_invites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ltu_invites_id_seq OWNED BY public.ltu_invites.id;


--
-- Name: ltu_languages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ltu_languages (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    rtl boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ltu_languages OWNER TO postgres;

--
-- Name: ltu_languages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ltu_languages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ltu_languages_id_seq OWNER TO postgres;

--
-- Name: ltu_languages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ltu_languages_id_seq OWNED BY public.ltu_languages.id;


--
-- Name: ltu_phrases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ltu_phrases (
    id bigint NOT NULL,
    uuid uuid NOT NULL,
    translation_id bigint NOT NULL,
    translation_file_id bigint NOT NULL,
    phrase_id bigint,
    key character varying(255) NOT NULL,
    "group" character varying(255) NOT NULL,
    value text,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    parameters json,
    note text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.ltu_phrases OWNER TO postgres;

--
-- Name: ltu_phrases_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ltu_phrases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ltu_phrases_id_seq OWNER TO postgres;

--
-- Name: ltu_phrases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ltu_phrases_id_seq OWNED BY public.ltu_phrases.id;


--
-- Name: ltu_translation_files; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ltu_translation_files (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    extension character varying(255) NOT NULL,
    is_root boolean DEFAULT false NOT NULL
);


ALTER TABLE public.ltu_translation_files OWNER TO postgres;

--
-- Name: ltu_translation_files_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ltu_translation_files_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ltu_translation_files_id_seq OWNER TO postgres;

--
-- Name: ltu_translation_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ltu_translation_files_id_seq OWNED BY public.ltu_translation_files.id;


--
-- Name: ltu_translations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ltu_translations (
    id bigint NOT NULL,
    language_id bigint NOT NULL,
    source boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.ltu_translations OWNER TO postgres;

--
-- Name: ltu_translations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ltu_translations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ltu_translations_id_seq OWNER TO postgres;

--
-- Name: ltu_translations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ltu_translations_id_seq OWNED BY public.ltu_translations.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: parents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parents (
    id bigint NOT NULL,
    "Father_Name" character varying(255),
    "Father_National_Id" character varying(255),
    "Father_Phone" character varying(255),
    "Father_Job" character varying(255),
    "Father_Birth_Date" date,
    "Father_Learning" character varying(255),
    "Mother_Name" character varying(255),
    "Mother_National_Id" character varying(255),
    "Mother_Phone" character varying(255),
    "Mother_Job" character varying(255),
    "Religion" character varying(255),
    "Address" character varying(255),
    "Mother_Birth_Date" date,
    user_id bigint NOT NULL,
    deleted_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.parents OWNER TO postgres;

--
-- Name: parents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.parents_id_seq OWNER TO postgres;

--
-- Name: parents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parents_id_seq OWNED BY public.parents.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO postgres;

--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.personal_access_tokens_id_seq OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: pulse_aggregates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pulse_aggregates (
    id bigint NOT NULL,
    bucket integer NOT NULL,
    period integer NOT NULL,
    type character varying(255) NOT NULL,
    key text NOT NULL,
    key_hash uuid GENERATED ALWAYS AS ((md5(key))::uuid) STORED NOT NULL,
    aggregate character varying(255) NOT NULL,
    value numeric(20,2) NOT NULL,
    count integer
);


ALTER TABLE public.pulse_aggregates OWNER TO postgres;

--
-- Name: pulse_aggregates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pulse_aggregates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pulse_aggregates_id_seq OWNER TO postgres;

--
-- Name: pulse_aggregates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pulse_aggregates_id_seq OWNED BY public.pulse_aggregates.id;


--
-- Name: pulse_entries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pulse_entries (
    id bigint NOT NULL,
    "timestamp" integer NOT NULL,
    type character varying(255) NOT NULL,
    key text NOT NULL,
    key_hash uuid GENERATED ALWAYS AS ((md5(key))::uuid) STORED NOT NULL,
    value bigint
);


ALTER TABLE public.pulse_entries OWNER TO postgres;

--
-- Name: pulse_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pulse_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pulse_entries_id_seq OWNER TO postgres;

--
-- Name: pulse_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pulse_entries_id_seq OWNED BY public.pulse_entries.id;


--
-- Name: pulse_values; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pulse_values (
    id bigint NOT NULL,
    "timestamp" integer NOT NULL,
    type character varying(255) NOT NULL,
    key text NOT NULL,
    key_hash uuid GENERATED ALWAYS AS ((md5(key))::uuid) STORED NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.pulse_values OWNER TO postgres;

--
-- Name: pulse_values_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pulse_values_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pulse_values_id_seq OWNER TO postgres;

--
-- Name: pulse_values_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pulse_values_id_seq OWNED BY public.pulse_values.id;


--
-- Name: school_fees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.school_fees (
    id bigint NOT NULL,
    grade_id bigint,
    classroom_id bigint,
    user_id bigint,
    description character varying(255) NOT NULL,
    amount numeric(8,2) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.school_fees OWNER TO postgres;

--
-- Name: school_fees_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.school_fees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.school_fees_id_seq OWNER TO postgres;

--
-- Name: school_fees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.school_fees_id_seq OWNED BY public.school_fees.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settings (
    id bigint NOT NULL,
    school_name character varying(255) NOT NULL,
    phone character varying(255) NOT NULL,
    address character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.settings OWNER TO postgres;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.settings_id_seq OWNER TO postgres;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: students; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.students (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    birth_date date NOT NULL,
    address character varying(255) NOT NULL,
    join_date date NOT NULL,
    gender character varying(255) NOT NULL,
    user_id bigint NOT NULL,
    grade_id bigint NOT NULL,
    classroom_id bigint NOT NULL,
    parent_id bigint,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT students_gender_check CHECK (((gender)::text = ANY ((ARRAY['male'::character varying, 'female'::character varying])::text[])))
);


ALTER TABLE public.students OWNER TO postgres;

--
-- Name: students_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.students_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.students_id_seq OWNER TO postgres;

--
-- Name: students_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.students_id_seq OWNED BY public.students.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    first_name character varying(255) NOT NULL,
    second_name character varying(255) NOT NULL,
    third_name character varying(255),
    forth_name character varying(255),
    phone character varying(255),
    address character varying(255),
    date_of_birth date,
    date_of_hiring date,
    learning character varying(255),
    reiligon character varying(255),
    postion boolean,
    email_verified_at timestamp(0) without time zone,
    email character varying(255) NOT NULL,
    "isAdmin" boolean DEFAULT false NOT NULL,
    login_allow boolean DEFAULT false NOT NULL,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: backups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backups ALTER COLUMN id SET DEFAULT nextval('public.backups_id_seq'::regclass);


--
-- Name: class_rooms id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_rooms ALTER COLUMN id SET DEFAULT nextval('public.class_rooms_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: grades id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades ALTER COLUMN id SET DEFAULT nextval('public.grades_id_seq'::regclass);


--
-- Name: images id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images ALTER COLUMN id SET DEFAULT nextval('public.images_id_seq'::regclass);


--
-- Name: ltu_contributors id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_contributors ALTER COLUMN id SET DEFAULT nextval('public.ltu_contributors_id_seq'::regclass);


--
-- Name: ltu_invites id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_invites ALTER COLUMN id SET DEFAULT nextval('public.ltu_invites_id_seq'::regclass);


--
-- Name: ltu_languages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_languages ALTER COLUMN id SET DEFAULT nextval('public.ltu_languages_id_seq'::regclass);


--
-- Name: ltu_phrases id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_phrases ALTER COLUMN id SET DEFAULT nextval('public.ltu_phrases_id_seq'::regclass);


--
-- Name: ltu_translation_files id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_translation_files ALTER COLUMN id SET DEFAULT nextval('public.ltu_translation_files_id_seq'::regclass);


--
-- Name: ltu_translations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_translations ALTER COLUMN id SET DEFAULT nextval('public.ltu_translations_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: parents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parents ALTER COLUMN id SET DEFAULT nextval('public.parents_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: pulse_aggregates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pulse_aggregates ALTER COLUMN id SET DEFAULT nextval('public.pulse_aggregates_id_seq'::regclass);


--
-- Name: pulse_entries id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pulse_entries ALTER COLUMN id SET DEFAULT nextval('public.pulse_entries_id_seq'::regclass);


--
-- Name: pulse_values id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pulse_values ALTER COLUMN id SET DEFAULT nextval('public.pulse_values_id_seq'::regclass);


--
-- Name: school_fees id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.school_fees ALTER COLUMN id SET DEFAULT nextval('public.school_fees_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: students id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students ALTER COLUMN id SET DEFAULT nextval('public.students_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: backups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backups (id, name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: class_rooms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.class_rooms (id, class_name, grade_id, user_id, created_at, updated_at) FROM stdin;
1	atque	2	1	2024-04-07 20:27:17	2024-04-07 20:27:17
2	voluptas	1	1	2024-04-07 20:27:17	2024-04-07 20:27:17
3	fuga	2	1	2024-04-07 20:27:17	2024-04-07 20:27:17
4	soluta	1	1	2024-04-07 20:27:17	2024-04-07 20:27:17
5	est	3	1	2024-04-07 20:27:17	2024-04-07 20:27:17
6	temporibus	3	1	2024-04-07 20:27:17	2024-04-07 20:27:17
7	alias	2	1	2024-04-07 20:27:17	2024-04-07 20:27:17
8	voluptas	1	1	2024-04-07 20:27:17	2024-04-07 20:27:17
9	provident	2	1	2024-04-07 20:27:17	2024-04-07 20:27:17
10	cupiditate	3	1	2024-04-07 20:27:17	2024-04-07 20:27:17
11	quas	3	1	2024-04-07 20:27:17	2024-04-07 20:27:17
12	eligendi	2	1	2024-04-07 20:27:17	2024-04-07 20:27:17
13	at	3	1	2024-04-07 20:27:17	2024-04-07 20:27:17
14	eius	1	1	2024-04-07 20:27:17	2024-04-07 20:27:17
15	maiores	2	1	2024-04-07 20:27:17	2024-04-07 20:27:17
16	et	4	1	2024-04-07 20:27:17	2024-04-07 20:27:17
17	deserunt	3	1	2024-04-07 20:27:17	2024-04-07 20:27:17
18	repudiandae	3	1	2024-04-07 20:27:17	2024-04-07 20:27:17
19	molestiae	1	1	2024-04-07 20:27:17	2024-04-07 20:27:17
20	assumenda	3	1	2024-04-07 20:27:17	2024-04-07 20:27:17
21	rerum	2	1	2024-04-07 20:27:17	2024-04-07 20:27:17
22	consequatur	4	1	2024-04-07 20:27:17	2024-04-07 20:27:17
23	eos	1	1	2024-04-07 20:27:17	2024-04-07 20:27:17
24	eius	4	1	2024-04-07 20:27:17	2024-04-07 20:27:17
25	voluptates	4	1	2024-04-07 20:27:17	2024-04-07 20:27:17
26	ad	3	1	2024-04-07 20:27:17	2024-04-07 20:27:17
27	facere	3	1	2024-04-07 20:27:17	2024-04-07 20:27:17
28	corrupti	2	1	2024-04-07 20:27:17	2024-04-07 20:27:17
29	vitae	4	1	2024-04-07 20:27:17	2024-04-07 20:27:17
30	assumenda	1	1	2024-04-07 20:27:17	2024-04-07 20:27:17
31	ex	4	1	2024-04-07 20:27:17	2024-04-07 20:27:17
32	minima	1	1	2024-04-07 20:27:17	2024-04-07 20:27:17
33	ipsam	1	1	2024-04-07 20:27:17	2024-04-07 20:27:17
34	ut	4	1	2024-04-07 20:27:17	2024-04-07 20:27:17
35	et	2	1	2024-04-07 20:27:17	2024-04-07 20:27:17
36	aut	3	1	2024-04-07 20:27:17	2024-04-07 20:27:17
37	totam	4	1	2024-04-07 20:27:17	2024-04-07 20:27:17
38	et	2	1	2024-04-07 20:27:17	2024-04-07 20:27:17
39	animi	3	1	2024-04-07 20:27:17	2024-04-07 20:27:17
40	inventore	4	1	2024-04-07 20:27:17	2024-04-07 20:27:17
41	quasi	2	1	2024-04-07 20:27:17	2024-04-07 20:27:17
42	sequi	4	1	2024-04-07 20:27:17	2024-04-07 20:27:17
43	qui	3	1	2024-04-07 20:27:17	2024-04-07 20:27:17
44	perferendis	2	1	2024-04-07 20:27:17	2024-04-07 20:27:17
45	dolorum	2	1	2024-04-07 20:27:17	2024-04-07 20:27:17
46	sed	1	1	2024-04-07 20:27:17	2024-04-07 20:27:17
47	aut	3	1	2024-04-07 20:27:17	2024-04-07 20:27:17
48	natus	2	1	2024-04-07 20:27:17	2024-04-07 20:27:17
49	et	2	1	2024-04-07 20:27:17	2024-04-07 20:27:17
50	non	4	1	2024-04-07 20:27:17	2024-04-07 20:27:17
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: grades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.grades (id, "Grade_Name", user_id, created_at, updated_at) FROM stdin;
1	الابتدائية	1	2024-04-07 20:27:16	2024-04-07 20:27:16
2	حضانة	1	2024-04-07 20:27:16	2024-04-07 20:27:16
3	الاعدادية	1	2024-04-07 20:27:16	2024-04-07 20:27:16
4	حضانة	1	2024-04-07 20:27:16	2024-04-07 20:27:16
5	 123	1	2024-04-09 22:22:37	2024-04-09 22:22:37
\.


--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.images (id, filename, imageable_id, imageable_type, created_at, updated_at) FROM stdin;
1	1.jpg	13	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
2	1.jpg	4	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
3	1.jpg	24	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
4	1.jpg	25	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
5	1.jpg	82	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
6	1.jpg	79	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
7	1.jpg	52	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
8	1.jpg	38	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
9	1.jpg	68	App\\Models\\My_parent	2024-04-07 20:27:19	2024-04-07 20:27:19
10	1.jpg	41	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
11	1.jpg	34	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
12	1.jpg	60	App\\Models\\My_parent	2024-04-07 20:27:19	2024-04-07 20:27:19
13	1.jpg	99	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
14	1.jpg	70	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
15	1.jpg	69	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
16	1.jpg	31	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
17	1.jpg	48	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
18	1.jpg	52	App\\Models\\My_parent	2024-04-07 20:27:19	2024-04-07 20:27:19
19	1.jpg	1	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
20	1.jpg	99	App\\Models\\My_parent	2024-04-07 20:27:19	2024-04-07 20:27:19
21	1.jpg	6	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
22	1.jpg	74	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
23	1.jpg	54	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
24	1.jpg	79	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
25	1.jpg	46	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
26	1.jpg	32	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
27	1.jpg	42	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
28	1.jpg	15	App\\Models\\My_parent	2024-04-07 20:27:19	2024-04-07 20:27:19
29	1.jpg	19	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
30	1.jpg	88	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
31	1.jpg	99	App\\Models\\My_parent	2024-04-07 20:27:19	2024-04-07 20:27:19
32	1.jpg	99	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
33	1.jpg	53	App\\Models\\My_parent	2024-04-07 20:27:19	2024-04-07 20:27:19
34	1.jpg	95	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
35	1.jpg	82	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
36	1.jpg	32	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
37	1.jpg	4	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
38	1.jpg	20	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
39	1.jpg	54	App\\Models\\My_parent	2024-04-07 20:27:19	2024-04-07 20:27:19
40	1.jpg	2	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
41	1.jpg	32	App\\Models\\My_parent	2024-04-07 20:27:19	2024-04-07 20:27:19
42	1.jpg	72	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
43	1.jpg	22	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
44	1.jpg	79	App\\Models\\My_parent	2024-04-07 20:27:19	2024-04-07 20:27:19
45	1.jpg	4	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
46	1.jpg	18	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
47	1.jpg	29	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
48	1.jpg	18	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
49	1.jpg	71	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
50	1.jpg	85	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
51	1.jpg	4	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
52	1.jpg	97	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
53	1.jpg	99	App\\Models\\My_parent	2024-04-07 20:27:19	2024-04-07 20:27:19
54	1.jpg	67	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
55	1.jpg	43	App\\Models\\My_parent	2024-04-07 20:27:19	2024-04-07 20:27:19
56	1.jpg	40	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
57	1.jpg	11	App\\Models\\My_parent	2024-04-07 20:27:19	2024-04-07 20:27:19
58	1.jpg	35	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
59	1.jpg	95	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
60	1.jpg	69	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
61	1.jpg	8	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
62	1.jpg	2	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
63	1.jpg	69	App\\Models\\My_parent	2024-04-07 20:27:19	2024-04-07 20:27:19
64	1.jpg	32	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
65	1.jpg	2	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
66	1.jpg	33	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
67	1.jpg	40	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
68	1.jpg	25	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
69	1.jpg	62	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
70	1.jpg	11	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
71	1.jpg	30	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
72	1.jpg	38	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
73	1.jpg	20	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
74	1.jpg	39	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
75	1.jpg	76	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
76	1.jpg	72	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
77	1.jpg	8	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
78	1.jpg	88	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
79	1.jpg	37	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
80	1.jpg	32	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
81	1.jpg	32	App\\Models\\My_parent	2024-04-07 20:27:19	2024-04-07 20:27:19
82	1.jpg	55	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
83	1.jpg	61	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
84	1.jpg	57	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
85	1.jpg	39	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
86	1.jpg	42	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
87	1.jpg	7	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
88	1.jpg	31	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
89	1.jpg	62	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
90	1.jpg	22	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
91	1.jpg	7	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
92	1.jpg	41	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
93	1.jpg	37	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
94	1.jpg	77	App\\Models\\settings	2024-04-07 20:27:19	2024-04-07 20:27:19
95	1.jpg	50	App\\Models\\My_parent	2024-04-07 20:27:19	2024-04-07 20:27:19
96	1.jpg	62	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
97	1.jpg	55	App\\Models\\Student	2024-04-07 20:27:19	2024-04-07 20:27:19
98	1.jpg	51	App\\Models\\My_parent	2024-04-07 20:27:19	2024-04-07 20:27:19
99	1.jpg	85	App\\Models\\User	2024-04-07 20:27:19	2024-04-07 20:27:19
100	1.jpg	3	App\\Models\\Class_room	2024-04-07 20:27:19	2024-04-07 20:27:19
\.


--
-- Data for Name: ltu_contributors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ltu_contributors (id, name, email, password, avatar, role, remember_token, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ltu_invites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ltu_invites (id, email, token, role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ltu_languages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ltu_languages (id, name, code, rtl) FROM stdin;
\.


--
-- Data for Name: ltu_phrases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ltu_phrases (id, uuid, translation_id, translation_file_id, phrase_id, key, "group", value, status, parameters, note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ltu_translation_files; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ltu_translation_files (id, name, extension, is_root) FROM stdin;
\.


--
-- Data for Name: ltu_translations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ltu_translations (id, language_id, source, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	2014_10_12_000000_create_users_table	1
2	2014_10_12_100000_create_password_reset_tokens_table	1
3	2019_08_19_000000_create_failed_jobs_table	1
4	2019_12_14_000001_create_personal_access_tokens_table	1
5	2023_06_07_000001_create_pulse_tables	1
6	2024_01_12_164040_create_settings_table	1
7	2024_01_12_172841_create_images_table	1
8	2024_01_17_180425_create_grades_table	1
9	2024_01_18_181323_create_class_rooms_table	1
10	2024_02_02_165625_create_parents_table	1
11	2024_03_01_211049_create_languages_table	1
12	2024_03_01_211050_create_translations_table	1
13	2024_03_01_211051_create_translation_files_table	1
14	2024_03_01_211052_create_phrases_table	1
15	2024_03_01_211053_create_contributors_table	1
16	2024_03_01_211055_create_invites_table	1
17	2024_03_01_211056_add_is_root_to_translation_files_table	1
18	2024_03_28_210218_create_school_fees_table	1
19	2024_03_29_121647_create_students_table	1
20	2024_03_30_194613_db_relations	1
21	2024_04_20_002037_create_backups_table	2
\.


--
-- Data for Name: parents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parents (id, "Father_Name", "Father_National_Id", "Father_Phone", "Father_Job", "Father_Birth_Date", "Father_Learning", "Mother_Name", "Mother_National_Id", "Mother_Phone", "Mother_Job", "Religion", "Address", "Mother_Birth_Date", user_id, deleted_at, created_at, updated_at) FROM stdin;
1	Magdalena	330407390001	+12764974579	Interior Designer	2003-09-23	Master	Dulce	357353370149	1-502-764-4726	Algorithm Developer	Muslim	15870 Georgianna Skyway Suite 759\nNew Tiannafurt, CO 09985	2010-07-14	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
2	Tyreek	403241375622	(706) 544-0949	Equal Opportunity Representative	2019-04-23	High School	Johanna	150444595774	681.477.8600	Mechanical Equipment Sales Representative	Christian	2963 Tess Forest\nTerryberg, KY 26886-0413	1981-11-27	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
3	Elisha	855728216199	646.990.0613	Anesthesiologist	2014-04-18	Master	Elbert	230651275153	505-380-9133	Drywall Ceiling Tile Installer	Muslim	55735 Kihn Viaduct Apt. 089\nEldoratown, VT 18990	1980-12-21	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
4	Novella	581841138163	+1.951.261.7513	Architectural Drafter	1980-05-25	Master	Jaden	754435128802	+18503956705	Boiler Operator	Muslim	441 Swaniawski Square Apt. 964\nWest Hollis, IN 05722	1998-09-13	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
5	Dan	751822724650	973-439-5682	Sailor	1970-03-02	Master	Jasmin	870312852636	(256) 780-7659	Maintenance Supervisor	Muslim	858 Enrico Prairie Apt. 741\nTrantowtown, AZ 33880-0480	1972-06-23	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
6	Valentine	858948861484	816.801.6407	Lifeguard	1978-08-26	Master	Treva	070632295171	+1 (224) 809-4134	Musical Instrument Tuner	Christian	82062 Jenifer Street\nAdaside, AZ 62059-7206	1993-04-29	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
7	Joanny	263562911348	+1-270-512-0671	Business Operations Specialist	1980-01-15	Bachelor	Laurine	939031535484	(854) 750-7355	Computer Support Specialist	Christian	8001 Ryan Knolls Suite 465\nLubowitzton, MI 73928	1984-10-24	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
8	Oleta	788870167274	+1-260-602-3827	Transportation Inspector	1991-08-08	Master	Violette	607749446958	1-207-666-9068	Coroner	Muslim	8507 Stevie Stream\nAufderharport, CT 15762	1972-06-27	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
9	Floy	897710268290	541.357.8267	Soldering Machine Setter	1973-11-21	Master	Brennan	990404281321	(260) 646-0664	Ship Mates	Christian	36118 Rowe Unions\nSouth Aida, MA 43963	2005-10-15	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
10	Maida	669678250786	+1-424-662-5850	Public Health Social Worker	1999-02-15	High School	Marcelina	770282446088	321.668.4692	Personal Home Care Aide	Muslim	743 Effertz Hill Suite 476\nRodfort, WI 79210	1990-03-20	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
11	Sincere	803112366660	+17042632229	Real Estate Association Manager	1985-07-27	High School	Florian	672820662970	+12766180208	Embalmer	Muslim	554 Aurore Fields\nNatshire, WI 74670-4037	1995-02-16	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
12	Ralph	951283693856	+1-323-283-8993	Plant and System Operator	2017-08-23	High School	Dandre	404804652469	(657) 452-5738	Assembler	Christian	32249 Pinkie Landing\nPort Rosannaberg, MI 29987-9383	2007-07-02	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
13	Olga	311206889242	(623) 549-8477	Broadcast Technician	2012-02-21	Bachelor	Emory	130881466813	605.498.4480	RN	Christian	259 Emely Vista\nFeilfurt, IN 79719-0604	1998-06-29	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
14	Samara	257959971395	1-978-473-5206	Gaming Dealer	1972-08-20	High School	Destini	969270903514	+1 (423) 946-0993	Statistician	Muslim	93772 Genevieve Forge\nAbigalebury, CT 08504	2017-03-02	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
15	Susie	768608621617	1-539-489-6219	Online Marketing Analyst	1997-05-15	Bachelor	Holden	562986516206	302-828-0373	Emergency Medical Technician and Paramedic	Muslim	2272 Torp Crescent\nAlechaven, UT 31564	1976-11-21	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
16	Evans	877016176649	864.533.3554	Architect	2023-11-19	Master	Kaya	039131000932	1-909-395-3730	Veterinary Technician	Christian	715 Kuhn Extensions\nFayberg, WY 03594-5948	1980-05-02	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
17	Adonis	907817137780	+1 (904) 881-2487	Claims Examiner	1983-12-30	High School	Hope	460520715095	1-260-926-8703	Medical Assistant	Christian	713 Windler Manors\nRusselbury, MA 04926	2016-04-24	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
18	Raoul	987131764006	(463) 392-4099	Carver	2016-02-18	Bachelor	Keira	257789049324	+1-862-550-4644	Bindery Worker	Christian	880 Hyatt Lock Apt. 841\nBaumbachport, VT 67463-2538	1997-07-17	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
19	Freddy	966522057839	1-972-696-4799	Drafter	2006-03-15	Bachelor	Sister	826465227008	+1-281-293-6990	Veterinary Assistant OR Laboratory Animal Caretaker	Christian	331 Twila Hills\nNew Helmerside, MS 43486	2019-12-12	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
20	Bethany	129171847290	+15867088939	Tire Builder	1980-12-15	High School	Cody	484865653005	(517) 976-5374	Forming Machine Operator	Muslim	73588 Krajcik Pass Apt. 993\nNorth Marian, IL 78691	1979-06-17	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
21	Annamarie	362585974975	(979) 422-5224	Electronics Engineer	1989-11-04	Bachelor	Shanelle	089828940976	847-673-0370	Photographic Restorer	Christian	263 Jett Flat\nBrandtberg, NE 74589	1973-01-06	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
22	Gladyce	948246243464	+1 (540) 748-1093	Geoscientists	2018-12-17	High School	Lolita	032259884492	719.868.6867	Watch Repairer	Muslim	3140 Crawford Mission Apt. 778\nLake Bonitamouth, CT 43620-3558	2005-10-31	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
23	Kristian	442667932391	+1.571.652.4906	Optical Instrument Assembler	2018-09-28	Bachelor	Cornelius	010737692159	+1 (978) 608-0786	Electronic Masking System Operator	Muslim	50810 Dicki Points Apt. 213\nWatsicafurt, CO 27925-1253	1997-03-23	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
24	Freddy	657032186773	828.787.0074	Punching Machine Setters	1974-06-28	High School	Gracie	271798065831	(718) 427-2547	Entertainment Attendant	Christian	9059 Cruickshank Mill\nLake Thelmaberg, OR 48631	2000-02-20	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
25	Eldora	466572561154	757.970.7621	Welding Machine Operator	1976-03-19	High School	Kevon	120445185009	(786) 734-4437	Electrical Engineer	Christian	60613 Walker Wall\nTorphyshire, AZ 21597-3821	1980-10-19	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
26	Jayda	746822668576	(641) 732-1663	Fish Hatchery Manager	1988-12-15	Master	Cortney	450434845638	+18782652803	Political Science Teacher	Christian	18538 Sonya Pines\nLake Lillian, AZ 05779-3044	1999-11-11	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
27	Aisha	716979039177	929.254.3671	Extruding and Drawing Machine Operator	2019-10-15	Master	Julianne	077761232229	+1.520.543.1523	Floor Layer	Christian	5554 Kutch Greens Suite 581\nPriceland, SD 39708	2009-10-14	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
28	Noel	417659334457	+1-864-399-6868	Locomotive Engineer	2011-08-24	Master	Sylvester	428168790461	1-480-338-9355	Merchandise Displayer OR Window Trimmer	Muslim	343 Ryann Harbors\nNew Katelynnberg, NC 50207-6815	1992-01-12	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
29	Blanche	233249575351	417-292-9453	Correctional Officer	1971-12-09	Master	Earnestine	806736880606	+1 (662) 564-3981	Head Nurse	Christian	98432 Leuschke Villages\nLake Denamouth, MN 41654-7615	1973-05-06	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
30	Dorothea	467426948305	1-480-866-7802	Forming Machine Operator	2022-01-14	High School	Carlee	819152638978	408.315.4679	Alteration Tailor	Muslim	18237 Daugherty Cliff\nNicholasmouth, ID 07016-9398	1975-10-06	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
31	Candace	005967331419	574-986-5189	Keyboard Instrument Repairer and Tuner	1986-11-27	High School	Jazmin	079191585548	(856) 849-4292	House Cleaner	Muslim	231 Christiansen Radial Suite 042\nO'Connellmouth, SC 56118	2013-08-24	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
32	Jeff	878583979399	+14805038427	Executive Secretary	1973-05-03	High School	Dino	597129850882	(256) 434-8486	Vocational Education Teacher	Christian	9656 Walsh Knoll\nLake Bonnieside, NJ 36561-4196	1989-03-12	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
33	Tressie	480926348163	1-743-818-4384	Craft Artist	2002-12-24	High School	Kraig	513346341521	+1-903-687-6529	Machine Tool Operator	Muslim	85205 Donnell Mission\nEast Reneville, AL 99781	1992-07-13	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
34	Lora	053302466409	+1-458-335-0704	Diagnostic Medical Sonographer	2007-08-07	High School	Herminio	400424962324	+14634537409	Medical Records Technician	Muslim	35275 Torphy Island\nBoscochester, AL 88090-7210	1973-06-17	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
35	Meagan	584601174424	386.388.4710	Locomotive Engineer	2008-03-16	High School	Josiah	323133937612	+1-231-662-8374	Highway Patrol Pilot	Muslim	90558 Cassin Glen\nJoefort, MT 51631	1998-03-05	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
36	Toby	554357945316	(470) 816-5173	Hand Sewer	1986-09-03	Bachelor	Orville	807307629457	1-949-741-5163	Chiropractor	Christian	173 Breitenberg Street Apt. 127\nColemanport, ID 86569-3090	1999-02-15	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
37	Hassie	337350394130	+1 (623) 604-6059	Statement Clerk	1976-09-08	Master	Darrin	191985254900	1-458-371-3550	Housekeeper	Muslim	9257 Lisandro Light\nRogahnside, HI 05504	2022-09-25	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
38	Chance	972632349930	(931) 451-8244	Nonfarm Animal Caretaker	2005-08-06	Bachelor	Ana	196888957858	(458) 685-9160	Welder	Muslim	33368 Funk Forge\nArmandchester, IA 40788	2007-09-03	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
39	Darlene	072718973468	+1 (661) 254-2431	Bulldozer Operator	2019-06-01	Master	Muriel	758980669405	+1.646.980.2401	Mechanical Equipment Sales Representative	Muslim	88543 Herta Trace Suite 931\nPort Jamir, WA 77681	2010-06-28	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
40	Carlee	995630331385	1-380-327-1290	Metal Pourer and Caster	1986-11-07	Bachelor	Corene	305994368272	(419) 275-9106	Webmaster	Muslim	26043 Wilkinson Junction\nMaximusbury, WV 39714	2004-10-11	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
41	Lenna	880380753006	+1 (380) 539-9665	Foreign Language Teacher	1990-05-25	Master	Hubert	021577016200	1-813-501-3035	Maid	Muslim	49184 Chelsie Valley\nEast Kailee, MI 53141-7442	2019-05-10	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
42	Joanne	716882636075	+1 (785) 466-7706	Tractor Operator	2012-12-14	Master	Bret	913298891235	+1 (970) 596-7172	Soldering Machine Setter	Muslim	196 Thiel Viaduct\nFritschchester, SD 31109-7736	2005-06-27	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
43	Maxie	636506483603	+1 (352) 771-5036	Tool and Die Maker	2002-08-12	High School	Jarrod	657237744128	973.780.8661	Materials Inspector	Christian	645 Schultz Centers\nAntoniettafort, ND 42821	1993-05-08	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
44	Tobin	508134166704	351-992-7205	Chef	1993-08-05	Bachelor	Werner	617361992425	+15164172946	Precision Aircraft Systems Assemblers	Muslim	751 Lavina Street Suite 114\nMoorefurt, HI 85443-0193	2012-10-18	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
45	Lydia	076773670422	1-435-461-4954	Plating Operator OR Coating Machine Operator	1976-07-19	Bachelor	Madisyn	171156859268	417-498-1337	Forest Fire Fighter	Muslim	4159 Deion Well Suite 622\nCoraliestad, NY 02386	1979-10-31	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
46	Elvera	937476047491	+13513423470	Preschool Teacher	1989-12-11	Bachelor	Paige	203012277839	+1-715-876-7227	Product Management Leader	Muslim	114 Emmerich Terrace\nTerrychester, DC 29922	1977-11-15	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
47	Felipa	360275814678	(952) 721-7160	Multiple Machine Tool Setter	2008-04-08	Bachelor	Treva	932508157364	+1.641.242.4325	Patternmaker	Christian	6743 Ashley Rapid\nNorth Price, CA 59955-0280	1983-08-13	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
48	Khalil	319775438116	+1.870.508.6835	Cost Estimator	1989-02-01	Bachelor	Maude	687967445382	+1-480-396-5074	Travel Clerk	Christian	392 Connelly Roads Apt. 835\nWest Estellmouth, LA 07354-9352	1999-07-17	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
49	Heloise	139757910124	480.661.6965	Statistician	2017-05-06	High School	Jermey	012069261661	+1-540-720-2974	Computer Software Engineer	Muslim	263 Koepp Avenue Suite 890\nPort Christa, NE 66200	2018-10-12	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
50	Haylie	500108974146	1-831-707-4235	Gas Distribution Plant Operator	1982-07-19	Bachelor	Karson	826770302139	1-651-270-6410	Meter Mechanic	Muslim	66679 Hoppe Station Apt. 475\nAylinton, NC 27802-0065	1977-07-20	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
51	Anna	020842959795	(828) 632-1780	Calibration Technician OR Instrumentation Technician	2009-02-03	High School	Imelda	886331133635	651.660.0057	Opticians	Christian	930 Alisha Corner Apt. 431\nMohammedstad, WV 18838	2021-12-08	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
52	Emma	764025073700	1-919-265-0982	Welding Machine Setter	1987-05-27	High School	Theodore	623950320473	(531) 644-7523	Athletic Trainer	Christian	70833 Kyleigh Stream\nSouth Nolastad, DE 45865	1978-05-13	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
53	Ramon	001608367937	848.480.7283	Supervisor of Police	1973-03-28	Master	Jovany	710167675055	+1 (469) 641-8825	Medical Records Technician	Christian	8819 Jasper Plaza Suite 465\nRempelhaven, DC 58847	1972-01-31	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
54	Amir	663889717417	+1-380-407-2152	Sawing Machine Operator	1984-02-02	Bachelor	Henriette	524560080586	520-532-6373	Storage Manager OR Distribution Manager	Christian	2941 Emmerich Stream Apt. 651\nCruickshankport, WA 97401-4036	2017-02-23	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
55	Natasha	550457758074	1-956-697-1841	Decorator	1974-08-14	Bachelor	Lila	703165423875	571-583-7697	Shoe and Leather Repairer	Muslim	6402 Deckow Drives\nPort Jace, MN 56125-3266	2013-12-02	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
56	Rosella	847171440373	+1 (651) 330-9825	Textile Machine Operator	1990-04-24	High School	Nickolas	511671885010	(440) 358-3022	Retail Sales person	Muslim	355 Clemens Row\nWuckertfort, MT 36044-0532	2020-11-17	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
57	Dejah	734129215061	+19797785571	Boat Builder and Shipwright	2000-03-16	High School	Colby	870759313809	(727) 849-0512	Respiratory Therapist	Christian	6084 Samir Vista\nEast Alizachester, AR 91612-0168	1971-11-16	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
58	Willy	990113907126	1-786-345-8774	Artist	1989-03-13	Master	Donny	850149009646	984-962-2772	Park Naturalist	Christian	808 Lueilwitz Divide Apt. 609\nPort Viviennestad, TN 26389	1994-12-15	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
59	Eriberto	593974736858	+1.352.960.9393	Clinical School Psychologist	2021-09-10	High School	Joanny	621020650933	1-786-530-9574	Metal Pourer and Caster	Christian	362 Metz Heights\nEbbaside, IN 75156	2001-03-04	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
60	Deon	031411672436	1-757-410-1133	Clinical Laboratory Technician	2021-08-27	Master	Tyreek	198787256923	1-440-527-4324	Cook	Christian	45326 Pagac Junction\nKiehnport, KS 87279	2020-08-16	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
61	Trey	770128375497	678-227-1115	Transportation Equipment Painters	1971-11-02	Bachelor	Alberto	316146288449	+1-443-912-1568	Telephone Station Installer and Repairer	Christian	6875 Haylee Key Apt. 058\nPalmaport, IN 75483	2004-03-12	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
62	Vinnie	104483006345	1-872-321-1527	Physician Assistant	1993-06-10	Master	Lizzie	817839276321	337.499.3213	Biological Scientist	Christian	81508 Arlene Manor\nKamronside, PA 25035	1990-03-28	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
63	Clare	714031014406	+1.762.523.8659	Electronic Engineering Technician	1983-03-31	Master	Zoe	517862804574	+1 (434) 660-8089	Logging Supervisor	Muslim	104 Schmeler Inlet Suite 726\nNew Adrienne, AZ 81207-5583	2022-08-18	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
64	Ruben	059963715095	386.633.2084	Captain	2009-03-11	High School	Kareem	089424071521	+1-434-760-1196	Ceiling Tile Installer	Christian	4992 Lueilwitz Corner Apt. 905\nNew Jalynmouth, CT 43635	1980-02-16	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
65	Amir	803210055994	858.815.4504	Continuous Mining Machine Operator	2011-12-27	Master	Tommie	644130812606	817-454-6162	Home Appliance Installer	Muslim	6785 Franecki Gardens Apt. 908\nNorth Karson, AL 75414	2007-10-23	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
66	Columbus	113558507768	1-443-485-7679	Transportation Inspector	1982-01-10	High School	Coty	332527600402	+12027097368	Adjustment Clerk	Christian	607 Keara Shoal Apt. 496\nCarolinefurt, UT 17514-6151	2010-07-13	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
67	Garth	413547576665	805-214-9258	User Experience Researcher	1989-01-09	Bachelor	Kenyatta	139390526020	+1.458.906.7481	Floral Designer	Muslim	3220 Hermina Locks Suite 150\nPort Alessandro, NJ 03087-7700	2017-01-05	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
68	Derick	850064779714	678-672-6086	Mining Engineer OR Geological Engineer	1985-10-11	Bachelor	Stephen	817299548446	(580) 558-3867	Material Movers	Muslim	368 Grace Union\nCobyberg, NE 77078-6956	2003-11-18	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
69	Jaeden	641631226770	+1-207-605-5339	Packaging Machine Operator	1982-09-24	Bachelor	Beatrice	058046251507	1-518-964-1130	Automotive Body Repairer	Muslim	3402 Kamille Trail Apt. 168\nLake Shanie, HI 81581	1980-09-14	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
70	Angeline	105179616619	+15595995105	Transportation Attendant	2019-02-28	Bachelor	Kenyon	989077671005	(870) 465-9213	Real Estate Broker	Christian	3436 Nola Squares Suite 540\nSouth Stephanieburgh, RI 89625-1336	1998-07-15	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
71	Jada	303424590637	1-646-798-7619	Biochemist	2014-09-11	Bachelor	Ike	747698955694	+1-972-442-9448	Statistician	Muslim	78341 Daron Route\nSouth Alisa, IN 66020	2011-03-11	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
72	Assunta	629307057868	445.651.8175	Plumber	2006-09-05	High School	Cortney	795588236369	1-541-770-2783	Makeup Artists	Christian	19335 Kaci Camp\nRettaview, AL 01990-5899	1982-09-28	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
73	Rey	894379798539	1-580-920-6146	Recreation Worker	2023-09-06	High School	Minerva	273747741232	364-470-2849	Court Reporter	Muslim	6973 Eleazar Pike Apt. 667\nNew Darby, SC 20841	1983-12-17	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
74	Judd	554114904813	+16787871447	Clergy	1980-07-09	Bachelor	Alejandra	354176330384	(239) 330-8962	Brickmason	Muslim	4049 Melany Throughway Apt. 460\nGrimesshire, WI 08141	1978-02-03	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
75	Jake	137246137007	415-996-4951	Tool Sharpener	1974-11-10	Master	Brandyn	625037482010	+1-346-331-3587	Installation and Repair Technician	Christian	7239 Cummerata Harbor Suite 047\nDiamondfort, PA 65895	2016-02-08	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
76	Johanna	232160401526	469.804.7686	Director Religious Activities	1993-09-23	High School	Elvis	964384208253	(206) 580-4487	Private Household Cook	Christian	480 Stewart Village Suite 248\nEast Ebonymouth, OK 16731	2016-03-10	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
77	Luz	604935567413	+1.478.803.1297	Numerical Tool Programmer OR Process Control Programmer	1973-01-02	Bachelor	Stacy	478225304498	+14582137857	Inspector	Muslim	8671 Hegmann Parks\nBoyerview, KS 80525-3598	1982-03-09	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
78	Zola	268791624686	+1-770-354-8603	Physicist	1984-09-05	High School	Thaddeus	711774716339	1-541-409-7785	Chemical Technician	Christian	669 Mabelle Parkway\nCassandrestad, VT 83720-5596	1971-11-19	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
79	Destiney	980001155325	434.521.5619	Library Technician	2012-04-02	Master	Justus	497758303648	213-737-0297	Home Appliance Installer	Christian	93753 Nigel Fields\nSouth Enricofurt, TN 12424-3471	1991-09-27	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
80	Donato	170124916355	914.435.3801	Audio-Visual Collections Specialist	2022-06-02	Bachelor	Laverne	361910472183	949-546-0510	Substation Maintenance	Christian	65430 Amy Parkway\nEzekielhaven, SD 79271-9772	2004-05-23	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
81	Mayra	574274513822	804-778-2055	Loan Interviewer	1984-12-29	Bachelor	Graciela	243349457123	+1-947-745-7030	Mechanical Engineering Technician	Christian	849 Orn Union\nLake Dennis, MI 49114-1081	2013-06-09	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
82	Louvenia	635385215868	1-361-452-3048	Chiropractor	1995-11-22	High School	Augusta	966547261257	+16782391983	Archeologist	Muslim	229 Merl Mountain\nEberthaven, FL 24575	1986-09-28	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
83	Lilyan	123437969067	+18035089961	Agricultural Engineer	2011-01-23	Master	Mitchell	105762640839	(469) 274-7588	Surgical Technologist	Christian	9821 Grover Meadows\nNorth Petehaven, AZ 54868-9961	1979-03-27	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
84	Griffin	773435450871	203.638.9158	Order Clerk	2003-09-09	Master	Yesenia	765443289603	+1-509-761-6795	Wellhead Pumper	Christian	96849 Rhoda Garden Apt. 023\nNew Tristinview, MA 91184	2014-01-14	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
85	Susie	099068568217	+1.731.567.9532	Roustabouts	1999-08-13	Bachelor	Cordell	556211761141	1-502-736-5225	Announcer	Christian	8949 Nora Lake Apt. 392\nLake Johnathontown, CO 77375	2012-01-13	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
86	Rosendo	772621592597	585.250.4379	Septic Tank Servicer	1982-10-19	Bachelor	Cordie	806548241895	279-272-3427	Solderer	Muslim	13732 Murazik Square Suite 574\nPort Marciaport, WY 96996	2020-01-04	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
87	Stacy	588147827218	+1.586.608.1935	Geological Sample Test Technician	2022-03-14	High School	Beaulah	186814670231	(424) 343-1239	Extruding Machine Operator	Christian	77534 Alicia Viaduct\nLubowitzstad, IL 85837-8380	1986-09-15	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
88	Rigoberto	878025144288	1-908-841-8946	Precision Etcher and Engraver	1989-12-25	High School	Preston	437039164704	+1-475-863-6006	Funeral Attendant	Christian	276 Lauryn Valleys Apt. 177\nChadshire, MA 84074	1978-11-11	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
89	Annetta	538502800055	+1-979-957-5247	Park Naturalist	1989-04-13	High School	Mable	777863733956	520-945-0279	Forest and Conservation Worker	Muslim	8134 Lavinia Ports Apt. 276\nCamylleport, UT 38642-8673	1981-08-27	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
90	Brady	510313440256	+1 (623) 806-6038	Buffing and Polishing Operator	1970-08-21	Master	Jada	170198813431	+1-986-731-6382	Woodworker	Christian	35648 Gene Garden Suite 956\nNorth Stephanie, HI 78208-5809	1987-02-24	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
91	Marcelina	310175178370	361-396-1168	Transportation Equipment Maintenance	1990-04-22	Bachelor	Aubree	093788084786	762-818-3423	Copy Writer	Muslim	36268 Bennett Lodge Apt. 201\nKarlieville, MO 75595	1976-11-17	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
92	Maida	455699795110	(682) 273-9110	Crushing Grinding Machine Operator	1994-05-01	High School	Toni	726570627694	+19146843320	Chemical Equipment Operator	Muslim	2956 Kutch Mill Suite 534\nWalshville, MN 88634-5833	2017-05-23	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
93	Lavina	334458660723	1-936-340-1144	Lifeguard	2005-08-24	Bachelor	Hayley	182227643851	330-296-9807	Desktop Publisher	Muslim	62553 Tre Valley\nPort Jackeline, NC 75440-3997	2011-04-04	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
94	Beau	020964549572	+1-757-716-5192	Motorboat Operator	1970-01-07	Master	Dax	018394733674	321.465.5243	Photographer	Muslim	1869 Barton Meadow Suite 970\nLockmanchester, NM 09467	1979-08-09	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
95	Kelton	990248951505	+1.254.967.9110	Police Identification OR Records Officer	2019-09-21	Bachelor	Katherine	637381370529	850-934-1145	User Experience Manager	Christian	296 Wolff Mews\nWest Damian, OR 88921	1978-10-21	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
96	Nigel	017619479533	+13208850743	Mail Clerk	2001-04-23	High School	Triston	236045195004	1-925-589-3295	Stringed Instrument Repairer and Tuner	Muslim	21319 Bettye Ferry\nEast Rhiannon, AL 30403-4351	1979-01-30	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
97	Bernardo	946985183076	1-480-290-6004	Recreational Therapist	1979-02-24	High School	Elody	545600984693	717-454-3163	Licensed Practical Nurse	Muslim	554 Kiarra Streets Apt. 813\nSylviaport, CT 50961	1987-06-30	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
98	Furman	238017314842	+1 (843) 485-3947	Tile Setter OR Marble Setter	1990-09-04	High School	Eleonore	468548123619	678-869-7376	Petroleum Pump System Operator	Muslim	688 Crist Garden Suite 774\nLake Imaniport, NC 09742	1971-01-14	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
99	Raegan	704602113584	857.781.4832	Pewter Caster	1981-03-30	Bachelor	Gonzalo	248492148190	+1-838-438-4501	Boilermaker	Muslim	28753 Hermiston Run Suite 834\nMertieton, SD 34105-6194	2009-04-10	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
100	Jadon	920371121843	302.741.7043	Packaging Machine Operator	1994-09-05	Bachelor	Frederik	057236466039	410-540-4905	Environmental Engineering Technician	Muslim	437 Justyn Forge\nSterlingchester, ME 66671	2015-01-16	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
101	Mallie	819073442770	(979) 233-5322	Electrical Engineering Technician	2013-03-02	Master	Duane	063047683457	+1 (580) 980-9561	Agricultural Crop Worker	Muslim	7237 Joel Key\nConnellyside, MI 06999	1998-12-10	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
102	Kody	235487490827	857.497.0929	Organizational Development Manager	1987-06-13	Bachelor	Percy	466664806869	1-938-307-4103	Engineering Teacher	Muslim	370 Skiles Crest\nWest Gunnertown, ID 70234-0442	2016-08-27	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
103	Mikel	346891376732	(785) 676-8529	Kindergarten Teacher	1991-02-04	Master	Nat	654440813757	209-218-2292	Diamond Worker	Christian	30922 Bernier Prairie Apt. 283\nNew Abdullah, DC 96798-3621	1994-03-31	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
104	Anastacio	300539661741	(364) 705-8130	Forest and Conservation Technician	2003-05-21	Master	Eleanore	508371720038	772-222-6168	Psychiatric Technician	Muslim	546 Winifred Courts\nProsaccomouth, SD 63133-4713	2020-05-10	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
105	Gilberto	709480638996	+1.678.695.7323	Coating Machine Operator	1996-07-01	Master	Lucienne	559609646264	(838) 224-2905	Forging Machine Setter	Christian	317 Thurman Trail\nYazminburgh, KY 17019-0382	2002-05-03	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
106	Derek	185457126017	+1-423-750-5174	Civil Engineer	2023-11-15	Bachelor	Gino	479356928869	+1-678-672-5146	Law Clerk	Christian	72033 Schneider Roads Suite 409\nPort Linda, MT 13170	2020-03-05	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
107	Telly	894164255215	+1 (534) 849-4690	Rail Transportation Worker	2022-10-22	Bachelor	Aniyah	284885870206	985.831.0595	Webmaster	Muslim	850 Maximillian Plaza Suite 753\nLake Amelie, AL 85767	1972-12-18	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
108	Kyleigh	387444208519	(786) 234-8570	Set and Exhibit Designer	1983-02-19	Master	Jayce	770912060740	469.589.0096	Taxi Drivers and Chauffeur	Christian	57729 Prohaska Club\nStrosinbury, IA 25353-0737	2015-03-18	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
109	Elenor	119487876406	1-231-465-6182	Electronic Drafter	2009-04-22	High School	Tianna	565576524907	+14254257837	Police and Sheriffs Patrol Officer	Christian	765 Kerluke Station Apt. 299\nLisandroton, VA 21482-7059	1976-11-11	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
110	Cortney	423994877299	+1-947-262-6744	Welder	1995-08-25	Bachelor	Montana	066608910951	+1-301-372-3966	Educational Psychologist	Christian	7492 Jacques Road Apt. 650\nSouth Georgiannaview, OR 62727-5283	2002-07-31	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
111	Taylor	979689675412	+15017171288	Government	1991-08-10	Bachelor	Jeromy	886751101162	+1 (364) 769-5431	Poultry Cutter	Muslim	93748 Eldon Shoal\nNew Zora, AL 95248-0864	1994-11-16	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
112	Alan	513853994227	657.697.1391	Software Engineer	2004-06-09	Master	Sadye	774752207046	+13106707595	Artist	Christian	4467 Darlene Brook Suite 362\nMaximefurt, WY 65313-4020	2020-08-28	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
113	Maximillia	750882684805	954-800-3679	Music Composer	1981-02-20	Master	Avis	074894188567	316-934-0661	Biological Science Teacher	Muslim	2117 Breitenberg Tunnel\nBreitenbergchester, WY 40176-7405	1982-04-14	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
114	Sheridan	129879308323	+19727143676	Personal Financial Advisor	2022-02-22	High School	Nathanael	408273498275	+1-814-549-4753	Teacher	Christian	499 Roma Camp Apt. 147\nHahnborough, DC 89947-5853	1988-03-22	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
115	Ross	795476541236	+1-936-736-1352	Protective Service Worker	2018-09-01	High School	Maximillia	400099186098	+1.385.532.7781	Psychology Teacher	Christian	7919 Turner Forks Apt. 460\nKingport, CT 59135	1977-06-09	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
116	Maryjane	466901686116	(240) 693-9813	Welfare Eligibility Clerk	1998-11-12	High School	Lavonne	739997440610	+16052650374	Welder	Christian	781 Summer Cliff Apt. 000\nFletafort, MD 54204-4791	2002-05-06	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
117	Ransom	835561805514	706-960-9954	Recreation and Fitness Studies Teacher	1995-04-28	Master	Johnny	828368863605	(724) 890-1161	Numerical Control Machine Tool Operator	Muslim	7161 Laney Inlet Apt. 188\nNorth Winstonside, PA 87980	2021-10-03	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
118	Mary	904628558503	1-986-990-0152	Real Estate Broker	2008-02-18	Master	Bessie	305385570885	1-678-379-6245	Bookbinder	Muslim	660 Lessie Glens\nLake Rasheed, MT 30967	1973-03-03	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
119	Raven	922166569005	443-324-8953	Gaming Surveillance Officer	1970-04-21	Master	Alanna	436346857314	+1-361-608-9143	Food Preparation	Christian	37575 Weber Ridges Suite 494\nWest Elenashire, NM 06611-9448	1976-12-17	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
120	Karine	060921319911	+1-251-255-3076	Maintenance Equipment Operator	2001-09-09	High School	Benedict	498765662071	520.562.9904	Typesetting Machine Operator	Christian	5784 Lowe Parks\nRosenbaumshire, NJ 67221-6687	1970-10-25	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
121	Shirley	356768277871	678.702.6151	Dragline Operator	1972-02-08	Bachelor	Jonas	799272867895	+1 (424) 733-9620	Podiatrist	Muslim	4306 Shields Point Suite 155\nWest Taylorport, ME 29843-9810	2000-04-27	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
122	Alicia	148989124287	713-884-0163	Medical Appliance Technician	2019-05-01	Bachelor	Makenna	534264756941	743.585.4247	Logging Supervisor	Muslim	46844 Hermiston Ville\nSouth Harry, RI 97225	1989-06-01	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
123	Elwyn	646944158485	+1.551.202.3080	Computer Hardware Engineer	2005-07-06	Master	Blanche	085234237636	848-958-2112	Farmer	Christian	3670 Gerhold Grove Suite 636\nNorth Jennyfer, VA 11979	1986-03-25	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
124	Reid	693280498674	+15749244730	Central Office and PBX Installers	1982-05-12	Bachelor	Bennett	388290774849	+1.520.677.0441	Fabric Mender	Christian	946 Quigley Street\nEdgardobury, RI 71704-8587	1998-02-16	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
125	Jeffrey	987110907710	(640) 247-9933	Marking Machine Operator	2023-03-05	High School	Dewayne	807656275852	937-509-5570	Fish Game Warden	Christian	1156 Emmalee Ports\nOrenstad, NC 68768-5613	1985-04-03	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
126	Elise	622184768717	346-561-5115	Housekeeping Supervisor	1977-05-19	Bachelor	Rosa	059439065752	(681) 405-8299	Gaming Dealer	Muslim	62771 Carter Light Suite 078\nSiennahaven, MA 39140-7858	2024-03-12	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
127	Rene	202765219556	217-384-8472	Veterinary Assistant OR Laboratory Animal Caretaker	1993-05-10	Master	Nicolette	721116372682	970-503-6956	Therapist	Muslim	4898 Orie Dale\nKaseyville, NY 06465	2012-08-01	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
128	Christine	065092868266	1-321-555-7310	Purchasing Agent	2023-09-20	Bachelor	Alize	999211644797	352-320-4710	Precision Dyer	Christian	599 Connelly Lane Suite 989\nNorth Kirstin, AR 27628	2015-06-16	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
129	Kaylie	758350861626	(540) 933-9046	Locomotive Engineer	2011-07-04	Bachelor	Domenick	613000825349	(334) 235-4656	Lawyer	Christian	78712 Jacobson Valley\nLake Arthur, OK 30811	1991-03-23	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
130	Buck	656427352076	(534) 479-0096	Network Admin OR Computer Systems Administrator	2020-08-25	Bachelor	Retta	617360211694	+1-479-558-5609	Terrazzo Workes and Finisher	Muslim	339 Berniece Parks\nSouth Giovannyfurt, OH 91380	1983-06-11	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
131	Freddie	157136388303	+1 (608) 898-9894	Business Manager	2004-10-01	Bachelor	Beryl	345213983308	+1 (585) 882-2317	Product Promoter	Christian	40909 Howell Wall Suite 594\nLake Roberto, RI 14351-2867	1986-09-17	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
132	Sammie	807037286412	(860) 769-8904	Aircraft Launch and Recovery Officer	2004-02-03	High School	Manuela	177852012761	1-283-976-4520	Highway Patrol Pilot	Christian	230 Gusikowski Crossroad\nWest Nasirview, NH 49109	1970-05-27	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
133	Itzel	392506669677	928-334-1622	Recreation and Fitness Studies Teacher	1997-07-24	Bachelor	Ernestina	178069591059	(352) 548-8033	Range Manager	Christian	5790 Kelly Loaf\nWilkinsonburgh, FL 38898-3403	2012-05-10	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
134	Patricia	821636093435	+1-458-986-0983	Residential Advisor	1990-10-01	High School	Abdul	403111597912	(385) 393-6043	System Administrator	Christian	1829 Kassulke Garden Suite 430\nRaphaelleview, ND 65344-5856	2010-12-06	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
135	Mireya	284583393887	443.494.9385	English Language Teacher	2021-05-07	Bachelor	Katarina	045576629081	260.734.0510	Forester	Muslim	89974 Stokes Lights Suite 551\nConstantinfort, NV 49494-9192	2007-05-31	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
136	Julianne	577190403978	(256) 664-9714	Production Inspector	1976-04-09	Bachelor	Leola	598850729339	425.405.1856	Industrial-Organizational Psychologist	Christian	90392 Cheyanne Place Apt. 861\nNew Zellamouth, KS 15381	2004-06-28	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
137	Hermann	698501757386	+1 (860) 242-6386	Sys Admin	1988-12-28	Bachelor	Kyle	825544859492	1-712-305-9074	Watch Repairer	Christian	394 Gia Rapid Suite 711\nSouth Virginia, WI 84832	1994-11-21	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
138	Conor	876531929815	(361) 271-4566	Automotive Body Repairer	1987-09-07	Master	Benny	827908873485	+1-973-504-4648	Entertainment Attendant	Christian	900 Kiera Street\nNorth Amira, KS 42034	1973-05-17	1	\N	2024-04-07 20:27:18	2024-04-07 20:27:18
139	Tom	360547868890	1-801-795-2071	Gaming Service Worker	1987-04-09	Bachelor	Gabrielle	432092046567	+1.360.410.7203	Network Systems Analyst	Muslim	15043 Allene Hollow\nUllrichton, TN 95881-1722	2004-08-07	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
140	Cloyd	490940354510	+1-727-584-9821	Product Safety Engineer	1990-09-19	Master	Diego	266404300317	+1 (628) 705-2052	Dancer	Christian	673 Rowe Cliff Apt. 746\nPort Emanuelton, RI 30766-6245	1991-08-25	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
141	Dorcas	338607190956	+1 (818) 808-2861	Mathematical Technician	2007-12-14	High School	Garnett	287272585420	+1 (319) 338-2368	Tool Set-Up Operator	Christian	95847 Macy Run Suite 462\nJaceville, AZ 11271	1995-10-20	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
142	Zachariah	475706801291	+1.970.334.2339	Personal Care Worker	1984-07-01	Master	Chaz	633519308142	(217) 352-3844	Bailiff	Christian	684 Ward Bypass Suite 136\nEast Jacklynberg, IN 45479	2011-12-09	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
143	Austin	717675297708	863-706-9225	Coating Machine Operator	1974-04-30	Bachelor	Willa	080399751011	+1-346-630-1621	Extruding Machine Operator	Christian	106 Schimmel Court\nPort Bell, WV 86023-4595	1981-03-30	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
144	Valentin	507817757518	+16077327140	Typesetting Machine Operator	1972-11-18	Master	Dell	249266821617	1-351-210-5612	Agricultural Worker	Christian	870 Marlee Park\nStephenmouth, IN 71950-7755	1997-12-18	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
145	Winfield	037626885405	646-581-6582	Clinical Laboratory Technician	1979-09-14	Master	Troy	262892979486	+1 (913) 554-9263	Licensing Examiner and Inspector	Christian	51342 Dion Run\nRoweport, MS 39535	2010-03-01	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
146	Gerhard	130653010256	(959) 742-7228	Auxiliary Equipment Operator	1977-03-21	Master	Alek	306522245754	1-605-668-5800	Safety Engineer	Christian	799 Frank Cove\nRyanbury, UT 52767-2286	1980-06-04	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
147	Tommie	523042207878	1-262-474-4301	Paving Equipment Operator	1999-02-18	Bachelor	Annetta	985631678739	(703) 516-7984	Engineer	Christian	407 Rice Mount Suite 706\nDorianburgh, NV 51820	2006-05-31	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
148	Stanford	075761574649	+1 (574) 897-8488	Account Manager	2012-09-13	High School	Joany	787688829847	+1.646.577.5163	Anthropologist OR Archeologist	Christian	97896 Casey Pike Apt. 449\nKreigerborough, OR 50904	1971-05-23	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
149	Elisa	487564407231	+1.310.499.4547	Manager Tactical Operations	1970-06-12	High School	Dorcas	217247388348	1-775-338-4625	Fishery Worker	Muslim	86662 Isobel Tunnel Suite 886\nNew Brisa, WY 64235-0475	1987-10-23	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
150	Mervin	915599834701	1-865-281-6454	Rough Carpenter	2015-11-16	High School	Shanelle	835898992122	424.294.3334	Health Educator	Muslim	14613 Abbott Shoals Apt. 078\nNew Juliet, OR 71800	1975-01-26	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
151	Rey	014742827671	774.792.5152	Home Appliance Installer	1974-02-26	High School	Walker	582761001686	(661) 813-9530	Procurement Clerk	Christian	35788 Calista Oval Apt. 351\nTyshawnport, NM 02850	1997-07-10	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
152	Kaela	382210678191	+1 (847) 893-8652	Pipelayer	1986-08-25	Bachelor	Prince	052751691645	228-633-1715	Graduate Teaching Assistant	Christian	291 Esperanza Hill Suite 165\nNew Savannah, AR 37528-4038	1979-07-28	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
153	Aubrey	449393096180	(806) 557-2318	Structural Iron and Steel Worker	1979-09-10	High School	Boris	006991902718	1-248-580-0879	Environmental Engineer	Christian	53634 Beer Hills Apt. 208\nLake Jasonbury, KS 23597-6264	2003-10-24	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
154	Willard	361714155253	+13512927072	Construction Manager	1979-10-20	Master	Daryl	918260214197	1-601-226-9095	Artist	Christian	6172 Spinka Ports\nNorth Kyrafort, UT 45205	1976-10-21	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
155	Norval	546401295970	(740) 206-7073	Trainer	1999-11-26	High School	Virgil	425008558996	+1 (678) 880-3315	Forging Machine Setter	Christian	9270 Bechtelar Haven\nKossfurt, WA 24994	2021-09-22	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
156	Tianna	369390495525	(626) 675-1898	Mathematical Science Teacher	1972-04-07	Master	Abbey	241045027041	310.531.1518	Dishwasher	Christian	1763 Lauriane Streets Apt. 580\nNorth Euna, IA 65258-9839	2000-03-03	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
157	Dashawn	819008226835	1-785-540-0601	Furnace Operator	1986-12-21	Master	Griffin	285401248641	+1-220-259-6527	Library Assistant	Christian	509 McKenzie Port\nNew Daijaborough, DC 27375-4999	1975-04-09	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
158	Thelma	975556939879	850.414.4422	Surgical Technologist	2000-01-24	High School	Yoshiko	041398843848	347-806-6667	Food Tobacco Roasting	Christian	6113 Rafaela Path\nMcLaughlinport, DE 50116-6109	1979-08-26	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
159	Mason	622620576704	(406) 415-7588	Computer Scientist	2018-05-01	Bachelor	Roslyn	282189074069	731-863-2362	Waitress	Muslim	63893 Tressie Extension\nSchmelerfurt, TN 11036-4077	1971-08-22	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
160	Fermin	944005194920	626-944-7894	Credit Authorizer	2020-05-29	Bachelor	Liana	904031215826	(240) 952-9762	User Experience Manager	Christian	587 Virginia Passage Apt. 760\nWest Emelie, HI 62526	2019-06-08	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
161	Alan	868297783909	980-477-9129	Engineering Manager	2001-04-27	Bachelor	Laron	311091356300	570.449.3160	Veterinary Assistant OR Laboratory Animal Caretaker	Christian	9530 Joaquin Plains Suite 451\nNew Burniceville, OR 16256	1997-09-23	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
162	Andrew	441818828452	580-676-9277	Stevedore	1970-03-24	Bachelor	Tate	435759623524	+1-508-420-0982	Philosophy and Religion Teacher	Christian	941 Brown Landing Suite 771\nMonahanport, CO 06086	2008-05-24	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
163	Amie	937440934937	828.529.2334	Forging Machine Setter	2006-03-11	High School	Everardo	567769907775	+1.334.262.6841	Agricultural Product Grader Sorter	Muslim	623 Flavie Mill Suite 353\nPamelaburgh, UT 30523	2000-07-09	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
164	Hyman	004478198760	+12063431904	Psychiatric Technician	1981-11-10	Master	Geovanni	523544531545	1-680-276-7077	Artillery Officer	Muslim	1848 Jesus Divide Apt. 435\nNew Jenningsmouth, NH 77999	1973-11-15	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
165	Rogers	867432072341	570.661.2271	Business Manager	2022-09-30	Master	Sadye	063987272650	317-951-0391	Waiter	Muslim	3321 Bergnaum Squares Apt. 974\nKonopelskimouth, IL 75555	1991-07-07	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
166	Kaci	404273027166	+1 (820) 347-2783	Food Preparation and Serving Worker	1987-06-05	Master	Fritz	794050121000	619.657.4036	Multi-Media Artist	Muslim	564 Goyette Park Suite 434\nRamonaland, MT 29487	2016-07-24	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
167	Lia	086704280289	320-942-0639	CTO	2007-03-22	High School	Rocky	691975240006	(931) 602-9576	Marine Cargo Inspector	Muslim	956 Lucinda Village Apt. 453\nNew Amymouth, PA 24605-6089	2003-06-10	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
168	Zoe	079477112833	+1-534-338-2612	Historian	1980-09-23	Bachelor	Josiane	864588962354	(682) 540-1711	Construction Manager	Muslim	624 Bosco Meadow\nEast Bruceberg, ND 07937-8823	2009-06-25	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
169	Flossie	891034214068	989-720-8012	Rental Clerk	1970-12-24	Bachelor	Emmie	618447223779	1-484-624-4929	Shoe and Leather Repairer	Christian	6603 Haley Manors Apt. 322\nPort Theresia, OH 03981-0207	1995-03-11	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
170	Freida	623480170462	+1-254-837-6552	Data Processing Equipment Repairer	2019-11-12	Bachelor	Hulda	258701620207	1-605-369-5907	Chemical Equipment Controller	Muslim	752 Judah Island\nNorth Mollyburgh, MA 21314	1973-12-02	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
171	Kathryne	843433070634	805.693.9491	Electrical and Electronics Drafter	1992-09-14	Bachelor	Orpha	629533691811	1-541-850-5782	Instructional Coordinator	Christian	1804 Ruth Trace Suite 840\nPort Katherinechester, IN 24282	1979-09-14	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
172	Zoe	303501463532	1-743-526-1804	Industrial Engineering Technician	2023-04-27	High School	Lupe	655736626413	850.218.9179	Deburring Machine Operator	Christian	58386 Kameron Stream\nTorpmouth, MI 37796-4045	1984-01-03	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
173	Jeanne	895608787876	(740) 271-7277	Cartoonist	1973-01-08	Master	Simone	598976610401	+19369075186	Product Management Leader	Christian	51081 Robel Trail Suite 065\nScottyfurt, RI 93789-1279	2000-02-07	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
174	Alfred	521779824085	(707) 477-4488	Office Machine and Cash Register Servicer	1978-07-17	High School	Joannie	629503738019	+1.617.354.1223	Alteration Tailor	Muslim	751 Johnny Point Apt. 627\nSouth Abigalemouth, VA 33697-0729	1970-04-20	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
175	Virgil	098078990773	+1 (754) 302-3757	Loan Interviewer	1997-03-27	High School	Agustina	870337227558	+13234428204	Sheriff	Christian	42640 August Loop Suite 432\nLake Luther, IN 27218-0784	1999-07-16	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
176	Carol	165018352726	+1-430-662-0015	Petroleum Technician	1992-02-28	Master	Mellie	002118924636	+1.430.820.9841	Bill and Account Collector	Christian	42927 Hertha Spur\nTristianport, ME 65873	1974-07-07	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
177	Katelynn	124049809154	1-909-387-3631	Avionics Technician	1982-01-15	Master	Norwood	791419952539	+1 (270) 719-8314	Architecture Teacher	Muslim	93294 Zemlak Ville Suite 484\nKulasville, NJ 61598	2016-05-12	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
178	Gaston	342203749613	+1-339-552-6150	Home Economics Teacher	2019-05-13	Bachelor	Karl	775299361881	+14846942478	Graphic Designer	Christian	3725 Kuhn Estates\nEast Janeview, MD 91999	2017-06-05	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
179	Vivien	663502561179	828.881.7681	Pipelayer	1987-10-14	High School	Alejandrin	288435990652	1-848-939-4335	Funeral Attendant	Muslim	46448 Hermina Grove Suite 744\nOndrickachester, NV 23872-0754	2015-11-06	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
180	Alan	492814745474	1-562-480-5371	Flight Attendant	2005-04-18	Master	Quinten	129421748868	484-746-1348	Space Sciences Teacher	Muslim	71672 Brekke Greens\nLake Madilyn, GA 94176-3026	2005-03-30	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
181	Estella	352123801638	+1-838-409-8259	Historian	1987-06-09	Bachelor	Anibal	584302028118	+1.984.274.7124	Machinery Maintenance	Christian	5027 Rodolfo Squares Apt. 610\nFadelborough, CA 71903-0542	1997-12-01	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
182	Kenyon	364513620616	+1.425.565.8330	Highway Maintenance Worker	1992-01-01	Master	Hunter	002757482713	+1-912-583-9085	Personal Home Care Aide	Muslim	5474 Morar Motorway\nPort Sanfordside, FL 81336-8236	1984-07-26	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
183	Morton	434382331473	+18782121532	Janitorial Supervisor	2010-12-22	High School	Alfred	275836667251	+1.906.735.7961	Highway Patrol Pilot	Christian	25399 Smith Corner Apt. 420\nEast Brendenberg, MN 54086-8637	2010-07-08	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
184	Leopold	567599852370	+16512689313	Electrical Sales Representative	1989-03-31	Bachelor	Francesca	520437772990	1-475-517-6624	Pantograph Engraver	Christian	88044 Bins Ferry Suite 773\nRunteborough, UT 40089-2861	1981-06-07	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
185	Claudine	978715304997	+14802714248	Heating and Air Conditioning Mechanic	2010-08-11	Master	Rebecca	556581166123	820.204.2239	Production Planning	Christian	97904 Ward Canyon Apt. 791\nNew Ransom, OK 39555	2022-05-13	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
186	Sanford	538354857587	559.764.4101	RN	2015-10-13	High School	Haylie	557934511951	+1.620.481.0263	Elevator Installer and Repairer	Christian	61594 Abbott Square Apt. 176\nDuBuqueport, NC 56441	1991-11-08	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
187	Haleigh	650356175605	720-419-5168	Drywall Installer	1981-04-13	Master	Alek	567049578678	+1-763-949-5592	Precision Dyer	Christian	41403 Jazmyne Parkways\nWest Vivianestad, NC 18585-7947	1992-11-07	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
188	Karlie	843420394332	+19843299077	Auditor	1995-10-29	Bachelor	Cale	454576728201	(341) 416-1397	Central Office Operator	Christian	672 Konopelski Crescent\nSouth Sierra, ME 45119-1113	1970-08-06	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
189	Jamey	338733460471	520-281-3070	Entertainer and Performer	2011-08-11	Bachelor	Gladyce	681094827591	463.514.0339	Animal Scientist	Muslim	19374 Cormier Alley\nLake Marilynetown, NC 35107-3352	1992-06-20	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
190	Rahsaan	209096680366	+1 (319) 795-7360	Materials Engineer	2018-03-07	High School	Miracle	103879362550	325.684.5294	Roofer	Christian	51144 Maudie Vista Suite 609\nLake Dominic, CT 16996-2931	2010-03-12	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
191	Margie	529474515469	(630) 798-9560	Internist	2021-08-08	High School	Gregg	082004759804	+1-708-792-0951	Adjustment Clerk	Christian	457 Dallin Fords\nAmericoton, MI 20721-5312	2000-04-04	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
192	Claudia	929859671887	+1-701-895-7595	Credit Authorizer	1979-08-14	Bachelor	Darius	966024784815	518-799-1108	Athletic Trainer	Muslim	95863 Joel Pine Apt. 077\nBerniefurt, WI 91888	1979-03-13	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
193	Camron	088764956439	+14754185099	Social Scientists	1991-02-10	High School	Laurianne	484149160992	+1-662-833-1570	Secretary	Muslim	7292 Towne Street Suite 358\nSeamusmouth, RI 69532-3376	1993-01-30	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
194	Matt	068925464640	+19728300657	Grinding Machine Operator	1974-01-25	Master	Waylon	947771409541	1-330-404-2309	Stationary Engineer OR Boiler Operator	Christian	5812 Mortimer Well\nLake Bennie, UT 23409	2010-02-09	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
195	Brant	524749017265	563.391.6407	Mail Clerk	1994-04-01	Master	Rusty	879497080727	+1 (757) 586-2309	Conservation Scientist	Christian	515 Sauer Courts Apt. 820\nNew General, IN 08726	1977-05-22	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
196	Jules	934955359263	(631) 456-7114	Electronic Engineering Technician	1971-05-18	Bachelor	Noemy	731082303523	+1 (820) 703-6822	Computer Support Specialist	Christian	23153 Destinee Avenue Apt. 327\nWendellmouth, UT 97260	1978-11-08	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
197	Nathen	542600979513	716.359.6905	Precision Aircraft Systems Assemblers	1999-10-19	High School	Armando	085344949147	+1-848-458-7363	Medical Transcriptionist	Muslim	54762 Coralie Ferry Suite 915\nNew Randalmouth, MA 05717-3774	2008-03-15	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
198	Davion	103595229628	951.859.8876	Assembler	1987-01-30	High School	Dock	518824281604	281-638-7666	Title Abstractor	Muslim	35574 Marlon Tunnel\nWest Lillianaport, NJ 83425	1989-01-30	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
199	Woodrow	543659525610	1-617-348-2438	Logging Equipment Operator	1990-10-31	Master	Anthony	198974851582	+1-769-551-2800	Private Detective and Investigator	Christian	7143 Fidel Lodge Apt. 062\nRasheedmouth, CA 18936-1289	2022-03-15	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
200	Annetta	149628466696	725.559.2427	Food Service Manager	1974-01-04	Master	Margaret	539817285879	+1-954-702-9146	Fast Food Cook	Christian	22057 Cayla Corners\nNorth Tracy, SD 50584	1999-03-03	1	\N	2024-04-07 20:27:19	2024-04-07 20:27:19
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pulse_aggregates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pulse_aggregates (id, bucket, period, type, key, aggregate, value, count) FROM stdin;
1	1712514720	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2	1712514600	360	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
3	1712514240	1440	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
4	1712511360	10080	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
17	1712514720	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2973.00	\N
18	1712514600	360	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2973.00	\N
19	1712514240	1440	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2973.00	\N
20	1712511360	10080	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2973.00	\N
21	1712514720	60	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	1.00	\N
22	1712514600	360	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	1.00	\N
5	1712514720	60	slow_user_request	1	count	2.00	\N
222	1712515680	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
8	1712511360	10080	slow_user_request	1	count	31.00	\N
197	1712515500	60	user_request	1	count	1.00	\N
9	1712514720	60	user_request	1	count	2.00	\N
23	1712514240	1440	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	2.00	\N
24	1712511360	10080	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	2.00	\N
13	1712514720	60	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	2.00	\N
14	1712514600	360	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	2.00	\N
16	1712511360	10080	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	4.00	\N
39	1712514240	1440	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	1798.00	\N
37	1712514720	60	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	1532.00	\N
38	1712514600	360	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	1532.00	\N
41	1712514780	60	slow_request	["GET","\\/ar\\/school_fees","Closure"]	count	1.00	\N
42	1712514600	360	slow_request	["GET","\\/ar\\/school_fees","Closure"]	count	1.00	\N
43	1712514240	1440	slow_request	["GET","\\/ar\\/school_fees","Closure"]	count	1.00	\N
44	1712511360	10080	slow_request	["GET","\\/ar\\/school_fees","Closure"]	count	1.00	\N
45	1712514780	60	slow_user_request	1	count	1.00	\N
6	1712514600	360	slow_user_request	1	count	3.00	\N
201	1712515500	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1466.00	\N
49	1712514780	60	user_request	1	count	1.00	\N
10	1712514600	360	user_request	1	count	3.00	\N
12	1712511360	10080	user_request	1	count	49.00	\N
80	1712511360	10080	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	5090.00	\N
53	1712514780	60	exception	["ReflectionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Routing\\\\RouteSignatureParameters.php:27"]	count	1.00	\N
54	1712514600	360	exception	["ReflectionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Routing\\\\RouteSignatureParameters.php:27"]	count	1.00	\N
55	1712514240	1440	exception	["ReflectionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Routing\\\\RouteSignatureParameters.php:27"]	count	1.00	\N
56	1712511360	10080	exception	["ReflectionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Routing\\\\RouteSignatureParameters.php:27"]	count	1.00	\N
57	1712514780	60	slow_request	["GET","\\/ar\\/school_fees","Closure"]	max	1814.00	\N
58	1712514600	360	slow_request	["GET","\\/ar\\/school_fees","Closure"]	max	1814.00	\N
59	1712514240	1440	slow_request	["GET","\\/ar\\/school_fees","Closure"]	max	1814.00	\N
60	1712511360	10080	slow_request	["GET","\\/ar\\/school_fees","Closure"]	max	1814.00	\N
15	1712514240	1440	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	4.00	\N
40	1712511360	10080	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	1798.00	\N
7	1712514240	1440	slow_user_request	1	count	10.00	\N
11	1712514240	1440	user_request	1	count	17.00	\N
166	1712515320	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2227.00	\N
79	1712514240	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2227.00	\N
221	1712515920	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
189	1712515500	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
193	1712515500	60	slow_user_request	1	count	1.00	\N
61	1712514780	60	exception	["ReflectionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Routing\\\\RouteSignatureParameters.php:27"]	max	1712514782.00	\N
62	1712514600	360	exception	["ReflectionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Routing\\\\RouteSignatureParameters.php:27"]	max	1712514782.00	\N
63	1712514240	1440	exception	["ReflectionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Routing\\\\RouteSignatureParameters.php:27"]	max	1712514782.00	\N
64	1712511360	10080	exception	["ReflectionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Routing\\\\RouteSignatureParameters.php:27"]	max	1712514782.00	\N
65	1712514960	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
69	1712514960	60	slow_user_request	1	count	1.00	\N
73	1712514960	60	user_request	1	count	1.00	\N
77	1712514960	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1003.00	\N
68	1712511360	10080	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	23.00	\N
81	1712515140	60	user_request	1	count	2.00	\N
89	1712515200	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
66	1712514960	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
150	1712515320	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	4.00	\N
67	1712514240	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	6.00	\N
153	1712515320	60	slow_user_request	1	count	1.00	\N
101	1712515200	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1216.00	\N
78	1712514960	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1216.00	\N
177	1712515380	60	slow_user_request	1	count	1.00	\N
157	1712515320	60	user_request	1	count	1.00	\N
161	1712515320	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\card.blade.php"]	count	1.00	\N
162	1712515320	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\card.blade.php"]	count	1.00	\N
117	1712515200	60	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	1.00	\N
118	1712514960	360	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	1.00	\N
93	1712515200	60	slow_user_request	1	count	2.00	\N
70	1712514960	360	slow_user_request	1	count	3.00	\N
163	1712514240	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\card.blade.php"]	count	1.00	\N
164	1712511360	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\card.blade.php"]	count	1.00	\N
113	1712515200	60	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	2.00	\N
114	1712514960	360	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	2.00	\N
133	1712515200	60	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	1798.00	\N
134	1712514960	360	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	1798.00	\N
97	1712515200	60	user_request	1	count	5.00	\N
165	1712515320	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2227.00	\N
141	1712515260	60	user_request	1	count	2.00	\N
74	1712514960	360	user_request	1	count	10.00	\N
149	1712515320	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
169	1712515320	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\card.blade.php"]	max	1712515358.00	\N
170	1712515320	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\card.blade.php"]	max	1712515358.00	\N
171	1712514240	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\card.blade.php"]	max	1712515358.00	\N
172	1712511360	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\card.blade.php"]	max	1712515358.00	\N
173	1712515380	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
209	1712515560	60	slow_user_request	1	count	1.00	\N
181	1712515380	60	user_request	1	count	1.00	\N
154	1712515320	360	slow_user_request	1	count	4.00	\N
185	1712515380	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1129.00	\N
213	1712515560	60	user_request	1	count	1.00	\N
205	1712515560	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
158	1712515320	360	user_request	1	count	4.00	\N
217	1712515560	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1409.00	\N
225	1712515920	60	slow_user_request	1	count	1.00	\N
229	1712515920	60	user_request	1	count	1.00	\N
233	1712515920	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	1.00	\N
237	1712515920	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	5090.00	\N
241	1712515920	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712515951.00	\N
294	1712516040	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
301	1712516040	60	user_request	1	count	1.00	\N
582	1712518560	360	user_request	1	count	2.00	\N
305	1712516040	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1054.00	\N
257	1712515980	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	1.00	\N
234	1712515680	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	2.00	\N
231	1712515680	1440	user_request	1	count	13.00	\N
236	1712511360	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	4.00	\N
223	1712515680	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	6.00	\N
265	1712515980	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712516003.00	\N
242	1712515680	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712516003.00	\N
577	1712518680	60	slow_user_request	1	count	1.00	\N
298	1712516040	360	slow_user_request	1	count	4.00	\N
245	1712515980	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
578	1712518560	360	slow_user_request	1	count	1.00	\N
249	1712515980	60	slow_user_request	1	count	2.00	\N
226	1712515680	360	slow_user_request	1	count	3.00	\N
317	1712516220	60	slow_user_request	1	count	1.00	\N
253	1712515980	60	user_request	1	count	2.00	\N
230	1712515680	360	user_request	1	count	3.00	\N
302	1712516040	360	user_request	1	count	7.00	\N
281	1712516040	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\drop-down_-table.blade.php"]	count	1.00	\N
282	1712516040	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\drop-down_-table.blade.php"]	count	1.00	\N
283	1712515680	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\drop-down_-table.blade.php"]	count	1.00	\N
284	1712511360	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\drop-down_-table.blade.php"]	count	1.00	\N
261	1712515980	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2741.00	\N
238	1712515680	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	5090.00	\N
289	1712516040	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\drop-down_-table.blade.php"]	max	1712516040.00	\N
290	1712516040	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\drop-down_-table.blade.php"]	max	1712516040.00	\N
291	1712515680	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\drop-down_-table.blade.php"]	max	1712516040.00	\N
292	1712511360	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\drop-down_-table.blade.php"]	max	1712516040.00	\N
293	1712516040	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
581	1712518680	60	user_request	1	count	1.00	\N
297	1712516040	60	slow_user_request	1	count	1.00	\N
309	1712516100	60	user_request	1	count	1.00	\N
313	1712516220	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
321	1712516220	60	user_request	1	count	1.00	\N
579	1712518560	1440	slow_user_request	1	count	5.00	\N
325	1712516220	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1004.00	\N
227	1712515680	1440	slow_user_request	1	count	9.00	\N
585	1712518680	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1079.00	\N
586	1712518560	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1079.00	\N
235	1712515680	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	3.00	\N
692	1712521440	10080	user_request	1	count	9.00	\N
589	1712518860	60	user_request	1	count	1.00	\N
583	1712518560	1440	user_request	1	count	8.00	\N
587	1712518560	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1502.00	\N
741	1712522040	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	1.00	\N
939	1712652480	1440	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1233.00	\N
329	1712516280	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
333	1712516280	60	slow_user_request	1	count	1.00	\N
341	1712516280	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	1.00	\N
342	1712516040	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	1.00	\N
345	1712516280	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2275.00	\N
306	1712516040	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2275.00	\N
239	1712515680	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	5090.00	\N
349	1712516280	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712516299.00	\N
350	1712516040	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712516299.00	\N
243	1712515680	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712516299.00	\N
337	1712516280	60	user_request	1	count	2.00	\N
361	1712516340	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
362	1712516040	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
365	1712516340	60	slow_user_request	1	count	1.00	\N
357	1712516340	60	user_request	1	count	2.00	\N
373	1712516340	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1171.00	\N
374	1712516040	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1171.00	\N
377	1712516520	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
429	1712517660	60	user_request	1	count	2.00	\N
415	1712517120	1440	user_request	1	count	11.00	\N
381	1712516520	60	slow_user_request	1	count	1.00	\N
385	1712516520	60	user_request	1	count	1.00	\N
389	1712516520	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1730.00	\N
421	1712517660	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
393	1712516580	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
378	1712516400	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
363	1712515680	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
364	1712511360	10080	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
397	1712516580	60	slow_user_request	1	count	1.00	\N
382	1712516400	360	slow_user_request	1	count	2.00	\N
401	1712516580	60	user_request	1	count	1.00	\N
386	1712516400	360	user_request	1	count	2.00	\N
405	1712516580	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1218.00	\N
390	1712516400	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1730.00	\N
375	1712515680	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1730.00	\N
376	1712511360	10080	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1730.00	\N
409	1712517060	60	user_request	1	count	1.00	\N
410	1712516760	360	user_request	1	count	1.00	\N
413	1712517540	60	user_request	1	count	1.00	\N
417	1712517600	60	user_request	1	count	1.00	\N
425	1712517660	60	slow_user_request	1	count	1.00	\N
422	1712517480	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
427	1712517120	1440	slow_user_request	1	count	7.00	\N
433	1712517660	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2212.00	\N
423	1712517120	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	8.00	\N
441	1712517780	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
445	1712517780	60	slow_user_request	1	count	1.00	\N
426	1712517480	360	slow_user_request	1	count	2.00	\N
449	1712517780	60	user_request	1	count	1.00	\N
414	1712517480	360	user_request	1	count	5.00	\N
244	1712511360	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712518067.00	\N
453	1712517780	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	count	1.00	\N
454	1712517480	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	count	1.00	\N
457	1712517780	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3129.00	\N
434	1712517480	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3129.00	\N
461	1712517780	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	max	1712517813.00	\N
462	1712517480	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	max	1712517813.00	\N
477	1712517900	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	count	1.00	\N
478	1712517840	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	count	1.00	\N
455	1712517120	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	count	2.00	\N
456	1712511360	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	count	2.00	\N
562	1712518200	360	user_request	1	count	2.00	\N
485	1712517900	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	max	1712517923.00	\N
486	1712517840	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	max	1712517923.00	\N
463	1712517120	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	max	1712517923.00	\N
464	1712511360	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	max	1712517923.00	\N
465	1712517900	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
553	1712518260	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
469	1712517900	60	slow_user_request	1	count	2.00	\N
546	1712518200	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
473	1712517900	60	user_request	1	count	2.00	\N
557	1712518260	60	slow_user_request	1	count	1.00	\N
481	1712517900	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2844.00	\N
558	1712518200	360	slow_user_request	1	count	1.00	\N
561	1712518260	60	user_request	1	count	1.00	\N
505	1712518020	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
509	1712518020	60	slow_user_request	1	count	1.00	\N
565	1712518260	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1165.00	\N
513	1712518020	60	user_request	1	count	1.00	\N
550	1712518200	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2885.00	\N
517	1712518020	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	1.00	\N
518	1712517840	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	1.00	\N
519	1712517120	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	1.00	\N
521	1712518020	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2048.00	\N
435	1712517120	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3129.00	\N
525	1712518020	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712518067.00	\N
526	1712517840	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712518067.00	\N
527	1712517120	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712518067.00	\N
529	1712518140	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
466	1712517840	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	4.00	\N
533	1712518140	60	slow_user_request	1	count	1.00	\N
470	1712517840	360	slow_user_request	1	count	4.00	\N
537	1712518140	60	user_request	1	count	1.00	\N
474	1712517840	360	user_request	1	count	4.00	\N
541	1712518140	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1635.00	\N
482	1712517840	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2844.00	\N
569	1712518500	60	user_request	1	count	1.00	\N
545	1712518200	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
549	1712518200	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2885.00	\N
573	1712518680	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
574	1712518560	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
575	1712518560	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
593	1712519040	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
594	1712518920	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
597	1712519040	60	slow_user_request	1	count	1.00	\N
598	1712518920	360	slow_user_request	1	count	1.00	\N
601	1712519040	60	user_request	1	count	1.00	\N
602	1712518920	360	user_request	1	count	1.00	\N
605	1712519040	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1401.00	\N
606	1712518920	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1401.00	\N
609	1712519700	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
610	1712519640	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
621	1712519700	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1502.00	\N
622	1712519640	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1502.00	\N
625	1712519700	60	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	count	1.00	\N
613	1712519700	60	slow_user_request	1	count	2.00	\N
617	1712519700	60	user_request	1	count	2.00	\N
628	1712511360	10080	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	count	2.00	\N
637	1712519700	60	exception	["Illuminate\\\\Database\\\\QueryException","app\\\\Livewire\\\\SchoolFees.php:20"]	count	1.00	\N
638	1712519640	360	exception	["Illuminate\\\\Database\\\\QueryException","app\\\\Livewire\\\\SchoolFees.php:20"]	count	1.00	\N
639	1712518560	1440	exception	["Illuminate\\\\Database\\\\QueryException","app\\\\Livewire\\\\SchoolFees.php:20"]	count	1.00	\N
640	1712511360	10080	exception	["Illuminate\\\\Database\\\\QueryException","app\\\\Livewire\\\\SchoolFees.php:20"]	count	1.00	\N
641	1712519700	60	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	max	2170.00	\N
645	1712519700	60	exception	["Illuminate\\\\Database\\\\QueryException","app\\\\Livewire\\\\SchoolFees.php:20"]	max	1712519747.00	\N
646	1712519640	360	exception	["Illuminate\\\\Database\\\\QueryException","app\\\\Livewire\\\\SchoolFees.php:20"]	max	1712519747.00	\N
647	1712518560	1440	exception	["Illuminate\\\\Database\\\\QueryException","app\\\\Livewire\\\\SchoolFees.php:20"]	max	1712519747.00	\N
648	1712511360	10080	exception	["Illuminate\\\\Database\\\\QueryException","app\\\\Livewire\\\\SchoolFees.php:20"]	max	1712519747.00	\N
649	1712519700	60	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	count	1.00	\N
650	1712519640	360	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	count	1.00	\N
651	1712518560	1440	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	count	1.00	\N
652	1712511360	10080	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	count	1.00	\N
653	1712519700	60	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	max	1249.00	\N
654	1712519640	360	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	max	1249.00	\N
655	1712518560	1440	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	max	1249.00	\N
656	1712511360	10080	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	max	1249.00	\N
669	1712519760	60	slow_user_request	1	count	1.00	\N
665	1712519760	60	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	count	1.00	\N
626	1712519640	360	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	count	2.00	\N
627	1712518560	1440	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	count	2.00	\N
614	1712519640	360	slow_user_request	1	count	3.00	\N
657	1712519760	60	user_request	1	count	3.00	\N
618	1712519640	360	user_request	1	count	5.00	\N
677	1712519760	60	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	max	1065.00	\N
642	1712519640	360	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	max	2170.00	\N
643	1712518560	1440	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	max	2170.00	\N
644	1712511360	10080	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	max	2170.00	\N
681	1712521920	60	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	count	1.00	\N
682	1712521800	360	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	count	1.00	\N
683	1712521440	1440	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	count	1.00	\N
684	1712521440	10080	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	count	1.00	\N
685	1712521920	60	slow_user_request	1	count	1.00	\N
689	1712521920	60	user_request	1	count	1.00	\N
693	1712521920	60	exception	["Livewire\\\\Exceptions\\\\EventHandlerDoesNotExist","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportEvents\\\\SupportEvents.php:23"]	count	1.00	\N
694	1712521800	360	exception	["Livewire\\\\Exceptions\\\\EventHandlerDoesNotExist","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportEvents\\\\SupportEvents.php:23"]	count	1.00	\N
695	1712521440	1440	exception	["Livewire\\\\Exceptions\\\\EventHandlerDoesNotExist","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportEvents\\\\SupportEvents.php:23"]	count	1.00	\N
696	1712521440	10080	exception	["Livewire\\\\Exceptions\\\\EventHandlerDoesNotExist","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportEvents\\\\SupportEvents.php:23"]	count	1.00	\N
697	1712521920	60	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	max	1689.00	\N
698	1712521800	360	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	max	1689.00	\N
699	1712521440	1440	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	max	1689.00	\N
700	1712521440	10080	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	max	1689.00	\N
701	1712521920	60	exception	["Livewire\\\\Exceptions\\\\EventHandlerDoesNotExist","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportEvents\\\\SupportEvents.php:23"]	max	1712521948.00	\N
702	1712521800	360	exception	["Livewire\\\\Exceptions\\\\EventHandlerDoesNotExist","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportEvents\\\\SupportEvents.php:23"]	max	1712521948.00	\N
703	1712521440	1440	exception	["Livewire\\\\Exceptions\\\\EventHandlerDoesNotExist","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportEvents\\\\SupportEvents.php:23"]	max	1712521948.00	\N
704	1712521440	10080	exception	["Livewire\\\\Exceptions\\\\EventHandlerDoesNotExist","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportEvents\\\\SupportEvents.php:23"]	max	1712521948.00	\N
705	1712521980	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
709	1712521980	60	slow_user_request	1	count	1.00	\N
706	1712521800	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
708	1712521440	10080	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	8.00	\N
687	1712521440	1440	slow_user_request	1	count	9.00	\N
713	1712521980	60	user_request	1	count	1.00	\N
686	1712521800	360	slow_user_request	1	count	4.00	\N
688	1712521440	10080	slow_user_request	1	count	9.00	\N
691	1712521440	1440	user_request	1	count	9.00	\N
717	1712521980	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	1.00	\N
721	1712521980	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2505.00	\N
725	1712521980	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712521982.00	\N
729	1712522040	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
733	1712522040	60	slow_user_request	1	count	1.00	\N
737	1712522040	60	user_request	1	count	1.00	\N
690	1712521800	360	user_request	1	count	4.00	\N
707	1712521440	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	8.00	\N
745	1712522040	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2372.00	\N
749	1712522040	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712522081.00	\N
753	1712522100	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
757	1712522100	60	slow_user_request	1	count	1.00	\N
761	1712522100	60	user_request	1	count	1.00	\N
765	1712522100	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	1.00	\N
718	1712521800	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	3.00	\N
793	1712522160	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3019.00	\N
769	1712522100	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2116.00	\N
722	1712521800	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2505.00	\N
853	1712522280	60	slow_user_request	1	count	1.00	\N
773	1712522100	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712522135.00	\N
726	1712521800	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712522135.00	\N
797	1712522160	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712522218.00	\N
857	1712522280	60	user_request	1	count	1.00	\N
778	1712522160	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	5.00	\N
829	1712522220	60	slow_user_request	1	count	1.00	\N
782	1712522160	360	slow_user_request	1	count	5.00	\N
833	1712522220	60	user_request	1	count	1.00	\N
786	1712522160	360	user_request	1	count	5.00	\N
837	1712522220	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	1.00	\N
777	1712522160	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
781	1712522160	60	slow_user_request	1	count	2.00	\N
861	1712522280	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	1.00	\N
785	1712522160	60	user_request	1	count	2.00	\N
790	1712522160	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	4.00	\N
789	1712522160	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	2.00	\N
719	1712521440	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	7.00	\N
720	1712521440	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	7.00	\N
865	1712522280	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2883.00	\N
825	1712522220	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
794	1712522160	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3019.00	\N
723	1712521440	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3019.00	\N
724	1712521440	10080	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3019.00	\N
841	1712522220	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2889.00	\N
845	1712522220	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712522258.00	\N
849	1712522280	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
869	1712522280	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712522292.00	\N
798	1712522160	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712522292.00	\N
727	1712521440	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712522292.00	\N
728	1712521440	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712522292.00	\N
873	1712522340	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
877	1712522340	60	slow_user_request	1	count	1.00	\N
881	1712522340	60	user_request	1	count	1.00	\N
885	1712522340	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1525.00	\N
889	1712652660	60	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
890	1712652480	360	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
891	1712652480	1440	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
892	1712652480	10080	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
893	1712652660	60	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	13592.00	\N
894	1712652480	360	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	13592.00	\N
895	1712652480	1440	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	13592.00	\N
896	1712652480	10080	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	13592.00	\N
897	1712652660	60	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	1.00	\N
898	1712652480	360	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	1.00	\N
899	1712652480	1440	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	1.00	\N
900	1712652480	10080	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	1.00	\N
901	1712652660	60	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	2250.00	\N
902	1712652480	360	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	2250.00	\N
903	1712652480	1440	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	2250.00	\N
904	1712652480	10080	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	2250.00	\N
905	1712652720	60	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	1.00	\N
906	1712652480	360	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	1.00	\N
907	1712652480	1440	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	1.00	\N
908	1712652480	10080	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	1.00	\N
917	1712652720	60	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	3939.00	\N
918	1712652480	360	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	3939.00	\N
919	1712652480	1440	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	3939.00	\N
920	1712652480	10080	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	3939.00	\N
913	1712652720	60	user_request	1	count	8.00	\N
914	1712652480	360	user_request	1	count	14.00	\N
912	1712652480	10080	slow_user_request	1	count	32.00	\N
925	1712652720	60	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	1.00	\N
926	1712652480	360	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	1.00	\N
927	1712652480	1440	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	1.00	\N
928	1712652480	10080	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	1.00	\N
909	1712652720	60	slow_user_request	1	count	6.00	\N
910	1712652480	360	slow_user_request	1	count	8.00	\N
911	1712652480	1440	slow_user_request	1	count	14.00	\N
916	1712652480	10080	user_request	1	count	68.00	\N
915	1712652480	1440	user_request	1	count	29.00	\N
937	1712652720	60	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1233.00	\N
938	1712652480	360	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1233.00	\N
940	1712652480	10080	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1233.00	\N
957	1712652720	60	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
958	1712652480	360	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
969	1712652720	60	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1415.00	\N
970	1712652480	360	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1415.00	\N
973	1712652720	60	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
974	1712652480	360	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
985	1712652720	60	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1293.00	\N
986	1712652480	360	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1293.00	\N
941	1712652720	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
942	1712652480	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
943	1712652480	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
944	1712652480	10080	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
953	1712652720	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2081.00	\N
954	1712652480	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2081.00	\N
955	1712652480	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2081.00	\N
956	1712652480	10080	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2081.00	\N
1078	1712652840	360	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
1021	1712652780	60	slow_user_request	1	count	2.00	\N
1017	1712652780	60	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	2.00	\N
1018	1712652480	360	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	2.00	\N
959	1712652480	1440	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
1029	1712652780	60	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	1295.00	\N
1030	1712652480	360	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	1295.00	\N
960	1712652480	10080	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
1009	1712652780	60	user_request	1	count	6.00	\N
1057	1712652900	60	user_request	1	count	1.00	\N
1061	1712652960	60	user_request	1	count	2.00	\N
1093	1712653020	60	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
975	1712652480	1440	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
976	1712652480	10080	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
1077	1712653020	60	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1082	1712652840	360	slow_user_request	1	count	6.00	\N
1058	1712652840	360	user_request	1	count	11.00	\N
1019	1712652480	1440	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	3.00	\N
1020	1712652480	10080	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	3.00	\N
1089	1712653020	60	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1042.00	\N
1094	1712652840	360	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1081	1712653020	60	slow_user_request	1	count	2.00	\N
1069	1712653020	60	user_request	1	count	4.00	\N
1090	1712652840	360	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1165.00	\N
1105	1712653020	60	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1227.00	\N
1106	1712652840	360	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1227.00	\N
1031	1712652480	1440	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	1295.00	\N
1032	1712652480	10080	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	1295.00	\N
971	1712652480	1440	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1415.00	\N
987	1712652480	1440	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1293.00	\N
988	1712652480	10080	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1293.00	\N
1109	1712653080	60	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	1.00	\N
1110	1712652840	360	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	1.00	\N
1121	1712653080	60	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	1004.00	\N
1122	1712652840	360	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	1004.00	\N
1125	1712653080	60	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1198	1712653920	360	user_request	1	count	2.00	\N
1137	1712653080	60	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1165.00	\N
972	1712652480	10080	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1415.00	\N
1209	1712654400	60	user_request	1	count	1.00	\N
1141	1712653080	60	slow_request	["POST","\\/ar\\/class_rooms","via \\/ar\\/livewire\\/update"]	count	2.00	\N
1142	1712652840	360	slow_request	["POST","\\/ar\\/class_rooms","via \\/ar\\/livewire\\/update"]	count	2.00	\N
1143	1712652480	1440	slow_request	["POST","\\/ar\\/class_rooms","via \\/ar\\/livewire\\/update"]	count	2.00	\N
1144	1712652480	10080	slow_request	["POST","\\/ar\\/class_rooms","via \\/ar\\/livewire\\/update"]	count	2.00	\N
1113	1712653080	60	slow_user_request	1	count	4.00	\N
1117	1712653080	60	user_request	1	count	4.00	\N
1153	1712653080	60	slow_request	["POST","\\/ar\\/class_rooms","via \\/ar\\/livewire\\/update"]	max	1331.00	\N
1154	1712652840	360	slow_request	["POST","\\/ar\\/class_rooms","via \\/ar\\/livewire\\/update"]	max	1331.00	\N
1155	1712652480	1440	slow_request	["POST","\\/ar\\/class_rooms","via \\/ar\\/livewire\\/update"]	max	1331.00	\N
1156	1712652480	10080	slow_request	["POST","\\/ar\\/class_rooms","via \\/ar\\/livewire\\/update"]	max	1331.00	\N
1173	1712653560	60	user_request	1	count	2.00	\N
1233	1712655000	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	1.00	\N
1213	1712654460	60	user_request	1	count	1.00	\N
1181	1712653800	60	user_request	1	count	2.00	\N
1174	1712653560	360	user_request	1	count	4.00	\N
1189	1712653980	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1190	1712653920	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1193	1712653980	60	slow_user_request	1	count	1.00	\N
1194	1712653920	360	slow_user_request	1	count	1.00	\N
1197	1712653980	60	user_request	1	count	1.00	\N
1201	1712653980	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1452.00	\N
1202	1712653920	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1452.00	\N
1205	1712654040	60	user_request	1	count	1.00	\N
1210	1712654280	360	user_request	1	count	2.00	\N
1217	1712654940	60	user_request	1	count	1.00	\N
1218	1712654640	360	user_request	1	count	1.00	\N
1222	1712655000	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	6.00	\N
1221	1712655000	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1192	1712652480	10080	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	17.00	\N
1225	1712655000	60	slow_user_request	1	count	1.00	\N
1229	1712655000	60	user_request	1	count	1.00	\N
1237	1712655000	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1993.00	\N
1191	1712653920	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	7.00	\N
1226	1712655000	360	slow_user_request	1	count	6.00	\N
1195	1712653920	1440	slow_user_request	1	count	7.00	\N
1230	1712655000	360	user_request	1	count	9.00	\N
1199	1712653920	1440	user_request	1	count	14.00	\N
1241	1712655000	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712655026.00	\N
1257	1712655060	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	1.00	\N
1234	1712655000	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	2.00	\N
1235	1712653920	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	2.00	\N
1203	1712653920	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1993.00	\N
1370	1712657880	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
1265	1712655060	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712655063.00	\N
1242	1712655000	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712655063.00	\N
1243	1712653920	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712655063.00	\N
1245	1712655060	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
1249	1712655060	60	slow_user_request	1	count	2.00	\N
1253	1712655060	60	user_request	1	count	2.00	\N
1261	1712655060	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1856.00	\N
1369	1712657940	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1325	1712655240	60	user_request	1	count	3.00	\N
1341	1712655300	60	user_request	1	count	1.00	\N
1285	1712655120	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1289	1712655120	60	slow_user_request	1	count	1.00	\N
1293	1712655120	60	user_request	1	count	1.00	\N
1297	1712655120	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1096.00	\N
1345	1712657640	60	user_request	1	count	1.00	\N
1301	1712655180	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1305	1712655180	60	slow_user_request	1	count	1.00	\N
1309	1712655180	60	user_request	1	count	1.00	\N
1313	1712655180	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1075.00	\N
1373	1712657940	60	slow_user_request	1	count	1.00	\N
1317	1712655240	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1321	1712655240	60	slow_user_request	1	count	1.00	\N
1329	1712655240	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1037.00	\N
1238	1712655000	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1993.00	\N
1349	1712657820	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1350	1712657520	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1353	1712657820	60	slow_user_request	1	count	1.00	\N
1354	1712657520	360	slow_user_request	1	count	1.00	\N
1357	1712657820	60	user_request	1	count	1.00	\N
1346	1712657520	360	user_request	1	count	2.00	\N
1361	1712657820	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1024.00	\N
1362	1712657520	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1024.00	\N
1351	1712656800	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
1365	1712657880	60	user_request	1	count	1.00	\N
1377	1712657940	60	user_request	1	count	1.00	\N
1381	1712657940	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1122.00	\N
1374	1712657880	360	slow_user_request	1	count	2.00	\N
1355	1712656800	1440	slow_user_request	1	count	3.00	\N
1366	1712657880	360	user_request	1	count	3.00	\N
1347	1712656800	1440	user_request	1	count	5.00	\N
1385	1712658180	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1389	1712658180	60	slow_user_request	1	count	1.00	\N
1393	1712658180	60	user_request	1	count	1.00	\N
1397	1712658180	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	1.00	\N
1398	1712657880	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	1.00	\N
1399	1712656800	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	1.00	\N
1236	1712652480	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	count	3.00	\N
1401	1712658180	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2560.00	\N
1382	1712657880	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2560.00	\N
1363	1712656800	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2560.00	\N
1405	1712658180	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712658221.00	\N
1406	1712657880	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712658221.00	\N
1407	1712656800	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712658221.00	\N
1244	1712652480	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	max	1712658221.00	\N
1409	1712658240	60	user_request	1	count	1.00	\N
1413	1712658480	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1417	1712658480	60	slow_user_request	1	count	1.00	\N
1421	1712658480	60	user_request	1	count	1.00	\N
1450	1712658960	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
1457	1712659020	60	user_request	1	count	1.00	\N
1425	1712658480	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1053.00	\N
1429	1712658540	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1414	1712658240	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
1433	1712658540	60	slow_user_request	1	count	1.00	\N
1418	1712658240	360	slow_user_request	1	count	2.00	\N
1454	1712658960	360	slow_user_request	1	count	4.00	\N
1437	1712658540	60	user_request	1	count	1.00	\N
1410	1712658240	360	user_request	1	count	3.00	\N
1493	1712659200	60	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	count	1.00	\N
1441	1712658540	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1105.00	\N
1426	1712658240	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1105.00	\N
1473	1712659080	60	user_request	1	count	1.00	\N
1494	1712658960	360	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	count	1.00	\N
1445	1712658600	60	user_request	1	count	1.00	\N
1446	1712658600	360	user_request	1	count	1.00	\N
1495	1712658240	1440	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	count	1.00	\N
1449	1712659020	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1453	1712659020	60	slow_user_request	1	count	1.00	\N
1461	1712659020	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1059.00	\N
1415	1712658240	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	7.00	\N
1501	1712659200	60	user_request	1	count	1.00	\N
1465	1712659080	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1469	1712659080	60	slow_user_request	1	count	1.00	\N
1477	1712659080	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1042.00	\N
1481	1712659140	60	user_request	1	count	3.00	\N
1496	1712652480	10080	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	count	1.00	\N
1497	1712659200	60	slow_user_request	1	count	1.00	\N
1505	1712659200	60	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	max	1215.00	\N
1506	1712658960	360	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	max	1215.00	\N
1507	1712658240	1440	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	max	1215.00	\N
1508	1712652480	10080	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	max	1215.00	\N
1509	1712659260	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1513	1712659260	60	slow_user_request	1	count	1.00	\N
1521	1712659260	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1350.00	\N
1462	1712658960	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1350.00	\N
1517	1712659260	60	user_request	1	count	2.00	\N
1458	1712658960	360	user_request	1	count	8.00	\N
1529	1712659320	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1533	1712659320	60	slow_user_request	1	count	1.00	\N
1537	1712659320	60	user_request	1	count	1.00	\N
1541	1712659320	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1005.00	\N
1553	1712659380	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1530	1712659320	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
1557	1712659380	60	slow_user_request	1	count	1.00	\N
1534	1712659320	360	slow_user_request	1	count	2.00	\N
1419	1712658240	1440	slow_user_request	1	count	8.00	\N
1545	1712659380	60	user_request	1	count	3.00	\N
1656	1712682720	10080	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	4461.00	\N
1565	1712659380	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1311.00	\N
1542	1712659320	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1311.00	\N
1427	1712658240	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1350.00	\N
1204	1712652480	10080	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2560.00	\N
1569	1712659440	60	user_request	1	count	4.00	\N
1538	1712659320	360	user_request	1	count	8.00	\N
1411	1712658240	1440	user_request	1	count	20.00	\N
1586	1712659440	60	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	count	1.00	\N
1585	1712659440	60	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	count	1.00	\N
1587	1712659320	360	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	count	1.00	\N
1589	1712658240	1440	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	count	1.00	\N
1588	1712659320	360	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	count	1.00	\N
1590	1712658240	1440	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	count	1.00	\N
1592	1712652480	10080	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	count	1.00	\N
1594	1712659440	60	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	max	1402.00	\N
1596	1712659320	360	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	max	1402.00	\N
1598	1712658240	1440	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	max	1402.00	\N
1600	1712652480	10080	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	max	1402.00	\N
1591	1712652480	10080	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	count	1.00	\N
1593	1712659440	60	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	max	1457.00	\N
1595	1712659320	360	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	max	1457.00	\N
1597	1712658240	1440	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	max	1457.00	\N
1599	1712652480	10080	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	max	1457.00	\N
1601	1712683500	60	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
1602	1712683440	360	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
1603	1712682720	1440	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
1604	1712682720	10080	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
1605	1712683500	60	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	1765.00	\N
1606	1712683440	360	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	1765.00	\N
1607	1712682720	1440	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	1765.00	\N
1608	1712682720	10080	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	1765.00	\N
1609	1712683500	60	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	2.00	\N
1610	1712683440	360	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	2.00	\N
1611	1712682720	1440	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	2.00	\N
1612	1712682720	10080	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	2.00	\N
1613	1712683500	60	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	1745.00	\N
1614	1712683440	360	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	1745.00	\N
1615	1712682720	1440	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	1745.00	\N
1616	1712682720	10080	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	1745.00	\N
1642	1712683440	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
1644	1712682720	10080	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	14.00	\N
1863	1712688480	1440	slow_user_request	1	count	7.00	\N
1661	1712683680	60	slow_user_request	1	count	1.00	\N
1622	1712683440	360	slow_user_request	1	count	3.00	\N
1665	1712683680	60	user_request	1	count	1.00	\N
1641	1712683500	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1621	1712683500	60	slow_user_request	1	count	2.00	\N
1677	1712683860	60	slow_user_request	1	count	1.00	\N
1625	1712683500	60	user_request	1	count	4.00	\N
1862	1712688840	360	slow_user_request	1	count	3.00	\N
1681	1712683860	60	user_request	1	count	1.00	\N
1653	1712683500	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1365.00	\N
1657	1712683680	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1626	1712683440	360	user_request	1	count	5.00	\N
1669	1712683680	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1135.00	\N
1654	1712683440	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1365.00	\N
1678	1712683800	360	slow_user_request	1	count	3.00	\N
1623	1712682720	1440	slow_user_request	1	count	6.00	\N
1673	1712683860	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1674	1712683800	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
1643	1712682720	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	5.00	\N
1685	1712683860	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	count	1.00	\N
1686	1712683800	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	count	1.00	\N
1687	1712682720	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	count	1.00	\N
1688	1712682720	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	count	1.00	\N
1689	1712683860	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2683.00	\N
1682	1712683800	360	user_request	1	count	4.00	\N
1627	1712682720	1440	user_request	1	count	9.00	\N
1869	1712688840	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	count	1.00	\N
1870	1712688840	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	count	1.00	\N
1871	1712688480	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	count	1.00	\N
1693	1712683860	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	max	1712683871.00	\N
1694	1712683800	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	max	1712683871.00	\N
1695	1712682720	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	max	1712683871.00	\N
1696	1712682720	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	max	1712683871.00	\N
1697	1712683920	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1701	1712683920	60	slow_user_request	1	count	1.00	\N
1705	1712683920	60	user_request	1	count	1.00	\N
1709	1712683920	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1028.00	\N
1713	1712683980	60	user_request	1	count	1.00	\N
1717	1712684100	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1721	1712684100	60	slow_user_request	1	count	1.00	\N
1725	1712684100	60	user_request	1	count	1.00	\N
1729	1712684100	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\index.blade.php"]	count	1.00	\N
1730	1712683800	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\index.blade.php"]	count	1.00	\N
1731	1712682720	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\index.blade.php"]	count	1.00	\N
1733	1712684100	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2131.00	\N
1690	1712683800	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2683.00	\N
1655	1712682720	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2683.00	\N
1737	1712684100	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\index.blade.php"]	max	1712684150.00	\N
1738	1712683800	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\index.blade.php"]	max	1712684150.00	\N
1739	1712682720	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\index.blade.php"]	max	1712684150.00	\N
1741	1712684160	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1742	1712684160	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1743	1712684160	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1745	1712684160	60	slow_user_request	1	count	1.00	\N
1746	1712684160	360	slow_user_request	1	count	1.00	\N
1747	1712684160	1440	slow_user_request	1	count	1.00	\N
1753	1712684160	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1057.00	\N
1754	1712684160	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1057.00	\N
1755	1712684160	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1057.00	\N
1749	1712684160	60	user_request	1	count	2.00	\N
1750	1712684160	360	user_request	1	count	2.00	\N
1751	1712684160	1440	user_request	1	count	2.00	\N
1761	1712687820	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1765	1712687820	60	slow_user_request	1	count	1.00	\N
1769	1712687820	60	user_request	1	count	1.00	\N
1773	1712687820	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	count	1.00	\N
1777	1712687820	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2306.00	\N
1763	1712687040	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	4.00	\N
1766	1712687760	360	slow_user_request	1	count	4.00	\N
1767	1712687040	1440	slow_user_request	1	count	4.00	\N
1770	1712687760	360	user_request	1	count	4.00	\N
1771	1712687040	1440	user_request	1	count	4.00	\N
1732	1712682720	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\index.blade.php"]	count	2.00	\N
1740	1712682720	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\index.blade.php"]	max	1712688944.00	\N
1762	1712687760	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	4.00	\N
2110	1712693880	360	user_request	1	count	9.00	\N
1781	1712687820	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	max	1712687870.00	\N
1776	1712682720	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	count	5.00	\N
1784	1712682720	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	max	1712688864.00	\N
1857	1712688840	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
1785	1712687940	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
1789	1712687940	60	slow_user_request	1	count	2.00	\N
1793	1712687940	60	user_request	1	count	2.00	\N
1797	1712687940	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	count	2.00	\N
1861	1712688840	60	slow_user_request	1	count	2.00	\N
1801	1712687940	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2690.00	\N
1858	1712688840	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
1805	1712687940	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	max	1712687991.00	\N
1859	1712688480	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	4.00	\N
1833	1712688060	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1837	1712688060	60	slow_user_request	1	count	1.00	\N
1841	1712688060	60	user_request	1	count	1.00	\N
1845	1712688060	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	count	1.00	\N
1774	1712687760	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	count	4.00	\N
1775	1712687040	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	count	4.00	\N
1849	1712688060	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1771.00	\N
1778	1712687760	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2690.00	\N
1779	1712687040	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2690.00	\N
1853	1712688060	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	max	1712688069.00	\N
1782	1712687760	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	max	1712688069.00	\N
1783	1712687040	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	max	1712688069.00	\N
1877	1712688840	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	max	1712688864.00	\N
1878	1712688840	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	max	1712688864.00	\N
1879	1712688480	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	max	1712688864.00	\N
1865	1712688840	60	user_request	1	count	2.00	\N
1893	1712688840	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	count	1.00	\N
1894	1712688840	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	count	1.00	\N
1895	1712688480	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	count	1.00	\N
1896	1712682720	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	count	1.00	\N
1873	1712688840	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2503.00	\N
1973	1712689320	60	user_request	1	count	5.00	\N
1946	1712689200	360	user_request	1	count	7.00	\N
1901	1712688840	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	max	1712688895.00	\N
1902	1712688840	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	max	1712688895.00	\N
1903	1712688480	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	max	1712688895.00	\N
1904	1712682720	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	max	1712688895.00	\N
1905	1712688900	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1909	1712688900	60	slow_user_request	1	count	1.00	\N
1913	1712688900	60	user_request	1	count	1.00	\N
1949	1712689260	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1950	1712689200	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1953	1712689260	60	slow_user_request	1	count	1.00	\N
1917	1712688900	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\index.blade.php"]	count	1.00	\N
1918	1712688840	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\index.blade.php"]	count	1.00	\N
1919	1712688480	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\index.blade.php"]	count	1.00	\N
1921	1712688900	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	4461.00	\N
1874	1712688840	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	4461.00	\N
1867	1712688480	1440	user_request	1	count	14.00	\N
1925	1712688900	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\index.blade.php"]	max	1712688944.00	\N
1926	1712688840	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\index.blade.php"]	max	1712688944.00	\N
1927	1712688480	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\index.blade.php"]	max	1712688944.00	\N
1945	1712689260	60	user_request	1	count	2.00	\N
1929	1712688960	60	user_request	1	count	2.00	\N
1624	1712682720	10080	slow_user_request	1	count	18.00	\N
1937	1712689080	60	user_request	1	count	1.00	\N
1961	1712689260	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1326.00	\N
1962	1712689200	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1326.00	\N
1875	1712688480	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	4461.00	\N
1941	1712689140	60	user_request	1	count	1.00	\N
1866	1712688840	360	user_request	1	count	7.00	\N
1969	1712689320	60	slow_user_request	1	count	3.00	\N
1954	1712689200	360	slow_user_request	1	count	4.00	\N
1965	1712689320	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1966	1712689200	360	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1967	1712688480	1440	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1968	1712682720	10080	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
1981	1712689320	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1716.00	\N
2362	1712694600	360	slow_user_request	1	count	15.00	\N
2350	1712694600	360	user_request	1	count	17.00	\N
2481	1712694660	60	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	3189.00	\N
2482	1712694600	360	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	3189.00	\N
2483	1712694240	1440	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	3189.00	\N
2493	1712694660	60	user_request	1	count	5.00	\N
1982	1712689200	360	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1716.00	\N
1983	1712688480	1440	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1716.00	\N
1984	1712682720	10080	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1716.00	\N
2049	1712693760	60	user_request	1	count	2.00	\N
2075	1712692800	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
2085	1712693820	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1132.00	\N
1985	1712689320	60	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	2.00	\N
1986	1712689200	360	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	2.00	\N
1987	1712688480	1440	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	2.00	\N
1988	1712682720	10080	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	2.00	\N
2086	1712693520	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1132.00	\N
1977	1712689320	60	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	4.00	\N
1978	1712689200	360	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	4.00	\N
1979	1712688480	1440	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	4.00	\N
1980	1712682720	10080	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	4.00	\N
2001	1712689320	60	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	1747.00	\N
2002	1712689200	360	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	1747.00	\N
2003	1712688480	1440	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	1747.00	\N
2004	1712682720	10080	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	1747.00	\N
1628	1712682720	10080	user_request	1	count	29.00	\N
2037	1712693700	60	user_request	1	count	1.00	\N
2041	1712693760	60	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	count	1.00	\N
2045	1712693760	60	slow_user_request	1	count	1.00	\N
2130	1712693880	360	slow_user_request	1	count	4.00	\N
2053	1712693760	60	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	max	1299.00	\N
2125	1712693940	60	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	count	1.00	\N
2047	1712692800	1440	slow_user_request	1	count	7.00	\N
2093	1712693820	60	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	count	1.00	\N
2042	1712693520	360	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	count	2.00	\N
2077	1712693820	60	slow_user_request	1	count	2.00	\N
2046	1712693520	360	slow_user_request	1	count	3.00	\N
2039	1712692800	1440	user_request	1	count	18.00	\N
2061	1712693820	60	user_request	1	count	6.00	\N
2073	1712693820	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2074	1712693520	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2109	1712693880	60	user_request	1	count	3.00	\N
2076	1712692800	10080	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	5.00	\N
2038	1712693520	360	user_request	1	count	9.00	\N
2129	1712693940	60	slow_user_request	1	count	1.00	\N
2105	1712693820	60	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	max	1023.00	\N
2054	1712693520	360	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	max	1299.00	\N
2043	1712692800	1440	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	count	4.00	\N
2044	1712692800	10080	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	count	4.00	\N
2048	1712692800	10080	slow_user_request	1	count	30.00	\N
2087	1712692800	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1132.00	\N
2121	1712693940	60	user_request	1	count	2.00	\N
2126	1712693880	360	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	count	2.00	\N
2040	1712692800	10080	user_request	1	count	50.00	\N
2137	1712693940	60	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	max	1802.00	\N
2088	1712692800	10080	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1843.00	\N
2138	1712693880	360	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	max	1802.00	\N
2141	1712693940	60	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	count	1.00	\N
2142	1712693880	360	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	count	1.00	\N
2143	1712692800	1440	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	count	1.00	\N
2145	1712693940	60	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	max	1051.00	\N
2146	1712693880	360	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	max	1051.00	\N
2147	1712692800	1440	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	max	1051.00	\N
2149	1712694060	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2150	1712693880	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2153	1712694060	60	slow_user_request	1	count	1.00	\N
2157	1712694060	60	user_request	1	count	1.00	\N
2161	1712694060	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1040.00	\N
2162	1712693880	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1040.00	\N
2169	1712694120	60	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	count	1.00	\N
2173	1712694120	60	slow_user_request	1	count	1.00	\N
2165	1712694120	60	user_request	1	count	2.00	\N
2181	1712694120	60	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	max	1249.00	\N
2055	1712692800	1440	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	max	1802.00	\N
2056	1712692800	10080	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	max	1802.00	\N
2185	1712694180	60	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2186	1712693880	360	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2187	1712692800	1440	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2189	1712694180	60	slow_user_request	1	count	1.00	\N
2193	1712694180	60	user_request	1	count	1.00	\N
2197	1712694180	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	count	1.00	\N
2198	1712693880	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	count	1.00	\N
2199	1712692800	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	count	1.00	\N
2201	1712694180	60	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2842.00	\N
2202	1712693880	360	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2842.00	\N
2203	1712692800	1440	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2842.00	\N
2205	1712694180	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	max	1712694207.00	\N
2206	1712693880	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	max	1712694207.00	\N
2207	1712692800	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	max	1712694207.00	\N
2209	1712694300	60	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2210	1712694240	360	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2211	1712694240	1440	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2188	1712692800	10080	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
2213	1712694300	60	slow_user_request	1	count	1.00	\N
2217	1712694300	60	user_request	1	count	1.00	\N
2221	1712694300	60	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1253.00	\N
2222	1712694240	360	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1253.00	\N
2204	1712692800	10080	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2842.00	\N
2215	1712694240	1440	slow_user_request	1	count	23.00	\N
2144	1712692800	10080	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	count	4.00	\N
2214	1712694240	360	slow_user_request	1	count	5.00	\N
2148	1712692800	10080	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	max	1558.00	\N
2219	1712694240	1440	user_request	1	count	32.00	\N
2200	1712692800	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	count	2.00	\N
2218	1712694240	360	user_request	1	count	10.00	\N
2208	1712692800	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	max	1712694907.00	\N
2223	1712694240	1440	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1253.00	\N
2225	1712694420	60	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2237	1712694420	60	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1124.00	\N
2279	1712694240	1440	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	max	1558.00	\N
2245	1712694420	60	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	1.00	\N
2229	1712694420	60	slow_user_request	1	count	2.00	\N
2257	1712694420	60	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	1222.00	\N
2228	1712692800	10080	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
2233	1712694420	60	user_request	1	count	6.00	\N
2273	1712694420	60	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	count	1.00	\N
2274	1712694240	360	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	count	1.00	\N
2277	1712694420	60	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	max	1041.00	\N
2278	1712694240	360	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	max	1041.00	\N
2281	1712694480	60	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2226	1712694240	360	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
2292	1712692800	10080	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	9.00	\N
2295	1712694240	1440	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	2364.00	\N
2285	1712694480	60	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3973.00	\N
2238	1712694240	360	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3973.00	\N
2296	1712692800	10080	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	2364.00	\N
2289	1712694480	60	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	1.00	\N
2290	1712694240	360	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	1.00	\N
2293	1712694480	60	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	1407.00	\N
2294	1712694240	360	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	1407.00	\N
2297	1712694480	60	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	count	1.00	\N
2298	1712694240	360	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	count	1.00	\N
2299	1712694240	1440	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	count	1.00	\N
2300	1712692800	10080	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	count	1.00	\N
2239	1712694240	1440	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3973.00	\N
2240	1712692800	10080	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3973.00	\N
2246	1712694240	360	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	3.00	\N
2291	1712694240	1440	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	9.00	\N
2258	1712694240	360	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	1746.00	\N
2247	1712694240	1440	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	6.00	\N
2248	1712692800	10080	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	6.00	\N
2259	1712694240	1440	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	3089.00	\N
2260	1712692800	10080	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	3089.00	\N
2275	1712694240	1440	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	count	3.00	\N
2227	1712694240	1440	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
2301	1712694480	60	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	max	1466.00	\N
2302	1712694240	360	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	max	1466.00	\N
2303	1712694240	1440	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	max	1466.00	\N
2305	1712692800	10080	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	max	1466.00	\N
2304	1712694480	60	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	count	1.00	\N
2306	1712694240	360	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	count	1.00	\N
2307	1712694240	1440	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	count	1.00	\N
2308	1712692800	10080	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	count	1.00	\N
2309	1712694480	60	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	max	1477.00	\N
2310	1712694240	360	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	max	1477.00	\N
2311	1712694240	1440	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	max	1477.00	\N
2312	1712692800	10080	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	max	1477.00	\N
2313	1712694540	60	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	2.00	\N
2317	1712694540	60	slow_user_request	1	count	2.00	\N
2321	1712694540	60	user_request	1	count	3.00	\N
2325	1712694540	60	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	1746.00	\N
2373	1712694600	60	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	6.00	\N
2477	1712694660	60	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	2.00	\N
2413	1712694600	60	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	count	2.00	\N
2414	1712694600	360	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	count	2.00	\N
2417	1712694600	60	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	max	1558.00	\N
2418	1712694600	360	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	max	1558.00	\N
2377	1712694600	60	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	1756.00	\N
2478	1712694600	360	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	2.00	\N
2489	1712694660	60	slow_user_request	1	count	5.00	\N
2357	1712694600	60	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	3.00	\N
2358	1712694600	360	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	3.00	\N
2361	1712694600	60	slow_user_request	1	count	3.00	\N
2349	1712694600	60	user_request	1	count	5.00	\N
2469	1712694660	60	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	2.00	\N
2369	1712694600	60	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	3089.00	\N
2370	1712694600	360	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	3089.00	\N
2479	1712694240	1440	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	2.00	\N
2480	1712692800	10080	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	2.00	\N
2374	1712694600	360	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	8.00	\N
2473	1712694660	60	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	2364.00	\N
2378	1712694600	360	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	2364.00	\N
2484	1712692800	10080	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	3189.00	\N
2501	1712694660	60	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2502	1712694600	360	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2513	1712694660	60	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2119.00	\N
2514	1712694600	360	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2119.00	\N
2533	1712694660	60	slow_request	["GET","\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	1.00	\N
2534	1712694600	360	slow_request	["GET","\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	1.00	\N
2535	1712694240	1440	slow_request	["GET","\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	1.00	\N
2536	1712692800	10080	slow_request	["GET","\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	1.00	\N
2545	1712694660	60	slow_request	["GET","\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1008.00	\N
2546	1712694600	360	slow_request	["GET","\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1008.00	\N
2547	1712694240	1440	slow_request	["GET","\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1008.00	\N
2548	1712692800	10080	slow_request	["GET","\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1008.00	\N
2549	1712694660	60	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	1.00	\N
2550	1712694600	360	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	1.00	\N
2561	1712694660	60	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1061.00	\N
2562	1712694600	360	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1061.00	\N
2565	1712694720	60	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	count	1.00	\N
2566	1712694600	360	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	count	1.00	\N
2567	1712694240	1440	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	count	1.00	\N
2568	1712692800	10080	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	count	1.00	\N
2569	1712694720	60	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	max	2264.00	\N
2570	1712694600	360	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	max	2264.00	\N
2571	1712694240	1440	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	max	2264.00	\N
2572	1712692800	10080	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	max	2264.00	\N
2573	1712694720	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2574	1712694600	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2585	1712694720	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1843.00	\N
2586	1712694600	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1843.00	\N
2589	1712694720	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2590	1712694600	360	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
2591	1712694240	1440	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
2605	1712694720	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1797.00	\N
2577	1712694720	60	slow_user_request	1	count	3.00	\N
2581	1712694720	60	user_request	1	count	3.00	\N
2592	1712692800	10080	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
2606	1712694600	360	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	4636.00	\N
2551	1712694240	1440	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	2.00	\N
2552	1712692800	10080	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	2.00	\N
2563	1712694240	1440	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1242.00	\N
2564	1712692800	10080	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1242.00	\N
2575	1712694240	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
2587	1712694240	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1843.00	\N
2609	1712694720	60	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	1.00	\N
2601	1712694720	60	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	2.00	\N
2625	1712694720	60	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	1756.00	\N
2629	1712694840	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2669	1712694900	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
2670	1712694600	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
2671	1712694240	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
2645	1712694840	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	4636.00	\N
2607	1712694240	1440	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	4636.00	\N
2608	1712692800	10080	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	4636.00	\N
2649	1712694840	60	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	1.00	\N
2610	1712694600	360	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	2.00	\N
2611	1712694240	1440	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	2.00	\N
2612	1712692800	10080	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	2.00	\N
2633	1712694840	60	slow_user_request	1	count	2.00	\N
2637	1712694840	60	user_request	1	count	2.00	\N
2641	1712694840	60	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	2.00	\N
2602	1712694600	360	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	4.00	\N
2603	1712694240	1440	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	4.00	\N
2604	1712692800	10080	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	4.00	\N
2665	1712694840	60	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	2167.00	\N
2626	1712694600	360	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	2167.00	\N
2627	1712694240	1440	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	2167.00	\N
2628	1712692800	10080	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	2167.00	\N
2681	1712694900	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	count	1.00	\N
2682	1712694600	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	count	1.00	\N
2683	1712694240	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	count	1.00	\N
2689	1712694900	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	max	1712694907.00	\N
2690	1712694600	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	max	1712694907.00	\N
2672	1712692800	10080	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
2673	1712694900	60	slow_user_request	1	count	2.00	\N
2677	1712694900	60	user_request	1	count	2.00	\N
2685	1712694900	60	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3272.00	\N
2686	1712694600	360	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3272.00	\N
2687	1712694240	1440	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3272.00	\N
2688	1712692800	10080	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3272.00	\N
2793	1713220440	60	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	9492.00	\N
2791	1713219840	1440	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
2792	1713216960	10080	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
2794	1713220200	360	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	9492.00	\N
2795	1713219840	1440	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	9492.00	\N
2796	1713216960	10080	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	9492.00	\N
2947	1713373920	1440	slow_query	["select * from \\"grades\\" limit 1","Command line code:1"]	max	1420.00	\N
2948	1713368160	10080	slow_query	["select * from \\"grades\\" limit 1","Command line code:1"]	max	1420.00	\N
3415	1713558240	1440	exception	["Error","app\\\\Http\\\\Controllers\\\\HomeController.php:9"]	max	1713559391.00	\N
3416	1713549600	10080	exception	["Error","app\\\\Http\\\\Controllers\\\\HomeController.php:9"]	max	1713559391.00	\N
2691	1712694240	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	max	1712694907.00	\N
2709	1712694960	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2710	1712694960	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2713	1712694960	60	slow_user_request	1	count	1.00	\N
2717	1712694960	60	user_request	1	count	1.00	\N
2721	1712694960	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1228.00	\N
2722	1712694960	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1228.00	\N
2725	1712695140	60	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	1.00	\N
2726	1712694960	360	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	1.00	\N
2729	1712695140	60	slow_user_request	1	count	1.00	\N
2714	1712694960	360	slow_user_request	1	count	2.00	\N
2733	1712695140	60	user_request	1	count	1.00	\N
2994	1713555000	360	slow_user_request	1	count	4.00	\N
2737	1712695140	60	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1242.00	\N
2738	1712694960	360	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1242.00	\N
2741	1712695200	60	user_request	1	count	1.00	\N
2790	1713220200	360	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
2745	1712695260	60	user_request	1	count	1.00	\N
2718	1712694960	360	user_request	1	count	4.00	\N
2749	1712695440	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2750	1712695320	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2753	1712695440	60	slow_user_request	1	count	1.00	\N
2754	1712695320	360	slow_user_request	1	count	1.00	\N
2757	1712695440	60	user_request	1	count	1.00	\N
2758	1712695320	360	user_request	1	count	1.00	\N
2761	1712695440	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1049.00	\N
2762	1712695320	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1049.00	\N
2765	1713211020	60	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
2766	1713210840	360	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
2767	1713209760	1440	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
2768	1713206880	10080	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
2769	1713211020	60	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	12649.00	\N
2770	1713210840	360	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	12649.00	\N
2771	1713209760	1440	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	12649.00	\N
2772	1713206880	10080	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	12649.00	\N
2773	1713211020	60	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
2774	1713210840	360	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
2775	1713209760	1440	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
2776	1713206880	10080	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
2777	1713211020	60	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	2171.00	\N
2778	1713210840	360	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	2171.00	\N
2779	1713209760	1440	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	2171.00	\N
2780	1713206880	10080	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	2171.00	\N
2781	1713211020	60	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	1.00	\N
2782	1713210840	360	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	1.00	\N
2783	1713209760	1440	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	1.00	\N
2784	1713206880	10080	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	1.00	\N
2785	1713211020	60	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	3484.00	\N
2786	1713210840	360	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	3484.00	\N
2787	1713209760	1440	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	3484.00	\N
2788	1713206880	10080	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	3484.00	\N
2789	1713220440	60	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2797	1713220440	60	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	1.00	\N
2798	1713220200	360	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	1.00	\N
2799	1713219840	1440	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	1.00	\N
2800	1713216960	10080	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	1.00	\N
2801	1713220440	60	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	2671.00	\N
2802	1713220200	360	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	2671.00	\N
2803	1713219840	1440	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	2671.00	\N
2804	1713216960	10080	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	2671.00	\N
2805	1713220500	60	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	1.00	\N
2806	1713220200	360	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	1.00	\N
2807	1713219840	1440	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	1.00	\N
2808	1713216960	10080	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	1.00	\N
2817	1713220500	60	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	2445.00	\N
2818	1713220200	360	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	2445.00	\N
2819	1713219840	1440	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	2445.00	\N
2820	1713216960	10080	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	2445.00	\N
2809	1713220500	60	slow_user_request	1	count	2.00	\N
2810	1713220200	360	slow_user_request	1	count	2.00	\N
2811	1713219840	1440	slow_user_request	1	count	2.00	\N
2845	1713221640	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
2813	1713220500	60	user_request	1	count	2.00	\N
2814	1713220200	360	user_request	1	count	2.00	\N
2815	1713219840	1440	user_request	1	count	2.00	\N
2998	1713555000	360	user_request	1	count	6.00	\N
2821	1713220500	60	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
2833	1713220500	60	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2112.00	\N
2846	1713221640	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
2847	1713221280	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
2999	1713553920	1440	user_request	1	count	6.00	\N
3000	1713549600	10080	user_request	1	count	30.00	\N
2849	1713221640	60	slow_user_request	1	count	2.00	\N
3609	1713562020	60	user_request	1	count	1.00	\N
2853	1713221640	60	user_request	1	count	2.00	\N
2848	1713216960	10080	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
2850	1713221640	360	slow_user_request	1	count	3.00	\N
2851	1713221280	1440	slow_user_request	1	count	3.00	\N
2854	1713221640	360	user_request	1	count	4.00	\N
2997	1713555300	60	user_request	1	count	6.00	\N
2855	1713221280	1440	user_request	1	count	6.00	\N
2812	1713216960	10080	slow_user_request	1	count	6.00	\N
3001	1713555300	60	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	1270.00	\N
3002	1713555000	360	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	1270.00	\N
3003	1713553920	1440	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	1270.00	\N
3004	1713549600	10080	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	max	1270.00	\N
2857	1713221640	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\table_row.blade.php"]	count	2.00	\N
2858	1713221640	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\table_row.blade.php"]	count	2.00	\N
2859	1713221280	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\table_row.blade.php"]	count	2.00	\N
2860	1713216960	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\table_row.blade.php"]	count	2.00	\N
2861	1713221640	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	5986.00	\N
2865	1713221640	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\table_row.blade.php"]	max	1713221680.00	\N
2866	1713221640	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\table_row.blade.php"]	max	1713221680.00	\N
2867	1713221280	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\table_row.blade.php"]	max	1713221680.00	\N
2868	1713216960	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\table_row.blade.php"]	max	1713221680.00	\N
2893	1713221820	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2897	1713221820	60	slow_user_request	1	count	1.00	\N
2901	1713221820	60	user_request	1	count	1.00	\N
2905	1713221820	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1219.00	\N
2862	1713221640	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	5986.00	\N
2863	1713221280	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	5986.00	\N
2864	1713216960	10080	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	5986.00	\N
2909	1713221940	60	user_request	1	count	1.00	\N
2913	1713222000	60	user_request	1	count	2.00	\N
2914	1713222000	360	user_request	1	count	2.00	\N
2921	1713222840	60	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2922	1713222720	360	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2923	1713222720	1440	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2924	1713216960	10080	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
2925	1713222840	60	slow_user_request	1	count	1.00	\N
2926	1713222720	360	slow_user_request	1	count	1.00	\N
2927	1713222720	1440	slow_user_request	1	count	1.00	\N
2929	1713222840	60	user_request	1	count	1.00	\N
2930	1713222720	360	user_request	1	count	1.00	\N
2933	1713222840	60	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1895.00	\N
2934	1713222720	360	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1895.00	\N
2935	1713222720	1440	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1895.00	\N
2936	1713216960	10080	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1895.00	\N
2937	1713223320	60	user_request	1	count	1.00	\N
2938	1713223080	360	user_request	1	count	1.00	\N
2931	1713222720	1440	user_request	1	count	2.00	\N
2816	1713216960	10080	user_request	1	count	10.00	\N
2941	1713375120	60	slow_query	["select * from \\"grades\\" limit 1","Command line code:1"]	count	1.00	\N
2942	1713375000	360	slow_query	["select * from \\"grades\\" limit 1","Command line code:1"]	count	1.00	\N
2943	1713373920	1440	slow_query	["select * from \\"grades\\" limit 1","Command line code:1"]	count	1.00	\N
2944	1713368160	10080	slow_query	["select * from \\"grades\\" limit 1","Command line code:1"]	count	1.00	\N
2945	1713375120	60	slow_query	["select * from \\"grades\\" limit 1","Command line code:1"]	max	1420.00	\N
2946	1713375000	360	slow_query	["select * from \\"grades\\" limit 1","Command line code:1"]	max	1420.00	\N
2949	1713389040	60	exception	["Symfony\\\\Component\\\\Console\\\\Exception\\\\NamespaceNotFoundException","vendor\\\\symfony\\\\console\\\\Application.php:669"]	count	1.00	\N
2950	1713389040	360	exception	["Symfony\\\\Component\\\\Console\\\\Exception\\\\NamespaceNotFoundException","vendor\\\\symfony\\\\console\\\\Application.php:669"]	count	1.00	\N
2951	1713388320	1440	exception	["Symfony\\\\Component\\\\Console\\\\Exception\\\\NamespaceNotFoundException","vendor\\\\symfony\\\\console\\\\Application.php:669"]	count	1.00	\N
2952	1713388320	10080	exception	["Symfony\\\\Component\\\\Console\\\\Exception\\\\NamespaceNotFoundException","vendor\\\\symfony\\\\console\\\\Application.php:669"]	count	1.00	\N
2953	1713389040	60	exception	["Symfony\\\\Component\\\\Console\\\\Exception\\\\NamespaceNotFoundException","vendor\\\\symfony\\\\console\\\\Application.php:669"]	max	1713389051.00	\N
2954	1713389040	360	exception	["Symfony\\\\Component\\\\Console\\\\Exception\\\\NamespaceNotFoundException","vendor\\\\symfony\\\\console\\\\Application.php:669"]	max	1713389051.00	\N
2955	1713388320	1440	exception	["Symfony\\\\Component\\\\Console\\\\Exception\\\\NamespaceNotFoundException","vendor\\\\symfony\\\\console\\\\Application.php:669"]	max	1713389051.00	\N
2956	1713388320	10080	exception	["Symfony\\\\Component\\\\Console\\\\Exception\\\\NamespaceNotFoundException","vendor\\\\symfony\\\\console\\\\Application.php:669"]	max	1713389051.00	\N
2957	1713555240	60	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
2958	1713555000	360	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
2959	1713553920	1440	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
2960	1713549600	10080	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
2961	1713555240	60	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	1214.00	\N
2962	1713555000	360	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	1214.00	\N
2963	1713553920	1440	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	1214.00	\N
2964	1713549600	10080	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	1214.00	\N
2965	1713555240	60	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
2966	1713555000	360	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
2967	1713553920	1440	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
2968	1713549600	10080	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	count	1.00	\N
2969	1713555240	60	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	1567.00	\N
2970	1713555000	360	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	1567.00	\N
2971	1713553920	1440	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	1567.00	\N
2972	1713549600	10080	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	max	1567.00	\N
2973	1713555240	60	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	count	1.00	\N
2974	1713555000	360	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	count	1.00	\N
2975	1713553920	1440	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	count	1.00	\N
2976	1713549600	10080	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	count	1.00	\N
2977	1713555240	60	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	max	1334.00	\N
2978	1713555000	360	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	max	1334.00	\N
2979	1713553920	1440	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	max	1334.00	\N
2980	1713549600	10080	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	max	1334.00	\N
2981	1713555240	60	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	count	1.00	\N
2982	1713555000	360	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	count	1.00	\N
2983	1713553920	1440	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	count	1.00	\N
2984	1713549600	10080	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	count	1.00	\N
2985	1713555240	60	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	max	1090.00	\N
2986	1713555000	360	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	max	1090.00	\N
2987	1713553920	1440	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	max	1090.00	\N
2988	1713549600	10080	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	max	1090.00	\N
2989	1713555300	60	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	1.00	\N
2990	1713555000	360	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	1.00	\N
2991	1713553920	1440	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	1.00	\N
2992	1713549600	10080	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	count	1.00	\N
3013	1713555300	60	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	count	1.00	\N
3014	1713555000	360	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	count	1.00	\N
3015	1713553920	1440	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	count	1.00	\N
3016	1713549600	10080	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	count	1.00	\N
3017	1713555300	60	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	max	1040.00	\N
3018	1713555000	360	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	max	1040.00	\N
3019	1713553920	1440	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	max	1040.00	\N
3020	1713549600	10080	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	max	1040.00	\N
3021	1713555300	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
3022	1713555000	360	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
3023	1713553920	1440	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
3037	1713555300	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1777.00	\N
3038	1713555000	360	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1777.00	\N
3039	1713553920	1440	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1777.00	\N
3082	1713555360	360	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	4.00	\N
3041	1713555300	60	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	2.00	\N
3042	1713555000	360	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	2.00	\N
3043	1713553920	1440	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	2.00	\N
2993	1713555300	60	slow_user_request	1	count	4.00	\N
2995	1713553920	1440	slow_user_request	1	count	4.00	\N
3081	1713555480	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
3033	1713555300	60	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	3.00	\N
3034	1713555000	360	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	3.00	\N
3035	1713553920	1440	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	3.00	\N
3057	1713555300	60	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	2831.00	\N
3058	1713555000	360	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	2831.00	\N
3059	1713553920	1440	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	2831.00	\N
3044	1713549600	10080	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	5.00	\N
3036	1713549600	10080	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	9.00	\N
3060	1713549600	10080	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	3947.00	\N
3085	1713555480	60	slow_user_request	1	count	2.00	\N
3089	1713555480	60	user_request	1	count	2.00	\N
3093	1713555480	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Student\\\\index.blade.php"]	count	2.00	\N
3097	1713555480	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	4994.00	\N
3101	1713555480	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Student\\\\index.blade.php"]	max	1713555513.00	\N
3083	1713555360	1440	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	4.00	\N
3129	1713555540	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
3133	1713555540	60	slow_user_request	1	count	1.00	\N
3024	1713549600	10080	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	7.00	\N
3177	1713555660	60	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	2.00	\N
3137	1713555540	60	user_request	1	count	1.00	\N
3178	1713555360	360	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	2.00	\N
3141	1713555540	60	cache_miss	powerGridTheme_App\\Helpers\\PowerGridThemes\\TailwindStriped	count	7.00	\N
3142	1713555360	360	cache_miss	powerGridTheme_App\\Helpers\\PowerGridThemes\\TailwindStriped	count	7.00	\N
3143	1713555360	1440	cache_miss	powerGridTheme_App\\Helpers\\PowerGridThemes\\TailwindStriped	count	7.00	\N
3144	1713549600	10080	cache_miss	powerGridTheme_App\\Helpers\\PowerGridThemes\\TailwindStriped	count	7.00	\N
3145	1713555540	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Student\\\\index.blade.php"]	count	1.00	\N
3094	1713555360	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Student\\\\index.blade.php"]	count	3.00	\N
3095	1713555360	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Student\\\\index.blade.php"]	count	3.00	\N
3096	1713549600	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Student\\\\index.blade.php"]	count	3.00	\N
3149	1713555540	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	10192.00	\N
3179	1713555360	1440	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	2.00	\N
3181	1713555660	60	slow_user_request	1	count	2.00	\N
3153	1713555540	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Student\\\\index.blade.php"]	max	1713555583.00	\N
3102	1713555360	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Student\\\\index.blade.php"]	max	1713555583.00	\N
3103	1713555360	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Student\\\\index.blade.php"]	max	1713555583.00	\N
3104	1713549600	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Student\\\\index.blade.php"]	max	1713555583.00	\N
3157	1713555600	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
3161	1713555600	60	slow_user_request	1	count	1.00	\N
3040	1713549600	10080	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	10192.00	\N
3165	1713555600	60	user_request	1	count	1.00	\N
3169	1713555600	60	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	1.00	\N
3173	1713555600	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2426.00	\N
3098	1713555360	360	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	10192.00	\N
3099	1713555360	1440	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	10192.00	\N
3197	1713555660	60	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	count	1.00	\N
3198	1713555360	360	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	count	1.00	\N
3086	1713555360	360	slow_user_request	1	count	6.00	\N
3087	1713555360	1440	slow_user_request	1	count	6.00	\N
3199	1713555360	1440	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	count	1.00	\N
3200	1713549600	10080	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	count	1.00	\N
3201	1713555660	60	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	max	1254.00	\N
3202	1713555360	360	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	max	1254.00	\N
3203	1713555360	1440	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	max	1254.00	\N
3204	1713549600	10080	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	max	1254.00	\N
3185	1713555660	60	user_request	1	count	3.00	\N
3090	1713555360	360	user_request	1	count	7.00	\N
3091	1713555360	1440	user_request	1	count	7.00	\N
3189	1713555660	60	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	3.00	\N
3170	1713555360	360	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	4.00	\N
3171	1713555360	1440	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	4.00	\N
3193	1713555660	60	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	3947.00	\N
3194	1713555360	360	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	3947.00	\N
3195	1713555360	1440	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	3947.00	\N
3233	1713558780	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
3234	1713558600	360	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
3237	1713558780	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3111.00	\N
3238	1713558600	360	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3111.00	\N
3253	1713558780	60	slow_user_request	1	count	1.00	\N
3254	1713558600	360	slow_user_request	1	count	3.00	\N
3257	1713558780	60	user_request	1	count	2.00	\N
2996	1713549600	10080	slow_user_request	1	count	21.00	\N
3239	1713558240	1440	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3111.00	\N
3249	1713558780	60	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
3259	1713558240	1440	user_request	1	count	17.00	\N
3258	1713558600	360	user_request	1	count	5.00	\N
3261	1713558780	60	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2242.00	\N
3241	1713558780	60	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	2.00	\N
3242	1713558600	360	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	2.00	\N
3243	1713558240	1440	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	2.00	\N
3244	1713549600	10080	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	count	2.00	\N
3245	1713558780	60	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	1623.00	\N
3246	1713558600	360	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	1623.00	\N
3247	1713558240	1440	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	1623.00	\N
3250	1713558600	360	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
3251	1713558240	1440	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
3252	1713549600	10080	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
3235	1713558240	1440	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
3255	1713558240	1440	slow_user_request	1	count	11.00	\N
3262	1713558600	360	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2325.00	\N
3263	1713558240	1440	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2325.00	\N
3264	1713549600	10080	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2325.00	\N
3248	1713549600	10080	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	max	1623.00	\N
3285	1713558900	60	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
3297	1713558900	60	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	2325.00	\N
3301	1713558900	60	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	1.00	\N
3302	1713558600	360	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	1.00	\N
3289	1713558900	60	slow_user_request	1	count	2.00	\N
3393	1713559380	60	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	2.00	\N
3313	1713558900	60	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	1162.00	\N
3314	1713558600	360	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	1162.00	\N
3293	1713558900	60	user_request	1	count	3.00	\N
3325	1713558960	60	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	1.00	\N
3326	1713558960	360	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	1.00	\N
3303	1713558240	1440	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	2.00	\N
3304	1713549600	10080	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	count	2.00	\N
3329	1713558960	60	slow_user_request	1	count	1.00	\N
3321	1713558960	60	user_request	1	count	2.00	\N
3337	1713558960	60	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	1024.00	\N
3338	1713558960	360	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	1024.00	\N
3315	1713558240	1440	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	1162.00	\N
3316	1713549600	10080	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	max	1162.00	\N
3341	1713559080	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
3342	1713558960	360	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
3349	1713559080	60	user_request	1	count	5.00	\N
3322	1713558960	360	user_request	1	count	7.00	\N
3357	1713559080	60	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1801.00	\N
3358	1713558960	360	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1801.00	\N
3361	1713559080	60	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	1.00	\N
3362	1713558960	360	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	1.00	\N
3363	1713558240	1440	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	count	1.00	\N
3345	1713559080	60	slow_user_request	1	count	2.00	\N
3330	1713558960	360	slow_user_request	1	count	3.00	\N
3353	1713559080	60	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	2.00	\N
3354	1713558960	360	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	2.00	\N
3355	1713558240	1440	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	count	2.00	\N
3377	1713559080	60	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	1978.00	\N
3378	1713558960	360	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	1978.00	\N
3379	1713558240	1440	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	max	1978.00	\N
3405	1713559380	60	exception	["Error","app\\\\Http\\\\Controllers\\\\HomeController.php:9"]	count	1.00	\N
3406	1713559320	360	exception	["Error","app\\\\Http\\\\Controllers\\\\HomeController.php:9"]	count	1.00	\N
3407	1713558240	1440	exception	["Error","app\\\\Http\\\\Controllers\\\\HomeController.php:9"]	count	1.00	\N
3408	1713549600	10080	exception	["Error","app\\\\Http\\\\Controllers\\\\HomeController.php:9"]	count	1.00	\N
3413	1713559380	60	exception	["Error","app\\\\Http\\\\Controllers\\\\HomeController.php:9"]	max	1713559391.00	\N
3414	1713559320	360	exception	["Error","app\\\\Http\\\\Controllers\\\\HomeController.php:9"]	max	1713559391.00	\N
3394	1713559320	360	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	5.00	\N
3397	1713559380	60	slow_user_request	1	count	2.00	\N
3401	1713559380	60	user_request	1	count	2.00	\N
3409	1713559380	60	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	2180.00	\N
3433	1713559440	60	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	1.00	\N
3485	1713560640	60	user_request	1	count	2.00	\N
3495	1713559680	1440	slow_user_request	1	count	3.00	\N
3437	1713559440	60	slow_user_request	1	count	1.00	\N
3496	1713559680	10080	slow_user_request	1	count	14.00	\N
3441	1713559440	60	user_request	1	count	1.00	\N
3516	1713559680	10080	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	4.00	\N
3445	1713559440	60	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1395.00	\N
3501	1713560640	60	exception	["Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Container\\\\BoundMethod.php:188"]	count	1.00	\N
3502	1713560400	360	exception	["Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Container\\\\BoundMethod.php:188"]	count	1.00	\N
3503	1713559680	1440	exception	["Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Container\\\\BoundMethod.php:188"]	count	1.00	\N
3504	1713559680	10080	exception	["Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Container\\\\BoundMethod.php:188"]	count	1.00	\N
3505	1713560640	60	slow_request	["GET","\\/ar\\/grades","App\\\\Livewire\\\\Grades@__invoke"]	max	1776.00	\N
3506	1713560400	360	slow_request	["GET","\\/ar\\/grades","App\\\\Livewire\\\\Grades@__invoke"]	max	1776.00	\N
3507	1713559680	1440	slow_request	["GET","\\/ar\\/grades","App\\\\Livewire\\\\Grades@__invoke"]	max	1776.00	\N
3508	1713559680	10080	slow_request	["GET","\\/ar\\/grades","App\\\\Livewire\\\\Grades@__invoke"]	max	1776.00	\N
3509	1713560640	60	exception	["Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Container\\\\BoundMethod.php:188"]	max	1713560678.00	\N
3510	1713560400	360	exception	["Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Container\\\\BoundMethod.php:188"]	max	1713560678.00	\N
3449	1713559560	60	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	2.00	\N
3395	1713558240	1440	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	5.00	\N
3396	1713549600	10080	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	5.00	\N
3453	1713559560	60	slow_user_request	1	count	2.00	\N
3398	1713559320	360	slow_user_request	1	count	5.00	\N
3457	1713559560	60	user_request	1	count	2.00	\N
3402	1713559320	360	user_request	1	count	5.00	\N
3461	1713559560	60	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1428.00	\N
3410	1713559320	360	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	2180.00	\N
3411	1713558240	1440	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	2180.00	\N
3412	1713549600	10080	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	2180.00	\N
3481	1713560280	60	user_request	1	count	1.00	\N
3482	1713560040	360	user_request	1	count	1.00	\N
3494	1713560400	360	slow_user_request	1	count	2.00	\N
3484	1713559680	10080	user_request	1	count	21.00	\N
3489	1713560640	60	slow_request	["GET","\\/ar\\/grades","App\\\\Livewire\\\\Grades@__invoke"]	count	1.00	\N
3490	1713560400	360	slow_request	["GET","\\/ar\\/grades","App\\\\Livewire\\\\Grades@__invoke"]	count	1.00	\N
3491	1713559680	1440	slow_request	["GET","\\/ar\\/grades","App\\\\Livewire\\\\Grades@__invoke"]	count	1.00	\N
3492	1713559680	10080	slow_request	["GET","\\/ar\\/grades","App\\\\Livewire\\\\Grades@__invoke"]	count	1.00	\N
3493	1713560640	60	slow_user_request	1	count	1.00	\N
3511	1713559680	1440	exception	["Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Container\\\\BoundMethod.php:188"]	max	1713560678.00	\N
3512	1713559680	10080	exception	["Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Container\\\\BoundMethod.php:188"]	max	1713560678.00	\N
3513	1713560700	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
3514	1713560400	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
3515	1713559680	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
3517	1713560700	60	slow_user_request	1	count	1.00	\N
3521	1713560700	60	user_request	1	count	1.00	\N
3486	1713560400	360	user_request	1	count	3.00	\N
3483	1713559680	1440	user_request	1	count	7.00	\N
3525	1713560700	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1417.00	\N
3526	1713560400	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1417.00	\N
3527	1713559680	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1417.00	\N
3529	1713560880	60	user_request	1	count	2.00	\N
3569	1713561960	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
3537	1713560940	60	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	1.00	\N
3538	1713560760	360	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	1.00	\N
3539	1713559680	1440	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	1.00	\N
3540	1713559680	10080	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	count	1.00	\N
3541	1713560940	60	slow_user_request	1	count	1.00	\N
3542	1713560760	360	slow_user_request	1	count	1.00	\N
3545	1713560940	60	user_request	1	count	1.00	\N
3530	1713560760	360	user_request	1	count	3.00	\N
3549	1713560940	60	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1227.00	\N
3550	1713560760	360	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1227.00	\N
3551	1713559680	1440	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1227.00	\N
3552	1713559680	10080	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	max	1227.00	\N
3553	1713561360	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
3554	1713561120	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	1.00	\N
3557	1713561360	60	slow_user_request	1	count	1.00	\N
3558	1713561120	360	slow_user_request	1	count	1.00	\N
3561	1713561360	60	user_request	1	count	1.00	\N
3562	1713561120	360	user_request	1	count	1.00	\N
3565	1713561360	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1175.00	\N
3566	1713561120	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	1175.00	\N
3570	1713561840	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	2.00	\N
3578	1713561840	360	user_request	1	count	3.00	\N
3563	1713561120	1440	user_request	1	count	4.00	\N
3613	1713563880	60	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	count	1.00	\N
3581	1713561960	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\layouts\\\\sidebar.blade.php"]	count	1.00	\N
3582	1713561840	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\layouts\\\\sidebar.blade.php"]	count	1.00	\N
3583	1713561120	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\layouts\\\\sidebar.blade.php"]	count	1.00	\N
3584	1713559680	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\layouts\\\\sidebar.blade.php"]	count	1.00	\N
3614	1713563640	360	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	count	1.00	\N
3615	1713562560	1440	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	count	1.00	\N
3589	1713561960	60	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\layouts\\\\sidebar.blade.php"]	max	1713561991.00	\N
3590	1713561840	360	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\layouts\\\\sidebar.blade.php"]	max	1713561991.00	\N
3591	1713561120	1440	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\layouts\\\\sidebar.blade.php"]	max	1713561991.00	\N
3592	1713559680	10080	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\layouts\\\\sidebar.blade.php"]	max	1713561991.00	\N
3555	1713561120	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	count	3.00	\N
3573	1713561960	60	slow_user_request	1	count	2.00	\N
3574	1713561840	360	slow_user_request	1	count	2.00	\N
3559	1713561120	1440	slow_user_request	1	count	3.00	\N
3577	1713561960	60	user_request	1	count	2.00	\N
3616	1713559680	10080	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	count	6.00	\N
3585	1713561960	60	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3814.00	\N
3586	1713561840	360	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3814.00	\N
3567	1713561120	1440	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3814.00	\N
3528	1713559680	10080	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	max	3814.00	\N
3617	1713563880	60	slow_user_request	1	count	1.00	\N
3618	1713563640	360	slow_user_request	1	count	1.00	\N
3619	1713562560	1440	slow_user_request	1	count	1.00	\N
3621	1713563880	60	user_request	1	count	1.00	\N
3622	1713563640	360	user_request	1	count	1.00	\N
3623	1713562560	1440	user_request	1	count	1.00	\N
3625	1713563880	60	exception	["ErrorException","resources\\\\views\\\\backend\\\\backup\\\\index.blade.php"]	count	1.00	\N
3626	1713563640	360	exception	["ErrorException","resources\\\\views\\\\backend\\\\backup\\\\index.blade.php"]	count	1.00	\N
3627	1713562560	1440	exception	["ErrorException","resources\\\\views\\\\backend\\\\backup\\\\index.blade.php"]	count	1.00	\N
3628	1713559680	10080	exception	["ErrorException","resources\\\\views\\\\backend\\\\backup\\\\index.blade.php"]	count	1.00	\N
3629	1713563880	60	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	max	5792.00	\N
3630	1713563640	360	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	max	5792.00	\N
3631	1713562560	1440	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	max	5792.00	\N
3633	1713563880	60	exception	["ErrorException","resources\\\\views\\\\backend\\\\backup\\\\index.blade.php"]	max	1713563905.00	\N
3634	1713563640	360	exception	["ErrorException","resources\\\\views\\\\backend\\\\backup\\\\index.blade.php"]	max	1713563905.00	\N
3635	1713562560	1440	exception	["ErrorException","resources\\\\views\\\\backend\\\\backup\\\\index.blade.php"]	max	1713563905.00	\N
3636	1713559680	10080	exception	["ErrorException","resources\\\\views\\\\backend\\\\backup\\\\index.blade.php"]	max	1713563905.00	\N
3637	1713563940	60	exception	["Spatie\\\\Backup\\\\Exceptions\\\\BackupFailed","vendor\\\\spatie\\\\laravel-backup\\\\src\\\\Exceptions\\\\BackupFailed.php:17"]	count	1.00	\N
3638	1713563640	360	exception	["Spatie\\\\Backup\\\\Exceptions\\\\BackupFailed","vendor\\\\spatie\\\\laravel-backup\\\\src\\\\Exceptions\\\\BackupFailed.php:17"]	count	1.00	\N
3639	1713562560	1440	exception	["Spatie\\\\Backup\\\\Exceptions\\\\BackupFailed","vendor\\\\spatie\\\\laravel-backup\\\\src\\\\Exceptions\\\\BackupFailed.php:17"]	count	1.00	\N
3640	1713559680	10080	exception	["Spatie\\\\Backup\\\\Exceptions\\\\BackupFailed","vendor\\\\spatie\\\\laravel-backup\\\\src\\\\Exceptions\\\\BackupFailed.php:17"]	count	1.00	\N
3641	1713563940	60	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","vendor\\\\symfony\\\\mailer\\\\Transport\\\\Smtp\\\\Stream\\\\SocketStream.php:154"]	count	1.00	\N
3642	1713563640	360	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","vendor\\\\symfony\\\\mailer\\\\Transport\\\\Smtp\\\\Stream\\\\SocketStream.php:154"]	count	1.00	\N
3643	1713562560	1440	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","vendor\\\\symfony\\\\mailer\\\\Transport\\\\Smtp\\\\Stream\\\\SocketStream.php:154"]	count	1.00	\N
3645	1713563940	60	exception	["Spatie\\\\Backup\\\\Exceptions\\\\BackupFailed","vendor\\\\spatie\\\\laravel-backup\\\\src\\\\Exceptions\\\\BackupFailed.php:17"]	max	1713563995.00	\N
3646	1713563640	360	exception	["Spatie\\\\Backup\\\\Exceptions\\\\BackupFailed","vendor\\\\spatie\\\\laravel-backup\\\\src\\\\Exceptions\\\\BackupFailed.php:17"]	max	1713563995.00	\N
3647	1713562560	1440	exception	["Spatie\\\\Backup\\\\Exceptions\\\\BackupFailed","vendor\\\\spatie\\\\laravel-backup\\\\src\\\\Exceptions\\\\BackupFailed.php:17"]	max	1713563995.00	\N
3648	1713559680	10080	exception	["Spatie\\\\Backup\\\\Exceptions\\\\BackupFailed","vendor\\\\spatie\\\\laravel-backup\\\\src\\\\Exceptions\\\\BackupFailed.php:17"]	max	1713563995.00	\N
3649	1713563940	60	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","vendor\\\\symfony\\\\mailer\\\\Transport\\\\Smtp\\\\Stream\\\\SocketStream.php:154"]	max	1713563998.00	\N
3650	1713563640	360	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","vendor\\\\symfony\\\\mailer\\\\Transport\\\\Smtp\\\\Stream\\\\SocketStream.php:154"]	max	1713563998.00	\N
3651	1713562560	1440	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","vendor\\\\symfony\\\\mailer\\\\Transport\\\\Smtp\\\\Stream\\\\SocketStream.php:154"]	max	1713563998.00	\N
3653	1713564060	60	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	count	1.00	\N
3654	1713564000	360	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	count	1.00	\N
3657	1713564060	60	slow_user_request	1	count	1.00	\N
3658	1713564000	360	slow_user_request	1	count	1.00	\N
3661	1713564060	60	user_request	1	count	1.00	\N
3662	1713564000	360	user_request	1	count	1.00	\N
3665	1713564060	60	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	max	2400.00	\N
3666	1713564000	360	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	max	2400.00	\N
3659	1713564000	1440	slow_user_request	1	count	7.00	\N
3669	1713564240	60	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","vendor\\\\symfony\\\\mailer\\\\Transport\\\\Smtp\\\\Stream\\\\SocketStream.php:154"]	count	1.00	\N
3670	1713564000	360	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","vendor\\\\symfony\\\\mailer\\\\Transport\\\\Smtp\\\\Stream\\\\SocketStream.php:154"]	count	1.00	\N
3671	1713564000	1440	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","vendor\\\\symfony\\\\mailer\\\\Transport\\\\Smtp\\\\Stream\\\\SocketStream.php:154"]	count	1.00	\N
3644	1713559680	10080	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","vendor\\\\symfony\\\\mailer\\\\Transport\\\\Smtp\\\\Stream\\\\SocketStream.php:154"]	count	2.00	\N
3673	1713564240	60	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","vendor\\\\symfony\\\\mailer\\\\Transport\\\\Smtp\\\\Stream\\\\SocketStream.php:154"]	max	1713564299.00	\N
3663	1713564000	1440	user_request	1	count	9.00	\N
3655	1713564000	1440	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	count	5.00	\N
3674	1713564000	360	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","vendor\\\\symfony\\\\mailer\\\\Transport\\\\Smtp\\\\Stream\\\\SocketStream.php:154"]	max	1713564299.00	\N
3675	1713564000	1440	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","vendor\\\\symfony\\\\mailer\\\\Transport\\\\Smtp\\\\Stream\\\\SocketStream.php:154"]	max	1713564299.00	\N
3652	1713559680	10080	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","vendor\\\\symfony\\\\mailer\\\\Transport\\\\Smtp\\\\Stream\\\\SocketStream.php:154"]	max	1713564299.00	\N
3677	1713564840	60	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	count	1.00	\N
3689	1713564840	60	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	max	1114.00	\N
3693	1713564840	60	slow_request	["GET","\\/ar\\/backup\\/create","App\\\\Http\\\\Controllers\\\\BackupController@create"]	count	1.00	\N
3694	1713564720	360	slow_request	["GET","\\/ar\\/backup\\/create","App\\\\Http\\\\Controllers\\\\BackupController@create"]	count	1.00	\N
3681	1713564840	60	slow_user_request	1	count	2.00	\N
3739	1713564000	1440	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:13"]	count	2.00	\N
3685	1713564840	60	user_request	1	count	2.00	\N
3740	1713559680	10080	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:13"]	count	2.00	\N
3705	1713564840	60	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:17"]	count	1.00	\N
3706	1713564720	360	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:17"]	count	1.00	\N
3707	1713564000	1440	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:17"]	count	1.00	\N
3708	1713559680	10080	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:17"]	count	1.00	\N
3709	1713564840	60	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	count	1.00	\N
3710	1713564720	360	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	count	1.00	\N
3711	1713564000	1440	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	count	1.00	\N
3712	1713559680	10080	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	count	1.00	\N
3713	1713564840	60	slow_request	["GET","\\/ar\\/backup\\/create","App\\\\Http\\\\Controllers\\\\BackupController@create"]	max	6818.00	\N
3714	1713564720	360	slow_request	["GET","\\/ar\\/backup\\/create","App\\\\Http\\\\Controllers\\\\BackupController@create"]	max	6818.00	\N
3717	1713564840	60	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:17"]	max	1713564857.00	\N
3718	1713564720	360	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:17"]	max	1713564857.00	\N
3719	1713564000	1440	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:17"]	max	1713564857.00	\N
3720	1713559680	10080	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:17"]	max	1713564857.00	\N
3721	1713564840	60	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	max	1713564857.00	\N
3722	1713564720	360	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	max	1713564857.00	\N
3723	1713564000	1440	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	max	1713564857.00	\N
3724	1713559680	10080	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	max	1713564857.00	\N
3725	1713565020	60	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	count	1.00	\N
3678	1713564720	360	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	count	2.00	\N
3729	1713565020	60	slow_user_request	1	count	1.00	\N
3682	1713564720	360	slow_user_request	1	count	3.00	\N
3733	1713565020	60	user_request	1	count	1.00	\N
3686	1713564720	360	user_request	1	count	3.00	\N
3737	1713565020	60	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:13"]	count	1.00	\N
3738	1713564720	360	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:13"]	count	1.00	\N
3695	1713564000	1440	slow_request	["GET","\\/ar\\/backup\\/create","App\\\\Http\\\\Controllers\\\\BackupController@create"]	count	2.00	\N
3696	1713559680	10080	slow_request	["GET","\\/ar\\/backup\\/create","App\\\\Http\\\\Controllers\\\\BackupController@create"]	count	2.00	\N
3715	1713564000	1440	slow_request	["GET","\\/ar\\/backup\\/create","App\\\\Http\\\\Controllers\\\\BackupController@create"]	max	8514.00	\N
3716	1713559680	10080	slow_request	["GET","\\/ar\\/backup\\/create","App\\\\Http\\\\Controllers\\\\BackupController@create"]	max	8514.00	\N
3741	1713565020	60	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	max	12373.00	\N
3690	1713564720	360	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	max	12373.00	\N
3745	1713565020	60	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:13"]	max	1713565027.00	\N
3746	1713564720	360	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:13"]	max	1713565027.00	\N
3749	1713565080	60	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	count	1.00	\N
3753	1713565080	60	slow_user_request	1	count	1.00	\N
3757	1713565080	60	user_request	1	count	1.00	\N
3761	1713565080	60	slow_query	["select * from \\"users\\" where \\"id\\" = ? limit 1","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportDisablingBackButtonCache\\\\DisableBackButtonCacheMiddleware.php:19"]	count	1.00	\N
3762	1713565080	360	slow_query	["select * from \\"users\\" where \\"id\\" = ? limit 1","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportDisablingBackButtonCache\\\\DisableBackButtonCacheMiddleware.php:19"]	count	1.00	\N
3763	1713564000	1440	slow_query	["select * from \\"users\\" where \\"id\\" = ? limit 1","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportDisablingBackButtonCache\\\\DisableBackButtonCacheMiddleware.php:19"]	count	1.00	\N
3764	1713559680	10080	slow_query	["select * from \\"users\\" where \\"id\\" = ? limit 1","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportDisablingBackButtonCache\\\\DisableBackButtonCacheMiddleware.php:19"]	count	1.00	\N
3765	1713565080	60	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:13"]	count	1.00	\N
3766	1713565080	360	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:13"]	count	1.00	\N
3769	1713565080	60	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	max	6870.00	\N
3797	1713565320	60	user_request	1	count	2.00	\N
3758	1713565080	360	user_request	1	count	5.00	\N
3773	1713565080	60	slow_query	["select * from \\"users\\" where \\"id\\" = ? limit 1","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportDisablingBackButtonCache\\\\DisableBackButtonCacheMiddleware.php:19"]	max	1101.00	\N
3774	1713565080	360	slow_query	["select * from \\"users\\" where \\"id\\" = ? limit 1","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportDisablingBackButtonCache\\\\DisableBackButtonCacheMiddleware.php:19"]	max	1101.00	\N
3775	1713564000	1440	slow_query	["select * from \\"users\\" where \\"id\\" = ? limit 1","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportDisablingBackButtonCache\\\\DisableBackButtonCacheMiddleware.php:19"]	max	1101.00	\N
3776	1713559680	10080	slow_query	["select * from \\"users\\" where \\"id\\" = ? limit 1","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportDisablingBackButtonCache\\\\DisableBackButtonCacheMiddleware.php:19"]	max	1101.00	\N
3777	1713565080	60	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:13"]	max	1713565139.00	\N
3778	1713565080	360	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:13"]	max	1713565139.00	\N
3747	1713564000	1440	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:13"]	max	1713565139.00	\N
3748	1713559680	10080	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:13"]	max	1713565139.00	\N
3770	1713565080	360	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	max	6870.00	\N
3781	1713565260	60	user_request	1	count	2.00	\N
3817	1713565320	60	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	count	1.00	\N
3789	1713565320	60	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	count	1.00	\N
3750	1713565080	360	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	count	2.00	\N
3801	1713565320	60	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	max	1711.00	\N
3667	1713564000	1440	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	max	12373.00	\N
3632	1713559680	10080	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	max	12373.00	\N
3805	1713565320	60	slow_request	["GET","\\/ar\\/backup\\/create","App\\\\Http\\\\Controllers\\\\BackupController@create"]	count	1.00	\N
3806	1713565080	360	slow_request	["GET","\\/ar\\/backup\\/create","App\\\\Http\\\\Controllers\\\\BackupController@create"]	count	1.00	\N
3793	1713565320	60	slow_user_request	1	count	2.00	\N
3754	1713565080	360	slow_user_request	1	count	3.00	\N
3818	1713565080	360	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	count	1.00	\N
3819	1713564000	1440	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	count	1.00	\N
3820	1713559680	10080	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	count	1.00	\N
3821	1713565320	60	exception	["Illuminate\\\\Database\\\\Eloquent\\\\MassAssignmentException","app\\\\Http\\\\Controllers\\\\BackupController.php:20"]	count	1.00	\N
3822	1713565080	360	exception	["Illuminate\\\\Database\\\\Eloquent\\\\MassAssignmentException","app\\\\Http\\\\Controllers\\\\BackupController.php:20"]	count	1.00	\N
3823	1713564000	1440	exception	["Illuminate\\\\Database\\\\Eloquent\\\\MassAssignmentException","app\\\\Http\\\\Controllers\\\\BackupController.php:20"]	count	1.00	\N
3824	1713559680	10080	exception	["Illuminate\\\\Database\\\\Eloquent\\\\MassAssignmentException","app\\\\Http\\\\Controllers\\\\BackupController.php:20"]	count	1.00	\N
3825	1713565320	60	slow_request	["GET","\\/ar\\/backup\\/create","App\\\\Http\\\\Controllers\\\\BackupController@create"]	max	8514.00	\N
3826	1713565080	360	slow_request	["GET","\\/ar\\/backup\\/create","App\\\\Http\\\\Controllers\\\\BackupController@create"]	max	8514.00	\N
3829	1713565320	60	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	max	1713565349.00	\N
3830	1713565080	360	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	max	1713565349.00	\N
3831	1713564000	1440	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	max	1713565349.00	\N
3832	1713559680	10080	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	max	1713565349.00	\N
3833	1713565320	60	exception	["Illuminate\\\\Database\\\\Eloquent\\\\MassAssignmentException","app\\\\Http\\\\Controllers\\\\BackupController.php:20"]	max	1713565349.00	\N
3834	1713565080	360	exception	["Illuminate\\\\Database\\\\Eloquent\\\\MassAssignmentException","app\\\\Http\\\\Controllers\\\\BackupController.php:20"]	max	1713565349.00	\N
3835	1713564000	1440	exception	["Illuminate\\\\Database\\\\Eloquent\\\\MassAssignmentException","app\\\\Http\\\\Controllers\\\\BackupController.php:20"]	max	1713565349.00	\N
3836	1713559680	10080	exception	["Illuminate\\\\Database\\\\Eloquent\\\\MassAssignmentException","app\\\\Http\\\\Controllers\\\\BackupController.php:20"]	max	1713565349.00	\N
\.


--
-- Data for Name: pulse_entries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pulse_entries (id, "timestamp", type, key, value) FROM stdin;
1	1712514757	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	2973
2	1712514757	slow_user_request	1	\N
3	1712514757	user_request	1	\N
4	1712514759	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
5	1712514764	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	1532
6	1712514764	slow_user_request	1	\N
7	1712514764	user_request	1	\N
8	1712514765	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
9	1712514781	slow_request	["GET","\\/ar\\/school_fees","Closure"]	1814
10	1712514781	slow_user_request	1	\N
11	1712514781	user_request	1	\N
12	1712514782	exception	["ReflectionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Routing\\\\RouteSignatureParameters.php:27"]	1712514782
13	1712514961	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1003
14	1712514961	slow_user_request	1	\N
15	1712514961	user_request	1	\N
16	1712515153	user_request	1	\N
17	1712515189	user_request	1	\N
18	1712515210	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1216
19	1712515210	slow_user_request	1	\N
20	1712515210	user_request	1	\N
21	1712515219	user_request	1	\N
22	1712515227	user_request	1	\N
23	1712515228	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
24	1712515232	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	1798
25	1712515232	slow_user_request	1	\N
26	1712515232	user_request	1	\N
27	1712515233	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
28	1712515233	user_request	1	\N
29	1712515276	user_request	1	\N
30	1712515310	user_request	1	\N
31	1712515357	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	2227
32	1712515357	slow_user_request	1	\N
33	1712515357	user_request	1	\N
34	1712515358	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\card.blade.php"]	1712515358
35	1712515427	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1129
36	1712515427	slow_user_request	1	\N
37	1712515427	user_request	1	\N
38	1712515529	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1466
39	1712515529	slow_user_request	1	\N
40	1712515529	user_request	1	\N
41	1712515589	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1409
42	1712515589	slow_user_request	1	\N
43	1712515589	user_request	1	\N
44	1712515948	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	5090
45	1712515948	slow_user_request	1	\N
46	1712515948	user_request	1	\N
47	1712515951	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	1712515951
48	1712516002	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	2741
49	1712516002	slow_user_request	1	\N
50	1712516002	user_request	1	\N
51	1712516003	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	1712516003
52	1712516039	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	2569
53	1712516039	slow_user_request	1	\N
54	1712516039	user_request	1	\N
55	1712516040	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\drop-down_-table.blade.php"]	1712516040
56	1712516086	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1054
57	1712516086	slow_user_request	1	\N
58	1712516086	user_request	1	\N
59	1712516120	user_request	1	\N
60	1712516225	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1004
61	1712516225	slow_user_request	1	\N
62	1712516225	user_request	1	\N
63	1712516298	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	2275
64	1712516298	slow_user_request	1	\N
65	1712516298	user_request	1	\N
66	1712516299	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	1712516299
67	1712516319	user_request	1	\N
68	1712516357	user_request	1	\N
69	1712516378	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1171
70	1712516378	slow_user_request	1	\N
71	1712516378	user_request	1	\N
72	1712516559	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1730
73	1712516559	slow_user_request	1	\N
74	1712516559	user_request	1	\N
75	1712516622	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1218
76	1712516622	slow_user_request	1	\N
77	1712516622	user_request	1	\N
78	1712517063	user_request	1	\N
79	1712517566	user_request	1	\N
80	1712517650	user_request	1	\N
81	1712517672	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	2212
82	1712517672	slow_user_request	1	\N
83	1712517672	user_request	1	\N
84	1712517696	user_request	1	\N
85	1712517812	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	3129
86	1712517812	slow_user_request	1	\N
87	1712517812	user_request	1	\N
88	1712517813	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	1712517813
89	1712517922	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	2844
90	1712517922	slow_user_request	1	\N
91	1712517922	user_request	1	\N
92	1712517923	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	1712517923
93	1712517953	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1236
94	1712517953	slow_user_request	1	\N
95	1712517953	user_request	1	\N
96	1712518066	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	2048
97	1712518066	slow_user_request	1	\N
98	1712518066	user_request	1	\N
99	1712518067	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	1712518067
100	1712518177	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1635
101	1712518177	slow_user_request	1	\N
102	1712518177	user_request	1	\N
103	1712518208	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	2885
104	1712518282	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1165
105	1712518282	slow_user_request	1	\N
106	1712518282	user_request	1	\N
107	1712518541	user_request	1	\N
108	1712518721	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1079
109	1712518721	slow_user_request	1	\N
110	1712518721	user_request	1	\N
111	1712518886	user_request	1	\N
112	1712519065	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1401
113	1712519065	slow_user_request	1	\N
114	1712519065	user_request	1	\N
115	1712519740	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1502
116	1712519740	slow_user_request	1	\N
117	1712519740	user_request	1	\N
118	1712519747	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	2170
119	1712519747	slow_user_request	1	\N
120	1712519747	user_request	1	\N
121	1712519747	exception	["Illuminate\\\\Database\\\\QueryException","app\\\\Livewire\\\\SchoolFees.php:20"]	1712519747
122	1712519750	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	1249
123	1712519787	user_request	1	\N
124	1712519792	user_request	1	\N
125	1712519814	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	1065
126	1712519814	slow_user_request	1	\N
127	1712519814	user_request	1	\N
128	1712521947	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	1689
129	1712521947	slow_user_request	1	\N
130	1712521947	user_request	1	\N
131	1712521948	exception	["Livewire\\\\Exceptions\\\\EventHandlerDoesNotExist","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportEvents\\\\SupportEvents.php:23"]	1712521948
132	1712521980	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	2505
133	1712521980	slow_user_request	1	\N
134	1712521980	user_request	1	\N
135	1712521982	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	1712521982
136	1712522080	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	2372
137	1712522080	slow_user_request	1	\N
138	1712522080	user_request	1	\N
139	1712522081	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	1712522081
140	1712522135	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	2116
141	1712522135	slow_user_request	1	\N
142	1712522135	user_request	1	\N
143	1712522135	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	1712522135
144	1712522170	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	2042
145	1712522170	slow_user_request	1	\N
146	1712522170	user_request	1	\N
147	1712522170	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	1712522170
148	1712522217	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	3019
149	1712522217	slow_user_request	1	\N
150	1712522217	user_request	1	\N
151	1712522218	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	1712522218
152	1712522256	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	2889
153	1712522256	slow_user_request	1	\N
154	1712522256	user_request	1	\N
155	1712522258	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	1712522258
156	1712522291	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	2883
157	1712522291	slow_user_request	1	\N
158	1712522291	user_request	1	\N
159	1712522292	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	1712522292
160	1712522388	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1525
161	1712522388	slow_user_request	1	\N
162	1712522388	user_request	1	\N
163	1712652684	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	13592
164	1712652699	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	2250
165	1712652721	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	3939
166	1712652721	slow_user_request	1	\N
167	1712652721	user_request	1	\N
168	1712652725	user_request	1	\N
169	1712652726	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	1233
170	1712652726	slow_user_request	1	\N
171	1712652726	user_request	1	\N
172	1712652732	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	2081
173	1712652732	slow_user_request	1	\N
174	1712652732	user_request	1	\N
175	1712652748	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	1415
176	1712652748	slow_user_request	1	\N
177	1712652748	user_request	1	\N
178	1712652758	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	1293
179	1712652758	slow_user_request	1	\N
180	1712652758	user_request	1	\N
181	1712652766	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1023
182	1712652766	slow_user_request	1	\N
183	1712652766	user_request	1	\N
184	1712652773	user_request	1	\N
185	1712652783	user_request	1	\N
186	1712652788	user_request	1	\N
187	1712652804	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	1295
188	1712652804	slow_user_request	1	\N
189	1712652804	user_request	1	\N
190	1712652823	user_request	1	\N
191	1712652826	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	1150
192	1712652826	slow_user_request	1	\N
193	1712652826	user_request	1	\N
194	1712652834	user_request	1	\N
195	1712652954	user_request	1	\N
196	1712652960	user_request	1	\N
197	1712652980	user_request	1	\N
198	1712653029	user_request	1	\N
199	1712653043	user_request	1	\N
200	1712653072	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	1042
201	1712653072	slow_user_request	1	\N
202	1712653072	user_request	1	\N
203	1712653077	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	1227
204	1712653077	slow_user_request	1	\N
205	1712653077	user_request	1	\N
206	1712653088	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	1004
207	1712653088	slow_user_request	1	\N
208	1712653088	user_request	1	\N
209	1712653100	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	1165
210	1712653100	slow_user_request	1	\N
211	1712653100	user_request	1	\N
212	1712653111	slow_request	["POST","\\/ar\\/class_rooms","via \\/ar\\/livewire\\/update"]	1062
213	1712653111	slow_user_request	1	\N
214	1712653111	user_request	1	\N
215	1712653114	slow_request	["POST","\\/ar\\/class_rooms","via \\/ar\\/livewire\\/update"]	1331
216	1712653114	slow_user_request	1	\N
217	1712653114	user_request	1	\N
218	1712653611	user_request	1	\N
219	1712653615	user_request	1	\N
220	1712653833	user_request	1	\N
221	1712653852	user_request	1	\N
222	1712653992	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1452
223	1712653992	slow_user_request	1	\N
224	1712653992	user_request	1	\N
225	1712654075	user_request	1	\N
226	1712654424	user_request	1	\N
227	1712654461	user_request	1	\N
228	1712654950	user_request	1	\N
229	1712655025	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1993
230	1712655025	slow_user_request	1	\N
231	1712655025	user_request	1	\N
232	1712655026	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	1712655026
233	1712655063	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1856
234	1712655063	slow_user_request	1	\N
235	1712655063	user_request	1	\N
317	1712683870	user_request	1	\N
236	1712655063	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	1712655063
237	1712655115	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1026
238	1712655115	slow_user_request	1	\N
239	1712655115	user_request	1	\N
240	1712655165	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1096
241	1712655165	slow_user_request	1	\N
242	1712655165	user_request	1	\N
243	1712655225	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1075
244	1712655225	slow_user_request	1	\N
245	1712655225	user_request	1	\N
246	1712655256	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1037
247	1712655256	slow_user_request	1	\N
248	1712655256	user_request	1	\N
249	1712655290	user_request	1	\N
250	1712655297	user_request	1	\N
251	1712655304	user_request	1	\N
252	1712657650	user_request	1	\N
253	1712657875	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1024
254	1712657875	slow_user_request	1	\N
255	1712657875	user_request	1	\N
256	1712657928	user_request	1	\N
257	1712657993	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1122
258	1712657993	slow_user_request	1	\N
259	1712657993	user_request	1	\N
260	1712658221	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	2560
261	1712658221	slow_user_request	1	\N
262	1712658221	user_request	1	\N
263	1712658221	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\school_fees\\\\school-fees.blade.php"]	1712658221
264	1712658254	user_request	1	\N
265	1712658519	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1053
266	1712658519	slow_user_request	1	\N
267	1712658519	user_request	1	\N
268	1712658577	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1105
269	1712658577	slow_user_request	1	\N
270	1712658577	user_request	1	\N
271	1712658603	user_request	1	\N
272	1712659033	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1059
273	1712659033	slow_user_request	1	\N
274	1712659033	user_request	1	\N
275	1712659112	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1042
276	1712659112	slow_user_request	1	\N
277	1712659112	user_request	1	\N
278	1712659154	user_request	1	\N
279	1712659166	user_request	1	\N
280	1712659199	user_request	1	\N
281	1712659209	slow_request	["POST","\\/ar\\/school_fees","via \\/ar\\/livewire\\/update"]	1215
282	1712659209	slow_user_request	1	\N
283	1712659209	user_request	1	\N
284	1712659282	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1350
285	1712659282	slow_user_request	1	\N
286	1712659282	user_request	1	\N
287	1712659293	user_request	1	\N
288	1712659344	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1005
289	1712659344	slow_user_request	1	\N
290	1712659344	user_request	1	\N
291	1712659386	user_request	1	\N
292	1712659399	user_request	1	\N
293	1712659417	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1311
294	1712659417	slow_user_request	1	\N
295	1712659417	user_request	1	\N
296	1712659450	user_request	1	\N
297	1712659457	user_request	1	\N
298	1712659465	user_request	1	\N
299	1712659491	user_request	1	\N
301	1712659493	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	1457
300	1712659493	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	1402
302	1712683513	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	1765
303	1712683527	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	1745
304	1712683539	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	1003
305	1712683539	slow_user_request	1	\N
306	1712683539	user_request	1	\N
307	1712683540	user_request	1	\N
308	1712683541	user_request	1	\N
309	1712683546	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1365
310	1712683546	slow_user_request	1	\N
311	1712683546	user_request	1	\N
312	1712683696	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1135
313	1712683696	slow_user_request	1	\N
314	1712683696	user_request	1	\N
315	1712683870	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	2683
316	1712683870	slow_user_request	1	\N
318	1712683871	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	1712683871
319	1712683960	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1028
320	1712683960	slow_user_request	1	\N
321	1712683960	user_request	1	\N
322	1712684027	user_request	1	\N
323	1712684149	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	2131
324	1712684149	slow_user_request	1	\N
325	1712684149	user_request	1	\N
326	1712684150	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\index.blade.php"]	1712684150
327	1712684177	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1057
328	1712684177	slow_user_request	1	\N
329	1712684177	user_request	1	\N
330	1712684214	user_request	1	\N
331	1712687869	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	2306
332	1712687869	slow_user_request	1	\N
333	1712687869	user_request	1	\N
334	1712687870	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	1712687870
335	1712687952	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	2690
336	1712687952	slow_user_request	1	\N
337	1712687952	user_request	1	\N
338	1712687953	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	1712687953
339	1712687990	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	2229
340	1712687990	slow_user_request	1	\N
341	1712687990	user_request	1	\N
342	1712687991	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	1712687991
343	1712688069	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1771
344	1712688069	slow_user_request	1	\N
345	1712688069	user_request	1	\N
346	1712688069	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	1712688069
347	1712688863	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	2495
348	1712688863	slow_user_request	1	\N
349	1712688863	user_request	1	\N
350	1712688864	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\input.blade.php"]	1712688864
351	1712688894	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	2503
352	1712688894	slow_user_request	1	\N
353	1712688894	user_request	1	\N
354	1712688895	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\modal.blade.php"]	1712688895
355	1712688942	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	4461
356	1712688942	slow_user_request	1	\N
357	1712688942	user_request	1	\N
358	1712688944	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\index.blade.php"]	1712688944
359	1712688991	user_request	1	\N
360	1712689017	user_request	1	\N
361	1712689098	user_request	1	\N
362	1712689152	user_request	1	\N
363	1712689276	user_request	1	\N
364	1712689315	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1326
365	1712689315	slow_user_request	1	\N
366	1712689315	user_request	1	\N
367	1712689329	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	1716
368	1712689329	slow_user_request	1	\N
369	1712689329	user_request	1	\N
370	1712689330	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
371	1712689334	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	1747
372	1712689334	slow_user_request	1	\N
373	1712689334	user_request	1	\N
374	1712689335	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
375	1712689349	user_request	1	\N
376	1712689350	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
377	1712689353	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	1249
378	1712689353	slow_user_request	1	\N
379	1712689353	user_request	1	\N
380	1712689354	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
381	1712689360	user_request	1	\N
382	1712693756	user_request	1	\N
383	1712693767	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	1299
384	1712693767	slow_user_request	1	\N
385	1712693767	user_request	1	\N
386	1712693769	user_request	1	\N
387	1712693834	user_request	1	\N
388	1712693843	user_request	1	\N
389	1712693847	user_request	1	\N
390	1712693867	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1132
391	1712693867	slow_user_request	1	\N
392	1712693867	user_request	1	\N
393	1712693877	user_request	1	\N
394	1712693878	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	1023
395	1712693878	slow_user_request	1	\N
396	1712693878	user_request	1	\N
397	1712693910	user_request	1	\N
398	1712693920	user_request	1	\N
399	1712693921	user_request	1	\N
400	1712693972	user_request	1	\N
401	1712693986	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	1802
402	1712693986	slow_user_request	1	\N
403	1712693986	user_request	1	\N
404	1712693989	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	1051
405	1712694102	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1040
406	1712694102	slow_user_request	1	\N
407	1712694102	user_request	1	\N
408	1712694122	user_request	1	\N
409	1712694156	slow_request	["POST","\\/ar\\/grades","via \\/ar\\/livewire\\/update"]	1249
410	1712694156	slow_user_request	1	\N
411	1712694156	user_request	1	\N
412	1712694206	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	2842
413	1712694206	slow_user_request	1	\N
414	1712694206	user_request	1	\N
415	1712694207	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	1712694207
416	1712694314	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	1253
417	1712694314	slow_user_request	1	\N
418	1712694314	user_request	1	\N
419	1712694447	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	1124
420	1712694447	slow_user_request	1	\N
421	1712694447	user_request	1	\N
422	1712694459	user_request	1	\N
423	1712694464	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	1222
424	1712694464	slow_user_request	1	\N
425	1712694464	user_request	1	\N
426	1712694468	user_request	1	\N
427	1712694471	user_request	1	\N
428	1712694473	user_request	1	\N
429	1712694474	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	1041
430	1712694509	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	3973
431	1712694519	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	1407
432	1712694523	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	1466
433	1712694523	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	1477
434	1712694578	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	1746
435	1712694578	slow_user_request	1	\N
436	1712694578	user_request	1	\N
437	1712694598	user_request	1	\N
438	1712694599	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	1349
439	1712694599	slow_user_request	1	\N
440	1712694599	user_request	1	\N
441	1712694601	user_request	1	\N
442	1712694603	user_request	1	\N
443	1712694605	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	2121
444	1712694605	slow_user_request	1	\N
445	1712694605	user_request	1	\N
446	1712694606	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	1472
447	1712694613	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	1135
448	1712694612	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	2703
449	1712694612	slow_user_request	1	\N
450	1712694612	user_request	1	\N
451	1712694615	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	1601
452	1712694615	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	1558
453	1712694615	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	3089
454	1712694615	slow_user_request	1	\N
455	1712694615	user_request	1	\N
456	1712694618	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	1509
457	1712694619	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	1423
458	1712694622	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	1622
459	1712694624	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	1756
460	1712694665	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	2364
461	1712694680	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	3189
462	1712694696	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	1259
463	1712694696	slow_user_request	1	\N
464	1712694696	user_request	1	\N
465	1712694698	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	2119
466	1712694698	slow_user_request	1	\N
467	1712694698	user_request	1	\N
468	1712694714	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	2159
469	1712694714	slow_user_request	1	\N
470	1712694714	user_request	1	\N
471	1712694716	slow_request	["GET","\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	1008
472	1712694716	slow_user_request	1	\N
473	1712694716	user_request	1	\N
474	1712694718	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	1061
475	1712694718	slow_user_request	1	\N
476	1712694718	user_request	1	\N
477	1712694720	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	2264
478	1712694724	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1843
479	1712694724	slow_user_request	1	\N
480	1712694724	user_request	1	\N
481	1712694732	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	1797
482	1712694732	slow_user_request	1	\N
483	1712694732	user_request	1	\N
484	1712694733	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
485	1712694735	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	1756
486	1712694735	slow_user_request	1	\N
487	1712694735	user_request	1	\N
488	1712694736	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
489	1712694871	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	4636
490	1712694871	slow_user_request	1	\N
491	1712694871	user_request	1	\N
492	1712694874	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
493	1712694879	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	2167
494	1712694879	slow_user_request	1	\N
495	1712694879	user_request	1	\N
496	1712694881	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
497	1712694907	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	3272
498	1712694907	slow_user_request	1	\N
499	1712694907	user_request	1	\N
500	1712694907	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\components\\\\button.blade.php"]	1712694907
501	1712694934	slow_request	["GET","\\/ar\\/school_fees","\\\\Illuminate\\\\Routing\\\\ViewController"]	1298
502	1712694934	slow_user_request	1	\N
503	1712694934	user_request	1	\N
504	1712694981	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1228
505	1712694981	slow_user_request	1	\N
506	1712694981	user_request	1	\N
507	1712695193	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	1242
508	1712695193	slow_user_request	1	\N
509	1712695193	user_request	1	\N
510	1712695235	user_request	1	\N
511	1712695290	user_request	1	\N
512	1712695480	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1049
513	1712695480	slow_user_request	1	\N
514	1712695480	user_request	1	\N
515	1713211038	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	12649
516	1713211052	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	2171
517	1713211055	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	3484
518	1713220488	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	9492
519	1713220499	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	2671
520	1713220513	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	2445
521	1713220513	slow_user_request	1	\N
522	1713220513	user_request	1	\N
523	1713220516	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	2112
524	1713220516	slow_user_request	1	\N
525	1713220516	user_request	1	\N
526	1713220536	slow_request	["GET","\\/ar\\/class_rooms","\\\\Illuminate\\\\Routing\\\\ViewController"]	2067
527	1713221648	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	5986
528	1713221648	slow_user_request	1	\N
529	1713221648	user_request	1	\N
530	1713221651	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\table_row.blade.php"]	1713221651
531	1713221679	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	2109
532	1713221679	slow_user_request	1	\N
533	1713221679	user_request	1	\N
534	1713221680	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Grades\\\\table_row.blade.php"]	1713221680
535	1713221867	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1219
536	1713221867	slow_user_request	1	\N
537	1713221867	user_request	1	\N
538	1713221941	user_request	1	\N
539	1713222052	user_request	1	\N
540	1713222057	user_request	1	\N
541	1713222890	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	1895
542	1713222890	slow_user_request	1	\N
543	1713222890	user_request	1	\N
544	1713223338	user_request	1	\N
545	1713375165	slow_query	["select * from \\"grades\\" limit 1","Command line code:1"]	1420
546	1713389051	exception	["Symfony\\\\Component\\\\Console\\\\Exception\\\\NamespaceNotFoundException","vendor\\\\symfony\\\\console\\\\Application.php:669"]	1713389051
547	1713555289	slow_request	["GET","\\/","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	1214
548	1713555291	slow_request	["GET","\\/ar","App\\\\Http\\\\Controllers\\\\SettingsController@index"]	1567
549	1713555295	slow_request	["GET","\\/_debugbar\\/assets\\/stylesheets","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@css"]	1334
550	1713555296	slow_request	["GET","\\/_debugbar\\/assets\\/javascript","Barryvdh\\\\Debugbar\\\\Controllers\\\\AssetController@js"]	1090
551	1713555313	slow_request	["POST","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@store"]	1270
552	1713555313	slow_user_request	1	\N
553	1713555313	user_request	1	\N
554	1713555315	user_request	1	\N
555	1713555316	user_request	1	\N
556	1713555317	slow_request	["GET","\\/livewire\\/livewire.js","Livewire\\\\Mechanisms\\\\FrontendAssets\\\\FrontendAssets@returnJavaScriptAsFile"]	1040
557	1713555320	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	1777
558	1713555320	slow_user_request	1	\N
559	1713555320	user_request	1	\N
560	1713555321	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
561	1713555328	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	2831
562	1713555328	slow_user_request	1	\N
563	1713555328	user_request	1	\N
564	1713555330	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
565	1713555339	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	2118
566	1713555339	slow_user_request	1	\N
567	1713555339	user_request	1	\N
568	1713555341	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
569	1713555486	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	4994
570	1713555486	slow_user_request	1	\N
571	1713555486	user_request	1	\N
572	1713555489	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Student\\\\index.blade.php"]	1713555489
573	1713555511	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	2943
574	1713555511	slow_user_request	1	\N
575	1713555511	user_request	1	\N
576	1713555513	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Student\\\\index.blade.php"]	1713555513
577	1713555581	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	10192
578	1713555581	slow_user_request	1	\N
579	1713555581	user_request	1	\N
580	1713555583	cache_miss	powerGridTheme_App\\Helpers\\PowerGridThemes\\TailwindStriped	\N
581	1713555583	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\livewire\\\\Student\\\\index.blade.php"]	1713555583
582	1713555591	cache_miss	powerGridTheme_App\\Helpers\\PowerGridThemes\\TailwindStriped	\N
583	1713555591	cache_miss	powerGridTheme_App\\Helpers\\PowerGridThemes\\TailwindStriped	\N
584	1713555591	cache_miss	powerGridTheme_App\\Helpers\\PowerGridThemes\\TailwindStriped	\N
585	1713555591	cache_miss	powerGridTheme_App\\Helpers\\PowerGridThemes\\TailwindStriped	\N
586	1713555591	cache_miss	powerGridTheme_App\\Helpers\\PowerGridThemes\\TailwindStriped	\N
587	1713555591	cache_miss	powerGridTheme_App\\Helpers\\PowerGridThemes\\TailwindStriped	\N
588	1713555656	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	2426
589	1713555656	slow_user_request	1	\N
590	1713555656	user_request	1	\N
591	1713555658	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
592	1713555664	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	3947
593	1713555664	slow_user_request	1	\N
594	1713555664	user_request	1	\N
595	1713555667	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
596	1713555669	slow_request	["GET","\\/_debugbar\\/open","Barryvdh\\\\Debugbar\\\\Controllers\\\\OpenHandlerController@handle"]	1254
597	1713555697	user_request	1	\N
598	1713555698	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
599	1713555701	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	1583
600	1713555701	slow_user_request	1	\N
601	1713555701	user_request	1	\N
602	1713555702	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
603	1713558782	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	3111
604	1713558786	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	1607
605	1713558792	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	2013
606	1713558792	slow_user_request	1	\N
607	1713558792	user_request	1	\N
608	1713558802	user_request	1	\N
609	1713558835	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	2242
610	1713558838	slow_request	["GET","\\/ar\\/login","App\\\\Http\\\\Controllers\\\\Auth\\\\AuthenticatedSessionController@create"]	1623
611	1713558942	slow_request	["GET","\\/ar\\/parents","\\\\Illuminate\\\\Routing\\\\ViewController"]	2325
612	1713558942	slow_user_request	1	\N
613	1713558942	user_request	1	\N
614	1713558953	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	1162
615	1713558953	slow_user_request	1	\N
616	1713558953	user_request	1	\N
617	1713558955	user_request	1	\N
618	1713558966	user_request	1	\N
619	1713558974	slow_request	["POST","\\/ar\\/parents","via \\/ar\\/livewire\\/update"]	1024
620	1713558974	slow_user_request	1	\N
621	1713558974	user_request	1	\N
622	1713559095	slow_request	["GET","\\/ar\\/students","\\\\Illuminate\\\\Routing\\\\ViewController"]	1801
623	1713559095	slow_user_request	1	\N
624	1713559095	user_request	1	\N
625	1713559096	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
626	1713559099	slow_request	["POST","\\/ar\\/students","via \\/ar\\/livewire\\/update"]	1978
627	1713559099	slow_user_request	1	\N
628	1713559099	user_request	1	\N
629	1713559101	cache_hit	powerGridTheme_PowerComponents\\LivewirePowerGrid\\Themes\\Tailwind	\N
630	1713559102	user_request	1	\N
631	1713559114	user_request	1	\N
632	1713559121	user_request	1	\N
633	1713559390	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	2180
634	1713559390	slow_user_request	1	\N
635	1713559390	user_request	1	\N
636	1713559391	exception	["Error","app\\\\Http\\\\Controllers\\\\HomeController.php:9"]	1713559391
637	1713559432	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	1004
638	1713559432	slow_user_request	1	\N
639	1713559432	user_request	1	\N
640	1713559468	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	1395
641	1713559468	slow_user_request	1	\N
642	1713559468	user_request	1	\N
643	1713559570	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	1099
644	1713559570	slow_user_request	1	\N
645	1713559570	user_request	1	\N
646	1713559608	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	1428
647	1713559608	slow_user_request	1	\N
648	1713559608	user_request	1	\N
649	1713560314	user_request	1	\N
650	1713560668	user_request	1	\N
651	1713560677	slow_request	["GET","\\/ar\\/grades","App\\\\Livewire\\\\Grades@__invoke"]	1776
652	1713560677	slow_user_request	1	\N
653	1713560677	user_request	1	\N
654	1713560678	exception	["Illuminate\\\\Contracts\\\\Container\\\\BindingResolutionException","vendor\\\\laravel\\\\framework\\\\src\\\\Illuminate\\\\Container\\\\BoundMethod.php:188"]	1713560678
655	1713560702	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1417
656	1713560702	slow_user_request	1	\N
657	1713560702	user_request	1	\N
658	1713560927	user_request	1	\N
659	1713560933	user_request	1	\N
660	1713560942	slow_request	["GET","\\/ar\\/dashboard","App\\\\Http\\\\Controllers\\\\HomeController@index"]	1227
661	1713560942	slow_user_request	1	\N
662	1713560942	user_request	1	\N
663	1713561396	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1175
664	1713561396	slow_user_request	1	\N
665	1713561396	user_request	1	\N
666	1713561990	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	3814
667	1713561990	slow_user_request	1	\N
668	1713561990	user_request	1	\N
669	1713561991	exception	["Illuminate\\\\View\\\\ViewException","resources\\\\views\\\\layouts\\\\sidebar.blade.php"]	1713561991
670	1713562015	slow_request	["GET","\\/ar\\/grades","\\\\Illuminate\\\\Routing\\\\ViewController"]	1357
671	1713562015	slow_user_request	1	\N
672	1713562015	user_request	1	\N
673	1713562023	user_request	1	\N
674	1713563904	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	5792
675	1713563904	slow_user_request	1	\N
676	1713563904	user_request	1	\N
677	1713563905	exception	["ErrorException","resources\\\\views\\\\backend\\\\backup\\\\index.blade.php"]	1713563905
678	1713563995	exception	["Spatie\\\\Backup\\\\Exceptions\\\\BackupFailed","vendor\\\\spatie\\\\laravel-backup\\\\src\\\\Exceptions\\\\BackupFailed.php:17"]	1713563995
679	1713563998	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","vendor\\\\symfony\\\\mailer\\\\Transport\\\\Smtp\\\\Stream\\\\SocketStream.php:154"]	1713563998
680	1713564073	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	2400
681	1713564073	slow_user_request	1	\N
682	1713564073	user_request	1	\N
683	1713564299	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","vendor\\\\symfony\\\\mailer\\\\Transport\\\\Smtp\\\\Stream\\\\SocketStream.php:154"]	1713564299
684	1713564842	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	1114
685	1713564842	slow_user_request	1	\N
686	1713564842	user_request	1	\N
687	1713564852	slow_request	["GET","\\/ar\\/backup\\/create","App\\\\Http\\\\Controllers\\\\BackupController@create"]	6818
688	1713564852	slow_user_request	1	\N
689	1713564852	user_request	1	\N
690	1713564857	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:17"]	1713564857
691	1713564857	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	1713564857
692	1713565023	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	12373
693	1713565023	slow_user_request	1	\N
694	1713565023	user_request	1	\N
695	1713565027	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:13"]	1713565027
696	1713565135	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	6870
697	1713565135	slow_user_request	1	\N
698	1713565135	user_request	1	\N
699	1713565137	slow_query	["select * from \\"users\\" where \\"id\\" = ? limit 1","vendor\\\\livewire\\\\livewire\\\\src\\\\Features\\\\SupportDisablingBackButtonCache\\\\DisableBackButtonCacheMiddleware.php:19"]	1101
700	1713565139	exception	["Carbon\\\\Exceptions\\\\InvalidFormatException","app\\\\Http\\\\Controllers\\\\BackupController.php:13"]	1713565139
701	1713565274	user_request	1	\N
702	1713565314	user_request	1	\N
703	1713565336	slow_request	["GET","\\/ar\\/backup","App\\\\Http\\\\Controllers\\\\BackupController@index"]	1711
704	1713565336	slow_user_request	1	\N
705	1713565336	user_request	1	\N
706	1713565342	slow_request	["GET","\\/ar\\/backup\\/create","App\\\\Http\\\\Controllers\\\\BackupController@create"]	8514
707	1713565342	slow_user_request	1	\N
708	1713565342	user_request	1	\N
709	1713565349	exception	["Symfony\\\\Component\\\\Mailer\\\\Exception\\\\TransportException","app\\\\Http\\\\Controllers\\\\BackupController.php:18"]	1713565349
710	1713565349	exception	["Illuminate\\\\Database\\\\Eloquent\\\\MassAssignmentException","app\\\\Http\\\\Controllers\\\\BackupController.php:20"]	1713565349
\.


--
-- Data for Name: pulse_values; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pulse_values (id, "timestamp", type, key, value) FROM stdin;
\.


--
-- Data for Name: school_fees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.school_fees (id, grade_id, classroom_id, user_id, description, amount, created_at, updated_at) FROM stdin;
1	1	19	1	ut	2454.00	2024-04-07 20:27:19	2024-04-07 20:27:19
2	1	38	1	voluptatem	5740.00	2024-04-07 20:27:19	2024-04-07 20:27:19
3	3	37	1	omnis	3628.00	2024-04-07 20:27:19	2024-04-07 20:27:19
4	2	40	1	cupiditate	3641.00	2024-04-07 20:27:19	2024-04-07 20:27:19
5	4	50	1	voluptatem	1385.00	2024-04-07 20:27:19	2024-04-07 20:27:19
6	3	20	1	totam	6895.00	2024-04-07 20:27:19	2024-04-07 20:27:19
7	1	13	1	est	9416.00	2024-04-07 20:27:19	2024-04-07 20:27:19
8	4	24	1	repellendus	3291.00	2024-04-07 20:27:19	2024-04-07 20:27:19
9	1	4	1	voluptates	4096.00	2024-04-07 20:27:19	2024-04-07 20:27:19
10	1	35	1	sint	3443.00	2024-04-07 20:27:19	2024-04-07 20:27:19
11	1	19	1	quam	9402.00	2024-04-07 20:27:19	2024-04-07 20:27:19
12	3	6	1	aliquid	8981.00	2024-04-07 20:27:19	2024-04-07 20:27:19
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settings (id, school_name, phone, address, created_at, updated_at) FROM stdin;
1	Hintz PLC	1-650-902-7492	557 Joshuah Road Apt. 559\nBoyerborough, MS 90508-2949	2024-04-07 20:27:16	2024-04-07 20:27:16
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.students (id, name, birth_date, address, join_date, gender, user_id, grade_id, classroom_id, parent_id, created_at, updated_at) FROM stdin;
1	Burdette Romaguera	2002-09-07	81400 Aufderhar Manor Apt. 022\nGreenborough, TX 37547	1994-05-16	female	1	4	4	140	2024-04-07 20:27:20	2024-04-07 20:27:20
2	Mr. Jameson Altenwerth I	1987-03-02	654 Annabel Ways Suite 770\nDonaldmouth, WA 91527-6268	1980-04-20	male	1	1	38	92	2024-04-07 20:27:20	2024-04-07 20:27:20
3	Myrtice Thompson	1989-08-05	797 Robel Dam Suite 652\nHandstad, VA 81497-0738	2000-09-03	female	1	4	28	65	2024-04-07 20:27:20	2024-04-07 20:27:20
4	Lourdes Ondricka	2008-11-18	12362 Paige Drive Apt. 718\nEast Franzburgh, IL 52050-2664	2014-11-01	male	1	4	26	55	2024-04-07 20:27:20	2024-04-07 20:27:20
5	Mafalda Stroman V	1974-01-03	35893 Sheila Mountains\nEast Erichaven, WI 96197	1975-01-11	female	1	1	4	159	2024-04-07 20:27:20	2024-04-07 20:27:20
6	Amir Harris	2002-04-08	49991 Yessenia Flat Suite 472\nKutchview, SC 65855	1997-01-06	male	1	3	36	8	2024-04-07 20:27:20	2024-04-07 20:27:20
7	Howard Johns	1996-11-15	4974 Jacobs Landing\nSauerbury, ID 15969-8909	1979-04-15	male	1	1	11	24	2024-04-07 20:27:20	2024-04-07 20:27:20
8	Osborne Crona	2007-04-18	684 Balistreri Way Suite 581\nMillston, UT 08375-0339	1977-02-20	male	1	2	19	200	2024-04-07 20:27:20	2024-04-07 20:27:20
9	Travis Waters	2021-04-24	961 Robel Shoals\nPhilipmouth, NE 11346	1980-02-12	female	1	4	47	85	2024-04-07 20:27:20	2024-04-07 20:27:20
10	Dr. Kris Halvorson PhD	1996-07-19	437 Branson Extensions\nLindgrenfort, DE 36885-4291	1979-10-03	male	1	1	21	101	2024-04-07 20:27:20	2024-04-07 20:27:20
11	Edyth Considine	2008-11-22	4409 Alfonso Mews\nNorth Enos, NJ 87242	1995-04-15	male	1	3	9	61	2024-04-07 20:27:20	2024-04-07 20:27:20
12	Rosanna Walsh	1996-11-04	12048 Aufderhar Corners Suite 562\nBentonton, CT 38572	1983-01-13	male	1	2	47	123	2024-04-07 20:27:20	2024-04-07 20:27:20
13	Mac Frami MD	1976-03-04	3339 Robbie Lights Apt. 273\nPort Demarcus, RI 63671	2018-01-27	female	1	2	17	176	2024-04-07 20:27:20	2024-04-07 20:27:20
14	Reggie Reichert	1974-09-07	139 Jude Ports\nGloriaburgh, UT 03440	1995-11-26	male	1	1	30	165	2024-04-07 20:27:20	2024-04-07 20:27:20
15	Buddy Schiller PhD	1973-10-18	203 Braun Isle\nWest Hayleyburgh, ND 87964-7351	2000-09-16	female	1	3	11	1	2024-04-07 20:27:20	2024-04-07 20:27:20
16	Wiley Wolff	1971-06-05	89726 Hipolito Neck\nEmeraldview, WY 89930-6815	2012-09-04	male	1	3	33	73	2024-04-07 20:27:20	2024-04-07 20:27:20
17	Ms. Bryana Beahan MD	1984-02-16	21712 Jenkins Forges Apt. 971\nLake Malikaton, TN 68360	2000-05-25	male	1	4	14	38	2024-04-07 20:27:20	2024-04-07 20:27:20
18	Elissa O'Kon MD	1982-05-04	47222 Greenfelder Curve\nNew Alysha, ME 93968	1971-07-09	female	1	2	8	179	2024-04-07 20:27:20	2024-04-07 20:27:20
19	Cody Reynolds	2016-05-18	9910 Annamarie Turnpike Apt. 843\nWest Aric, GA 77309-7131	1996-11-10	male	1	1	3	173	2024-04-07 20:27:20	2024-04-07 20:27:20
20	Ericka Marvin	1985-06-01	18264 Kaitlin Mills\nPort Dayton, MA 43505-6878	2001-09-06	male	1	2	18	44	2024-04-07 20:27:20	2024-04-07 20:27:20
21	Lavonne Stiedemann	1990-03-04	42286 McClure Drive Suite 091\nNorth Ottobury, NV 42340-9782	1979-04-15	female	1	4	20	173	2024-04-07 20:27:20	2024-04-07 20:27:20
22	Mateo Miller	2022-02-25	4835 Turcotte Mission\nMcLaughlinbury, TX 45090	1971-10-17	male	1	1	4	172	2024-04-07 20:27:20	2024-04-07 20:27:20
23	Mac Corkery MD	2005-02-16	1694 Ebert Square Apt. 876\nWest Kaela, MO 96935	1981-06-06	female	1	1	20	136	2024-04-07 20:27:20	2024-04-07 20:27:20
24	Raphaelle Ryan	1980-06-22	386 Marc Spur\nMedhurstburgh, UT 11178	1974-02-23	male	1	2	13	195	2024-04-07 20:27:20	2024-04-07 20:27:20
25	Miss Cayla Sporer	2020-08-05	377 Zieme Plain Suite 500\nHershelfort, ID 37189	2003-12-06	female	1	1	43	65	2024-04-07 20:27:20	2024-04-07 20:27:20
26	Amara Larkin	2001-11-27	51842 Nader Street Suite 051\nMorartown, AK 95093-0530	2005-08-15	male	1	4	19	194	2024-04-07 20:27:20	2024-04-07 20:27:20
27	Sylvan Berge	2000-03-20	455 Zetta Loaf\nEast Stefanie, KY 72000-1380	1973-03-03	male	1	1	24	152	2024-04-07 20:27:20	2024-04-07 20:27:20
28	Prof. Litzy Effertz PhD	2017-01-29	4062 Sanford Isle Suite 758\nKulasborough, TX 58750-8628	1982-02-06	male	1	3	6	173	2024-04-07 20:27:20	2024-04-07 20:27:20
29	Hubert Pollich	2009-10-10	19021 McDermott Locks\nNorth Alia, UT 66982-8703	2007-03-21	female	1	1	39	76	2024-04-07 20:27:20	2024-04-07 20:27:20
30	Hayden Lubowitz Jr.	2021-07-25	54662 Runolfsdottir Square Apt. 955\nNew Jordontown, UT 61615-9706	2023-12-08	female	1	3	33	159	2024-04-07 20:27:20	2024-04-07 20:27:20
31	Aleen Swift	1980-05-22	366 Heathcote Squares\nSouth Carrie, RI 90396-6550	1992-02-25	male	1	2	19	11	2024-04-07 20:27:20	2024-04-07 20:27:20
32	Monserrate Wyman	2003-02-26	63221 Moen Prairie\nNorth Providencishire, OR 30353	2005-09-30	male	1	3	3	159	2024-04-07 20:27:20	2024-04-07 20:27:20
33	Prof. Wilford Romaguera I	1990-06-17	271 Koelpin Dale\nLake Leonardo, AR 19139	2017-04-17	male	1	2	5	122	2024-04-07 20:27:20	2024-04-07 20:27:20
34	German Ondricka II	1986-04-16	4976 Stanton Heights\nLake Neomamouth, IN 34410-1262	2004-02-05	male	1	4	46	74	2024-04-07 20:27:20	2024-04-07 20:27:20
35	Erika Hyatt	2007-01-29	3164 Emil Points\nTurnerport, OK 59899	2004-05-16	male	1	1	27	77	2024-04-07 20:27:20	2024-04-07 20:27:20
36	Llewellyn Beier	2010-09-23	5111 Hyatt Via\nGaylordside, MI 66310	1990-11-03	male	1	4	17	68	2024-04-07 20:27:20	2024-04-07 20:27:20
37	Haleigh Hills	2021-05-04	75554 Carolyne Groves Apt. 600\nNew Freedabury, NC 03076-5944	2017-07-07	female	1	3	27	85	2024-04-07 20:27:20	2024-04-07 20:27:20
38	Virgil D'Amore	2005-12-18	503 Skyla Ports\nOlsonmouth, ND 41352	1982-01-22	female	1	1	21	114	2024-04-07 20:27:20	2024-04-07 20:27:20
39	Jayme Wunsch	1990-10-08	96615 Darius Shores Apt. 197\nNew Allieview, FL 97779-9246	1987-07-06	female	1	1	20	198	2024-04-07 20:27:20	2024-04-07 20:27:20
40	Danny Moen	2010-01-31	74913 Audreanne Shore\nWeissnatberg, MS 18308-3086	1994-01-19	male	1	1	28	177	2024-04-07 20:27:20	2024-04-07 20:27:20
41	Miss Aurore Hansen	2019-04-14	58422 Michael Forge Suite 524\nWest Triston, NH 46363-8347	1987-08-26	female	1	1	13	185	2024-04-07 20:27:20	2024-04-07 20:27:20
42	Gerald Fay	1995-06-29	805 Hill Rest Apt. 048\nLaurelstad, ME 16823	1976-11-06	male	1	3	50	139	2024-04-07 20:27:20	2024-04-07 20:27:20
43	Dr. Joanne Gleason I	2003-01-30	866 Raheem Corner\nPort Dennisville, NM 22070-5812	2004-06-10	female	1	3	47	99	2024-04-07 20:27:20	2024-04-07 20:27:20
44	Tess Bernier	1998-02-01	505 Wolff Plains\nLake Dianahaven, NE 54084-5839	1991-12-12	female	1	3	29	60	2024-04-07 20:27:20	2024-04-07 20:27:20
45	Meta Schumm	1979-09-20	5437 Sauer Oval Apt. 819\nWest Ednaside, NH 31847	1998-05-10	male	1	2	32	87	2024-04-07 20:27:20	2024-04-07 20:27:20
46	Dr. Giovanna O'Keefe V	2016-10-05	9975 Christiansen Inlet\nSouth Millerchester, DE 31484-3032	1994-05-08	female	1	2	38	142	2024-04-07 20:27:20	2024-04-07 20:27:20
47	Karina Mills	1996-10-11	87270 Henderson Springs\nHermannborough, WV 71364-5098	2019-10-02	male	1	1	32	95	2024-04-07 20:27:20	2024-04-07 20:27:20
48	Eulalia Quitzon V	1984-12-20	31061 Nakia Street Apt. 058\nWest Jillianmouth, TN 88472-8896	1974-02-18	male	1	4	30	1	2024-04-07 20:27:20	2024-04-07 20:27:20
49	Ms. Delilah Gutmann DVM	1992-05-14	78365 Linnea Spring\nSchmidtfurt, NE 92006	1981-02-04	male	1	3	25	25	2024-04-07 20:27:20	2024-04-07 20:27:20
50	Prof. Estelle Schmidt PhD	2002-12-20	186 Wilber Roads\nLake Titofurt, CO 39534-0672	2010-04-27	female	1	3	31	39	2024-04-07 20:27:20	2024-04-07 20:27:20
51	Dr. Maybelle Auer	1979-10-03	18781 Torphy Road\nOvaport, AZ 19581-6793	1975-05-26	female	1	2	28	188	2024-04-07 20:27:20	2024-04-07 20:27:20
52	Mrs. Crystal Boehm	1976-12-25	216 Alexandre Spring Apt. 275\nAnnieville, MD 19210-5258	1972-07-31	female	1	3	45	60	2024-04-07 20:27:20	2024-04-07 20:27:20
53	Jonas Hyatt	1990-06-04	32076 Reece Radial\nNorth Kamronland, SC 54504	1992-08-15	male	1	1	2	198	2024-04-07 20:27:20	2024-04-07 20:27:20
54	Tamia Wyman	1982-04-30	493 Kiley Meadows\nBoganfurt, AL 98262	2023-11-22	female	1	3	29	168	2024-04-07 20:27:20	2024-04-07 20:27:20
55	Wiley Morissette	1990-11-24	59141 Wilmer Pine\nLake Nolastad, IN 01865	2013-09-18	male	1	1	8	154	2024-04-07 20:27:20	2024-04-07 20:27:20
56	Gloria Crooks III	2016-12-16	7074 Zackery Walks\nPort Margieburgh, MA 47151-6524	2004-07-25	female	1	3	34	167	2024-04-07 20:27:20	2024-04-07 20:27:20
57	Imelda Fritsch IV	1992-08-20	8185 Gorczany Light\nNorth Immanuel, SC 75341	2014-09-13	male	1	4	31	123	2024-04-07 20:27:20	2024-04-07 20:27:20
58	Patsy Fahey	1985-08-14	3812 Jaime Mews\nAmanibury, SD 65647-5622	1993-04-23	male	1	4	17	170	2024-04-07 20:27:20	2024-04-07 20:27:20
59	Salvador Johnson	2016-10-21	3852 Stella Shoals Suite 079\nNorth Cassandraburgh, MS 50779	2013-08-29	male	1	2	19	47	2024-04-07 20:27:20	2024-04-07 20:27:20
60	Benjamin Grimes	1975-04-09	895 Rudy Throughway Suite 607\nKlington, NH 83630	2005-10-11	male	1	4	45	181	2024-04-07 20:27:20	2024-04-07 20:27:20
61	Eldora Kertzmann	1984-12-13	5695 Eichmann Stravenue\nHoegerberg, IL 30125-9272	1970-03-24	male	1	4	31	193	2024-04-07 20:27:20	2024-04-07 20:27:20
62	Imelda Rosenbaum	2008-09-14	967 Sheila Estates Apt. 142\nTillmanview, OK 81380	2004-09-04	male	1	3	14	7	2024-04-07 20:27:20	2024-04-07 20:27:20
63	Dr. Jameson Schroeder DDS	1986-08-04	80245 Botsford Ferry\nNew Bernadette, WI 76577-6820	2006-07-29	male	1	4	48	82	2024-04-07 20:27:20	2024-04-07 20:27:20
64	Skylar Franecki	2003-02-02	6842 Ramon Drive Apt. 759\nHoppeside, KY 30577-1227	1971-10-14	male	1	1	6	161	2024-04-07 20:27:20	2024-04-07 20:27:20
65	Dr. Rico Schultz	2015-05-05	78911 Kiana Forge Suite 139\nClarabellemouth, NJ 42897	1995-01-04	male	1	2	32	182	2024-04-07 20:27:20	2024-04-07 20:27:20
66	Mr. Alford Wolff	1981-02-02	808 Ally Shoals\nLangoshside, SD 86477	1986-12-13	female	1	2	9	63	2024-04-07 20:27:20	2024-04-07 20:27:20
67	Dr. Gianni Nikolaus V	2009-04-09	65010 Stiedemann Route Suite 425\nLake Leonora, CT 20105	1971-11-30	male	1	1	34	49	2024-04-07 20:27:20	2024-04-07 20:27:20
68	Malinda Hintz	2013-05-20	7050 Fisher Walks Suite 787\nPort Joelleshire, SC 24222	1997-06-25	female	1	4	50	49	2024-04-07 20:27:20	2024-04-07 20:27:20
69	Alexandria Mohr	1988-05-07	631 Parisian Throughway\nLake Javonchester, CT 31100	2020-10-29	female	1	4	20	70	2024-04-07 20:27:20	2024-04-07 20:27:20
70	Layla Nader	2020-05-18	2975 Gulgowski Trail\nPort Zelma, IL 83829-0350	2016-05-24	male	1	3	34	76	2024-04-07 20:27:20	2024-04-07 20:27:20
71	Mr. Derrick Mohr II	2001-04-14	65945 Sandy Mountain Apt. 840\nBrodystad, KY 04170-3036	2006-12-01	female	1	4	27	193	2024-04-07 20:27:20	2024-04-07 20:27:20
72	Ally Wolf	2020-08-29	36748 Davion View\nNelsonland, WV 59064-4703	2000-12-13	male	1	4	37	157	2024-04-07 20:27:20	2024-04-07 20:27:20
73	Dr. Reilly Buckridge	2012-05-16	30280 Gislason Pine Suite 849\nNorth Mortonbury, VA 88598	2017-09-16	male	1	1	18	179	2024-04-07 20:27:20	2024-04-07 20:27:20
74	Mikel Schmidt	1977-10-17	5457 Eda Burg\nPort Rogers, KS 91778-7026	1990-03-15	female	1	4	5	189	2024-04-07 20:27:20	2024-04-07 20:27:20
75	Henri Botsford	1989-01-21	975 Albina Tunnel\nEast Carol, HI 44703-8074	2007-12-05	male	1	1	45	50	2024-04-07 20:27:20	2024-04-07 20:27:20
76	Miss Tianna Beier III	1985-08-01	89699 Minerva Estate\nLadariusside, IL 61133	1974-03-08	male	1	4	30	105	2024-04-07 20:27:20	2024-04-07 20:27:20
77	Devan Larson	1998-10-16	751 Allison Locks Suite 135\nWest Aydenfort, TN 44969	2010-06-30	male	1	1	46	24	2024-04-07 20:27:20	2024-04-07 20:27:20
78	Alfred Boehm I	1985-01-29	254 Hills Valleys Suite 727\nPort Vestaville, VA 81075-8535	1975-05-12	female	1	2	45	190	2024-04-07 20:27:20	2024-04-07 20:27:20
79	Mr. Filiberto Hoeger I	2018-05-30	96574 Noe Parks\nNew Colten, AK 17465	2022-08-10	male	1	4	16	104	2024-04-07 20:27:20	2024-04-07 20:27:20
80	Prof. Horace Herzog	1982-05-28	845 Friedrich Villages\nLake Oceane, ND 13882	1995-10-16	male	1	4	25	100	2024-04-07 20:27:20	2024-04-07 20:27:20
81	Dr. Rasheed Wyman	1990-03-28	791 Demetris Cliff\nReillymouth, KY 81314	1976-09-07	male	1	1	34	56	2024-04-07 20:27:20	2024-04-07 20:27:20
82	Cydney Gerhold I	2020-02-13	50083 Loraine Harbor\nSouth Melanybury, DE 60076	2001-08-30	male	1	3	38	173	2024-04-07 20:27:20	2024-04-07 20:27:20
83	Mrs. Michelle Kohler III	1982-10-01	937 Georgette Divide Suite 385\nNew Gayle, CO 26635-6199	2022-08-13	female	1	2	30	66	2024-04-07 20:27:20	2024-04-07 20:27:20
84	Jacques Dicki	2019-11-09	94224 Nitzsche Forest\nDuBuqueport, IA 73467-0156	2020-10-09	male	1	1	35	170	2024-04-07 20:27:20	2024-04-07 20:27:20
85	Howell Stark III	2017-02-21	820 McKenzie Plains\nMyamouth, MS 21352-1186	1990-06-08	female	1	4	9	152	2024-04-07 20:27:20	2024-04-07 20:27:20
86	Mr. Emory Wisozk	1978-03-26	3610 Zula Street Suite 067\nPort Oswald, ID 67228	2001-08-13	female	1	3	15	173	2024-04-07 20:27:20	2024-04-07 20:27:20
87	Mr. Flavio Mann Sr.	1988-04-24	66023 Zemlak Neck\nNorth Hassietown, SC 89718-1864	2001-01-07	female	1	1	23	182	2024-04-07 20:27:20	2024-04-07 20:27:20
88	Mr. Mackenzie Ledner	1998-09-28	4969 Roman Squares Suite 658\nPort Madeline, AZ 81167	2019-03-04	male	1	1	7	45	2024-04-07 20:27:20	2024-04-07 20:27:20
89	Shannon Becker	2020-09-10	678 Kshlerin Villages Apt. 264\nPort Winfield, NV 01558-3841	2016-11-03	male	1	1	44	47	2024-04-07 20:27:20	2024-04-07 20:27:20
90	Mr. Ephraim Trantow	1970-09-16	61408 Medhurst Bridge Apt. 437\nEast Eduardoshire, TN 10561	1978-03-07	female	1	1	10	23	2024-04-07 20:27:20	2024-04-07 20:27:20
91	Maverick Reinger DDS	2016-07-08	657 Fisher Ranch Apt. 299\nDollyfort, NY 03976-6407	1992-02-12	male	1	1	49	169	2024-04-07 20:27:20	2024-04-07 20:27:20
92	Prof. Gardner Greenfelder PhD	1972-10-18	643 Mosciski Alley\nTreutelshire, NM 96351-5899	2005-12-02	male	1	1	10	101	2024-04-07 20:27:20	2024-04-07 20:27:20
93	Carroll Crist	2013-06-21	480 Jamir Stream Suite 725\nEverettport, VT 27015-2584	1985-04-14	male	1	2	27	33	2024-04-07 20:27:20	2024-04-07 20:27:20
94	Dr. Kirk Sawayn	2017-03-12	691 Will Square Suite 142\nSporerhaven, OH 61865-1470	2022-03-10	male	1	3	24	13	2024-04-07 20:27:20	2024-04-07 20:27:20
95	Rowena Rippin	1988-01-21	195 Grant Drive Apt. 866\nNorth Kaylieborough, NV 79772-7682	2021-02-01	male	1	2	15	146	2024-04-07 20:27:20	2024-04-07 20:27:20
96	Ken Kessler	2022-12-14	24458 Margaret Ports Suite 358\nSouth Alisonfort, TN 68315-5686	2011-11-05	female	1	3	19	192	2024-04-07 20:27:20	2024-04-07 20:27:20
97	Miss Maurine Abernathy	1974-10-30	15550 Heather Centers Apt. 792\nBahringerport, NC 05553	1981-03-26	female	1	2	10	183	2024-04-07 20:27:20	2024-04-07 20:27:20
98	Arielle Boyle MD	1983-10-03	92682 Reilly Lane\nPort Dameon, AR 75902	2015-05-11	male	1	1	33	15	2024-04-07 20:27:20	2024-04-07 20:27:20
99	Mr. Grover Johns I	1985-01-18	6434 Eden Common Apt. 019\nSouth Donnellfurt, ME 27014	1989-04-28	male	1	2	49	125	2024-04-07 20:27:20	2024-04-07 20:27:20
100	Jamel Harber	1999-12-05	4915 Orval Mall Suite 533\nAndersonmouth, IA 80777	1984-09-14	female	1	3	27	90	2024-04-07 20:27:20	2024-04-07 20:27:20
101	Johan Senger III	1996-01-06	18714 Charity Roads Suite 743\nLake Kristinshire, NJ 45318	1996-04-21	female	1	3	44	167	2024-04-07 20:27:20	2024-04-07 20:27:20
102	Jermey Heaney MD	2016-10-11	1088 Lisa Mission Apt. 115\nPort Arvilla, NC 03885-8548	2013-12-20	female	1	3	41	144	2024-04-07 20:27:20	2024-04-07 20:27:20
103	Shawn Wolf IV	1991-09-11	8839 Viva Neck Apt. 675\nCollierberg, VT 75915-3139	1974-08-19	male	1	4	39	138	2024-04-07 20:27:20	2024-04-07 20:27:20
104	Ricardo Walter	2007-08-24	78496 Judd Ways\nSouth Raina, CO 84273-8268	2019-06-18	male	1	2	10	32	2024-04-07 20:27:20	2024-04-07 20:27:20
105	Emanuel Kihn	1974-06-11	8915 Champlin Lake\nWest Darien, TN 12637-0213	1999-11-09	male	1	1	49	67	2024-04-07 20:27:20	2024-04-07 20:27:20
106	Karlee Hermiston	1976-05-05	38681 Gerhold Lodge Suite 299\nEast Theodora, WA 11532-0843	1980-05-26	male	1	1	8	72	2024-04-07 20:27:20	2024-04-07 20:27:20
107	Norval Yost	1978-11-23	87037 Maggio Throughway Suite 350\nNew Dejah, AL 36604	2024-04-06	male	1	4	4	141	2024-04-07 20:27:20	2024-04-07 20:27:20
108	Pierre Jast V	2024-01-13	6668 Westley Locks\nPort Jordane, MD 84987	2004-02-02	male	1	2	29	147	2024-04-07 20:27:20	2024-04-07 20:27:20
109	Mr. Chesley Funk V	2013-01-05	855 Dale Drives Suite 534\nNorth Paulchester, HI 63095-7137	2011-10-27	male	1	4	30	157	2024-04-07 20:27:20	2024-04-07 20:27:20
110	Electa Kassulke II	1979-03-03	98440 Hill Plaza Suite 575\nPort Pearlchester, AK 27325	1976-12-05	male	1	1	8	52	2024-04-07 20:27:20	2024-04-07 20:27:20
111	Natalie Sporer	2019-02-24	89558 Hansen Prairie\nLelandfurt, RI 73381	1993-03-28	male	1	3	46	71	2024-04-07 20:27:20	2024-04-07 20:27:20
112	Rory Collins IV	2012-05-09	32450 Gislason Station\nNorth Fannieberg, CO 07590-5302	1986-06-22	male	1	4	6	8	2024-04-07 20:27:20	2024-04-07 20:27:20
113	Dr. Keira Romaguera	1993-05-26	83435 Farrell Fall Apt. 574\nPort Giovannafurt, TX 63484-1643	2000-07-25	female	1	3	18	144	2024-04-07 20:27:20	2024-04-07 20:27:20
114	Mr. Giovanni Bayer	1994-09-12	7023 Selina Course Apt. 072\nNew Pricemouth, KY 96812-2767	2017-05-31	female	1	1	2	155	2024-04-07 20:27:20	2024-04-07 20:27:20
115	Haskell Kautzer	2001-05-10	77485 Jasper Hollow Apt. 976\nEast Florian, NV 31362-7559	1991-02-15	male	1	3	39	26	2024-04-07 20:27:20	2024-04-07 20:27:20
116	Jayne Hamill	2012-06-08	73876 Iva Forks Suite 847\nPollichfurt, AZ 08054	1986-01-09	male	1	2	36	178	2024-04-07 20:27:20	2024-04-07 20:27:20
117	Dr. Cary Ruecker Sr.	1993-01-13	6585 Sanford Meadows\nNorth Lizzie, GA 85862-8391	2009-09-07	female	1	4	44	12	2024-04-07 20:27:20	2024-04-07 20:27:20
118	Roberta Kohler	1993-03-02	445 Cruickshank Stream Suite 465\nNew Schuyler, KY 99777-8683	1973-02-22	male	1	3	28	147	2024-04-07 20:27:20	2024-04-07 20:27:20
119	Prof. Johnson Gorczany	1977-12-06	9834 Yost Court Suite 957\nLennamouth, ID 78673-1315	2018-04-12	female	1	4	49	171	2024-04-07 20:27:20	2024-04-07 20:27:20
120	Ellis Haley	1981-12-06	3440 Daphnee Station Apt. 312\nSouth Oscarberg, AK 73591	1983-12-14	female	1	2	30	167	2024-04-07 20:27:20	2024-04-07 20:27:20
121	Cloyd Murphy	2014-02-05	39997 Jay Street\nBrannonstad, GA 42368	2016-08-21	female	1	4	7	86	2024-04-07 20:27:20	2024-04-07 20:27:20
122	Kallie Bartell V	1976-04-26	593 Alize Haven\nPort Freedashire, OK 07527	2010-07-19	male	1	3	18	11	2024-04-07 20:27:20	2024-04-07 20:27:20
123	Axel McCullough	1970-01-30	76021 McLaughlin Village\nEast Tommie, CT 24623-1441	1974-10-24	male	1	2	47	166	2024-04-07 20:27:20	2024-04-07 20:27:20
124	Estefania Klein	1998-10-05	2139 Aufderhar Streets Apt. 048\nNorth Rosella, ID 28559	1978-08-13	male	1	3	1	116	2024-04-07 20:27:20	2024-04-07 20:27:20
125	Myrtle Rolfson	1976-12-14	58964 Hand Mission Suite 847\nBillieland, NH 11829-0874	1988-12-27	female	1	2	19	46	2024-04-07 20:27:20	2024-04-07 20:27:20
126	Kody Gislason	2023-07-05	421 Cartwright Coves\nHomenickbury, DC 50554	1972-04-30	female	1	2	7	138	2024-04-07 20:27:20	2024-04-07 20:27:20
127	Dr. Zachery Daniel	2022-09-23	878 Schoen Curve\nLelastad, FL 07738-3464	2007-04-28	female	1	4	47	23	2024-04-07 20:27:20	2024-04-07 20:27:20
128	Freddy Kutch	1970-01-23	231 Fahey Lodge\nLake Jayceeview, LA 29485	2019-04-13	female	1	4	25	162	2024-04-07 20:27:20	2024-04-07 20:27:20
129	Gaston Ritchie	2003-01-29	371 Vernon Union\nSouth Masonshire, OR 09727-5398	2019-12-05	female	1	1	18	194	2024-04-07 20:27:20	2024-04-07 20:27:20
130	Dr. Janae Marvin	1978-08-19	442 Beier Corner Suite 554\nLake Griffin, NM 21047-0164	1989-10-18	male	1	4	38	104	2024-04-07 20:27:20	2024-04-07 20:27:20
131	Mrs. Evie Romaguera	1997-12-16	687 Simonis Lake Apt. 441\nPort Daynemouth, ID 21122-2754	2014-12-01	female	1	2	28	137	2024-04-07 20:27:20	2024-04-07 20:27:20
132	Ms. Viva Maggio V	1995-08-13	1418 Britney Lodge Apt. 472\nMuellerhaven, DE 76186	1984-08-25	female	1	4	28	83	2024-04-07 20:27:20	2024-04-07 20:27:20
133	Mrs. Adriana Hilpert MD	2000-09-20	95720 Dana Ramp\nPadbergview, MT 32610	2023-11-17	male	1	4	31	178	2024-04-07 20:27:20	2024-04-07 20:27:20
134	Stanford Shanahan	1995-01-14	38608 Huel Ridges Apt. 996\nDylanport, MA 55620-1751	1988-06-15	male	1	1	16	173	2024-04-07 20:27:20	2024-04-07 20:27:20
135	Mr. Eriberto Dare PhD	1970-01-22	1256 D'Amore Mews Suite 179\nIsobelfurt, IL 99505-5622	1988-09-07	male	1	4	14	130	2024-04-07 20:27:20	2024-04-07 20:27:20
136	Adonis Prosacco	1982-11-09	2033 Homenick Trafficway\nJackelinefort, AR 65545	1972-10-25	male	1	4	4	54	2024-04-07 20:27:20	2024-04-07 20:27:20
137	Abbey Hamill	2019-11-21	7474 Adriana Curve Suite 177\nFeeneyside, MT 69598-5404	2023-08-17	female	1	2	8	148	2024-04-07 20:27:20	2024-04-07 20:27:20
138	Mr. Walker Schamberger	2006-08-26	3884 Agustin Mountain\nPort Moises, HI 22986-9094	1988-08-07	male	1	4	41	15	2024-04-07 20:27:20	2024-04-07 20:27:20
139	Prof. Kadin Trantow	2006-01-22	156 Bauch Drive\nTillmanchester, NH 78438	1974-06-18	female	1	2	27	68	2024-04-07 20:27:20	2024-04-07 20:27:20
140	Kurtis Leffler	1982-02-18	689 Jaron River\nRobertsport, NJ 45565-0251	2011-06-18	male	1	1	9	128	2024-04-07 20:27:20	2024-04-07 20:27:20
141	Olen Crooks	2008-11-25	55929 Kihn Turnpike\nLake Herman, CT 20784	1972-12-23	female	1	1	33	139	2024-04-07 20:27:20	2024-04-07 20:27:20
142	Miss Danika Veum	2019-09-20	75841 Monique Roads Suite 225\nStrackeberg, SC 74255	2017-06-19	male	1	4	49	3	2024-04-07 20:27:20	2024-04-07 20:27:20
143	Leila Smitham	2023-08-25	7434 Monahan Creek Apt. 022\nDaphneemouth, NH 53858	2008-08-31	male	1	1	21	103	2024-04-07 20:27:20	2024-04-07 20:27:20
144	Patrick Emard	1985-04-27	413 Schimmel Track\nNew Cyriltown, NY 54522	1989-10-07	female	1	3	29	92	2024-04-07 20:27:20	2024-04-07 20:27:20
145	Carmel Kovacek	2009-10-23	777 Schmidt Manor\nNorth Wilfredview, KS 25782	1977-01-16	male	1	3	13	150	2024-04-07 20:27:20	2024-04-07 20:27:20
146	Julia Schneider	1979-09-17	42060 Heathcote Wall Apt. 272\nTeaganburgh, ID 19116	1981-09-22	male	1	3	21	78	2024-04-07 20:27:20	2024-04-07 20:27:20
147	Jazmyne Kuvalis	1973-01-16	37004 Wunsch Squares Suite 748\nPort Kristopherbury, CA 59089-2038	1971-06-02	female	1	3	21	32	2024-04-07 20:27:20	2024-04-07 20:27:20
148	Conrad Hoppe	1971-05-25	7990 Rusty Landing\nPort Meggie, IN 28813-5817	1995-08-04	female	1	2	41	173	2024-04-07 20:27:20	2024-04-07 20:27:20
149	Deshaun Walter	2009-05-12	496 Kihn Courts Suite 996\nWalshstad, MI 91470-5859	1974-10-21	male	1	4	41	181	2024-04-07 20:27:20	2024-04-07 20:27:20
150	Ms. Charity McCullough DVM	1998-03-31	89216 Cartwright Rapid Suite 542\nNorth Dasiastad, DE 83377-7530	2007-05-12	male	1	4	13	49	2024-04-07 20:27:20	2024-04-07 20:27:20
151	Bulah Daniel I	2013-12-29	5546 Keeling Crossroad\nRudolphland, AK 56663	1970-02-11	female	1	3	21	192	2024-04-07 20:27:20	2024-04-07 20:27:20
152	Hermina Bernhard	1987-02-17	9748 Hoppe Flats Apt. 975\nPort Dayanatown, OH 99536-4830	1977-06-06	male	1	3	5	43	2024-04-07 20:27:20	2024-04-07 20:27:20
153	Dr. Elza Ankunding V	1993-09-26	12608 Gottlieb Mills Apt. 503\nMoenshire, AZ 97845	2003-12-06	male	1	4	11	127	2024-04-07 20:27:20	2024-04-07 20:27:20
154	Adolfo Hane	1988-08-12	4960 Hyatt Rapid Suite 798\nEast Wilbertton, CT 20233	2020-09-23	female	1	1	33	121	2024-04-07 20:27:20	2024-04-07 20:27:20
155	Consuelo Mills	1977-04-30	4649 Bruen Mountain Suite 231\nSimeonberg, MO 57092-9617	1997-11-04	female	1	3	7	121	2024-04-07 20:27:20	2024-04-07 20:27:20
156	Lamont Powlowski	1971-06-30	53875 Marks Estate Apt. 901\nPort Nyahfurt, VA 02535-3216	2019-01-12	female	1	2	37	97	2024-04-07 20:27:20	2024-04-07 20:27:20
157	Asia Hyatt	1992-09-22	396 Krajcik Islands\nWatersville, AR 97771	1982-03-14	male	1	4	47	90	2024-04-07 20:27:20	2024-04-07 20:27:20
158	Prof. Murl Farrell	1997-12-15	815 Cole Viaduct\nZiemannfort, TX 25366	2002-11-04	male	1	4	23	152	2024-04-07 20:27:20	2024-04-07 20:27:20
159	Mr. Denis Crona	1990-04-30	4115 Beatty Isle\nPollichville, AL 59474-2914	1986-02-05	female	1	2	39	87	2024-04-07 20:27:20	2024-04-07 20:27:20
160	Prof. Dejah Gislason III	1993-04-30	884 Yundt Square\nWest Floy, NC 87614	2003-06-30	male	1	3	4	1	2024-04-07 20:27:20	2024-04-07 20:27:20
161	Dr. Nelson Eichmann II	1984-01-21	29161 Hansen Loaf\nElviefort, TN 06752-8518	1970-06-03	male	1	2	3	136	2024-04-07 20:27:20	2024-04-07 20:27:20
162	Janiya Berge II	2014-12-02	24385 Heaney Alley Suite 400\nSchuppeton, MA 72295-9710	2014-07-31	male	1	2	23	61	2024-04-07 20:27:20	2024-04-07 20:27:20
163	Cloyd Mayer	2021-02-27	3426 Raynor Road Apt. 224\nWest Marley, NV 24392-7334	1980-10-02	female	1	2	36	63	2024-04-07 20:27:20	2024-04-07 20:27:20
164	Fay Reichert	2018-11-02	10279 Sabryna Lodge\nEast Ashtyntown, SC 70248	2006-12-26	female	1	4	39	106	2024-04-07 20:27:20	2024-04-07 20:27:20
165	Prof. Jett Adams	2012-12-24	3721 Devonte Roads\nLake Michelle, NJ 88793-3448	2011-04-04	female	1	1	4	134	2024-04-07 20:27:20	2024-04-07 20:27:20
166	Miss Chanelle Pfeffer PhD	1984-06-30	8031 Monahan Field Apt. 735\nEast Halmouth, MT 14922	1987-03-22	male	1	1	16	54	2024-04-07 20:27:20	2024-04-07 20:27:20
167	Sandrine Sipes III	2020-05-20	671 Carolina Mews\nSouth Gretchenbury, HI 50579-9808	1981-02-25	female	1	2	16	99	2024-04-07 20:27:20	2024-04-07 20:27:20
168	Armand Carter III	1985-07-19	4445 Emelia Squares Apt. 147\nNew Janniestad, OH 64962	2007-01-12	female	1	2	24	103	2024-04-07 20:27:20	2024-04-07 20:27:20
169	Ignacio McCullough	2006-03-08	5424 Urban Parkway\nWest Arlie, DC 30616	1988-05-02	female	1	3	21	38	2024-04-07 20:27:20	2024-04-07 20:27:20
170	Wilhelm Ankunding V	1994-04-23	35880 Feil Flats Suite 716\nNew Julieberg, DE 92806	2023-06-24	female	1	2	12	140	2024-04-07 20:27:20	2024-04-07 20:27:20
171	Germaine Turner DVM	2007-12-14	499 Greenfelder Land\nWest Herminia, VT 20312-6233	1989-07-07	female	1	4	24	100	2024-04-07 20:27:20	2024-04-07 20:27:20
172	Kip Bogan I	1980-12-25	7814 Kaden Lake\nNew Richard, NM 23742	1987-01-18	female	1	2	3	159	2024-04-07 20:27:20	2024-04-07 20:27:20
173	Stan Prosacco	1990-04-22	7666 Alanna Station\nZellachester, LA 00841	1993-08-03	female	1	1	1	69	2024-04-07 20:27:20	2024-04-07 20:27:20
174	Friedrich Dare MD	1997-12-24	305 Alexie Viaduct\nEast Emie, OR 41542-7105	2014-09-12	male	1	3	28	1	2024-04-07 20:27:20	2024-04-07 20:27:20
175	Clint Feest	2023-07-25	1850 Marks Brooks\nSageland, CT 62008-6195	2021-08-09	male	1	2	22	159	2024-04-07 20:27:20	2024-04-07 20:27:20
176	Margie Dooley V	2006-06-12	261 Elena Points\nEast Serenityshire, AZ 77057	1974-03-13	male	1	4	35	159	2024-04-07 20:27:20	2024-04-07 20:27:20
177	Eladio Lang	2011-10-12	298 Aglae Lane\nNorth Yadiraport, GA 66016-5426	2011-04-21	male	1	2	6	68	2024-04-07 20:27:20	2024-04-07 20:27:20
178	Cecil Cartwright	2016-02-29	12701 Hills Drive\nEmardmouth, NM 57316-2136	1974-12-05	female	1	1	49	67	2024-04-07 20:27:20	2024-04-07 20:27:20
179	Miss Pearline Schamberger	1970-07-07	3732 Conroy Estate\nPort Otis, DC 32136-5802	2014-07-29	female	1	4	21	135	2024-04-07 20:27:20	2024-04-07 20:27:20
180	Jayden Orn	2020-05-16	659 Kovacek Crescent\nLesliefort, AK 78900	2012-07-22	male	1	3	17	142	2024-04-07 20:27:20	2024-04-07 20:27:20
181	Dr. Schuyler Doyle DVM	2001-04-26	336 Baumbach Spur Apt. 584\nAydenhaven, MO 15847-2314	1985-10-16	female	1	1	6	33	2024-04-07 20:27:20	2024-04-07 20:27:20
182	Prof. Dashawn Leuschke DVM	2012-11-05	639 Kerluke Trafficway\nNew Carlos, WI 92144	2001-07-21	female	1	4	48	137	2024-04-07 20:27:20	2024-04-07 20:27:20
183	Willa Wehner DVM	1988-12-27	2535 Koss Shore\nEast Katelinbury, PA 63915-0934	1978-10-01	female	1	2	48	50	2024-04-07 20:27:20	2024-04-07 20:27:20
184	Antonette Hahn	2015-01-28	45801 Candelario Row Suite 944\nSouth Maryjane, FL 52563	2001-04-06	male	1	1	50	127	2024-04-07 20:27:20	2024-04-07 20:27:20
185	Brant Cruickshank V	2023-06-16	764 Stroman Points\nMinervaport, RI 91275	2009-03-30	male	1	2	48	187	2024-04-07 20:27:20	2024-04-07 20:27:20
186	Ms. Helga Cronin	2005-09-27	8712 Trisha Field Apt. 473\nCassinmouth, MS 74725	2010-04-26	male	1	1	1	180	2024-04-07 20:27:20	2024-04-07 20:27:20
187	Dr. Tyrel Welch	2006-10-07	46891 Heathcote Parkway Suite 956\nLucioburgh, NV 16770-4520	2008-12-15	female	1	2	3	13	2024-04-07 20:27:20	2024-04-07 20:27:20
188	Bridgette Hauck	1990-07-24	387 Bednar Cove Apt. 482\nNew Demarioshire, OR 45206-4179	1986-06-30	female	1	3	50	56	2024-04-07 20:27:20	2024-04-07 20:27:20
189	Camilla Welch	2005-04-29	58514 Nettie Spurs Apt. 841\nSouth Rasheed, ND 37224-9095	1985-04-16	male	1	1	29	172	2024-04-07 20:27:20	2024-04-07 20:27:20
190	Winona Simonis	1978-09-17	7218 Wiegand Keys\nSouth Minervamouth, ND 53788-4047	2005-05-20	male	1	4	12	27	2024-04-07 20:27:20	2024-04-07 20:27:20
191	Lolita Anderson Sr.	1988-05-04	60643 Nienow Forks\nGustchester, GA 80534	2016-10-01	female	1	3	2	161	2024-04-07 20:27:20	2024-04-07 20:27:20
192	Mr. Green Schaden MD	2012-07-20	181 Gerhold Hills Suite 579\nZulaufton, OH 37570	1979-06-13	female	1	3	36	78	2024-04-07 20:27:20	2024-04-07 20:27:20
193	Aniyah Zemlak	2003-04-05	50102 Schuster Union\nEast Peyton, WY 86678	1975-11-18	female	1	4	17	141	2024-04-07 20:27:20	2024-04-07 20:27:20
194	Anjali Parisian DDS	2015-04-27	89455 Jakubowski Pine Suite 158\nEast Carleton, TX 60766-2178	2004-11-01	male	1	2	2	6	2024-04-07 20:27:20	2024-04-07 20:27:20
195	Ciara Haag	1985-08-24	9012 Bruen Ford\nPaucekstad, TN 41202	1983-01-18	male	1	1	36	152	2024-04-07 20:27:20	2024-04-07 20:27:20
196	Alivia Lakin	2006-06-20	4261 Alford Neck Suite 514\nPort Hershel, GA 31085-4971	1998-03-25	male	1	1	33	23	2024-04-07 20:27:20	2024-04-07 20:27:20
197	Lemuel Emard	1973-10-21	1550 Dell Camp\nMelodymouth, NH 59011	2015-09-07	male	1	3	36	133	2024-04-07 20:27:20	2024-04-07 20:27:20
198	Norwood Kub	1997-12-07	417 Jena Islands Suite 953\nLake Leonefurt, LA 53094-2612	2023-04-28	female	1	4	14	171	2024-04-07 20:27:20	2024-04-07 20:27:20
199	Ashly Johnson	1987-08-31	3558 Wunsch Mall Apt. 724\nFranciscoland, ID 88928	2005-11-12	female	1	3	37	92	2024-04-07 20:27:20	2024-04-07 20:27:20
200	Perry Witting IV	1981-03-30	8526 Schoen Ford Apt. 791\nWillmsside, OR 09174-3380	2010-09-26	male	1	4	41	183	2024-04-07 20:27:20	2024-04-07 20:27:20
201	Norwood Stiedemann	2013-09-06	931 Marley Coves Suite 580\nHuldaburgh, KY 52220	2015-01-15	male	1	4	49	161	2024-04-07 20:27:20	2024-04-07 20:27:20
202	Mr. Alfred Lakin MD	2011-10-28	646 Williamson Street Suite 448\nEast Burdette, WI 26105	1977-03-12	female	1	2	4	109	2024-04-07 20:27:20	2024-04-07 20:27:20
203	Eliza Smith	1993-12-16	36276 Kiehn Course Suite 849\nSouth Cristobalstad, MN 51438-7522	2020-05-11	female	1	2	46	72	2024-04-07 20:27:20	2024-04-07 20:27:20
204	Cesar Bailey	1984-04-24	729 Bauch Throughway Apt. 536\nHackettshire, OK 42590-3077	1996-05-26	female	1	3	10	139	2024-04-07 20:27:20	2024-04-07 20:27:20
205	Mercedes Howe	2005-11-21	148 Predovic Trafficway\nFisherport, NC 48383-6534	1997-10-14	female	1	1	8	187	2024-04-07 20:27:20	2024-04-07 20:27:20
206	Dax Halvorson	2010-11-05	454 Blanda Underpass Suite 985\nNorth Noelia, MS 74063	2013-04-25	female	1	3	11	138	2024-04-07 20:27:20	2024-04-07 20:27:20
207	Elvie Langworth	2023-05-08	257 Mills Knoll\nKirlinfort, WV 87575	1989-02-27	female	1	4	23	102	2024-04-07 20:27:20	2024-04-07 20:27:20
208	Germaine Macejkovic V	2016-06-19	1858 McClure Plains Suite 985\nSouth Leonor, NJ 87858-3419	2017-12-22	female	1	4	3	121	2024-04-07 20:27:20	2024-04-07 20:27:20
209	Mrs. Aryanna Dooley I	1990-11-20	834 Oda Mall\nGleichnerville, IN 31901	1992-05-24	male	1	2	49	97	2024-04-07 20:27:20	2024-04-07 20:27:20
210	Elroy Feest	1980-07-10	19458 Gwendolyn Radial Suite 750\nLewisstad, TN 74819	1992-07-29	male	1	3	21	17	2024-04-07 20:27:20	2024-04-07 20:27:20
211	Prof. Liliane Carter	2024-01-04	93332 Karli Mission\nIcieberg, KS 10757-5770	1990-07-04	female	1	3	9	102	2024-04-07 20:27:20	2024-04-07 20:27:20
212	Stacey Prohaska DVM	1983-10-15	7021 Irwin Spring Suite 241\nLake Adam, ID 00135-6775	2004-05-06	male	1	4	15	2	2024-04-07 20:27:20	2024-04-07 20:27:20
213	Dr. Wilfred Champlin DDS	2011-01-18	71151 Hermiston Spur Apt. 013\nNew Margarete, IN 48248-5253	2014-06-26	female	1	4	31	33	2024-04-07 20:27:20	2024-04-07 20:27:20
214	Mr. Arch Runte MD	1996-02-19	20232 Marquardt Corner Apt. 368\nWeberton, ID 69030	2013-01-21	female	1	2	8	148	2024-04-07 20:27:20	2024-04-07 20:27:20
215	Mr. Oswald Dicki	2006-08-27	63489 Bayer Dale Apt. 024\nLavadaland, UT 15427-2268	1982-11-03	female	1	4	5	69	2024-04-07 20:27:20	2024-04-07 20:27:20
216	Zoe Lueilwitz	1999-06-23	58138 Forrest Landing Suite 225\nRempelburgh, WY 29022	2015-08-28	male	1	3	30	127	2024-04-07 20:27:20	2024-04-07 20:27:20
217	Kiara Beatty	2022-06-11	23674 Prosacco Ramp\nNew Alaynatown, LA 56787	2000-01-05	male	1	4	20	157	2024-04-07 20:27:20	2024-04-07 20:27:20
218	Dr. Amy Cronin	2008-06-16	513 Sage Ways\nBrannontown, WV 56714	1988-07-05	female	1	3	29	111	2024-04-07 20:27:20	2024-04-07 20:27:20
219	Destini Stehr	2015-04-18	22805 McCullough Tunnel Apt. 381\nMayertshire, NV 05190	1979-03-22	female	1	4	33	54	2024-04-07 20:27:20	2024-04-07 20:27:20
220	Reuben Feeney	2016-10-06	9040 Daren Skyway\nEast Wardhaven, AR 61006-0978	1970-10-07	male	1	4	38	135	2024-04-07 20:27:20	2024-04-07 20:27:20
221	Tamia Jast I	1973-06-17	3939 Julian Mountain Apt. 494\nNorth Sasha, NH 66952	1982-03-26	male	1	2	1	62	2024-04-07 20:27:20	2024-04-07 20:27:20
222	Prof. Baylee Ritchie III	2001-10-04	397 Jude Place Suite 764\nEmardfurt, VT 57206-3656	2017-10-24	female	1	1	49	159	2024-04-07 20:27:20	2024-04-07 20:27:20
223	Mr. Americo Barton II	1992-08-09	263 Russell Bypass\nSpinkatown, FL 38846-1402	2009-02-24	male	1	1	32	30	2024-04-07 20:27:20	2024-04-07 20:27:20
224	Adrian Lemke	2010-10-31	7967 Muriel Flats\nAdellamouth, WI 46316	2009-02-01	female	1	4	20	13	2024-04-07 20:27:20	2024-04-07 20:27:20
225	Tyler Price	2008-04-09	446 Corbin Via\nYosttown, TN 19543-1326	2009-04-30	female	1	1	26	106	2024-04-07 20:27:20	2024-04-07 20:27:20
226	Cleo Graham	2013-12-20	31714 Lehner Fields\nMantemouth, MT 94867-8048	2011-04-15	female	1	4	38	100	2024-04-07 20:27:20	2024-04-07 20:27:20
227	Prof. Laury Hegmann	2017-09-14	814 Frami Ranch Apt. 878\nNicholasstad, SD 45845-8689	1994-09-26	male	1	4	36	96	2024-04-07 20:27:20	2024-04-07 20:27:20
228	Sydney Boehm	2012-02-10	166 Hansen Ferry\nLake Santinofurt, MA 70865	1979-02-08	male	1	4	32	46	2024-04-07 20:27:20	2024-04-07 20:27:20
229	Mr. Andrew Dickinson	2002-07-01	6474 Crist Lakes Apt. 807\nDurganton, OK 47091-9204	1980-07-05	male	1	4	40	66	2024-04-07 20:27:20	2024-04-07 20:27:20
230	Mr. Jaeden Schamberger MD	1993-10-05	99061 Art Port\nIdaview, NV 53921-3869	1996-11-05	male	1	4	23	95	2024-04-07 20:27:20	2024-04-07 20:27:20
231	Calista Botsford	1986-11-12	33399 Veda Harbors Suite 103\nWest Marcia, NE 42896-7770	2014-02-05	male	1	3	2	198	2024-04-07 20:27:20	2024-04-07 20:27:20
232	Ronaldo Rippin	1987-01-09	8419 Little Walks Suite 208\nMorissetteborough, SC 10759	1980-07-28	male	1	4	21	77	2024-04-07 20:27:20	2024-04-07 20:27:20
233	Reilly Langworth DVM	1986-11-29	15951 O'Connell Glen\nGottliebview, NY 76355	1995-10-01	female	1	4	33	84	2024-04-07 20:27:21	2024-04-07 20:27:21
234	Agnes Beatty	1979-11-11	643 Ramona Station\nJoyceport, AL 82421-5615	1974-04-28	female	1	1	28	163	2024-04-07 20:27:21	2024-04-07 20:27:21
235	Santiago Flatley I	1994-10-15	67833 Brody Meadow\nSouth Kirstin, MI 22363-7178	2008-10-12	male	1	2	50	107	2024-04-07 20:27:21	2024-04-07 20:27:21
236	Sean Quitzon III	1996-11-30	45308 Marisol Ways Apt. 308\nLake Helga, UT 03613	1980-01-14	female	1	3	8	187	2024-04-07 20:27:21	2024-04-07 20:27:21
237	Duncan Streich	2001-05-27	2152 Kilback Islands Suite 525\nWeimannchester, CA 90629	1972-03-26	male	1	3	24	73	2024-04-07 20:27:21	2024-04-07 20:27:21
238	Lempi Schoen	2020-02-28	461 Kuphal Overpass Apt. 002\nNew Jewel, VA 16983	2018-11-12	male	1	1	47	132	2024-04-07 20:27:21	2024-04-07 20:27:21
239	Josie Metz	1979-06-05	12895 Jordi Square\nCandidaview, VT 66297	1973-04-14	male	1	3	23	165	2024-04-07 20:27:21	2024-04-07 20:27:21
240	Ophelia Hayes	1981-07-06	275 Feil Rapids\nHortenseport, WY 80393	2003-08-24	male	1	4	19	6	2024-04-07 20:27:21	2024-04-07 20:27:21
241	Nyasia Erdman I	1974-03-13	40943 Brigitte Haven Suite 643\nNew Jamarcusberg, AK 96337	1990-10-27	female	1	4	21	128	2024-04-07 20:27:21	2024-04-07 20:27:21
242	Prof. Eden Mayert IV	2015-05-26	219 Delpha Greens\nFloridaland, NH 06263-7231	2014-01-08	female	1	3	21	3	2024-04-07 20:27:21	2024-04-07 20:27:21
243	Bertram Corwin	1981-10-19	425 Rachel Trail Apt. 760\nErnsershire, IN 46691-2099	1975-03-07	female	1	4	9	70	2024-04-07 20:27:21	2024-04-07 20:27:21
244	Issac Raynor	2021-03-04	93263 Kemmer Rue Apt. 077\nNew Jolie, AL 05318-8142	2017-09-20	male	1	2	42	114	2024-04-07 20:27:21	2024-04-07 20:27:21
245	Mr. Devonte Howell	1990-03-24	18676 Roderick Brook Apt. 639\nWaylonbury, TX 71348-6372	1978-07-09	female	1	3	7	14	2024-04-07 20:27:21	2024-04-07 20:27:21
246	Leif Purdy II	1997-03-30	454 Jonathon Pike Suite 428\nEast Federicoborough, WV 44667-3029	1993-11-06	female	1	2	43	75	2024-04-07 20:27:21	2024-04-07 20:27:21
247	Lucio Doyle	2002-02-05	67812 Bettie Ports Apt. 703\nEast Leland, ND 26781	1996-06-01	male	1	3	49	174	2024-04-07 20:27:21	2024-04-07 20:27:21
248	Darlene Schroeder	1972-05-30	924 Gorczany Streets\nFreedachester, MT 93760-3401	2017-06-01	female	1	2	37	100	2024-04-07 20:27:21	2024-04-07 20:27:21
249	Prof. Gustave Willms	1982-01-12	750 McClure Rue\nWest Roselynville, ND 51954-8951	2006-10-03	female	1	4	39	171	2024-04-07 20:27:21	2024-04-07 20:27:21
250	Bernhard Schoen PhD	2001-10-15	771 Bashirian Ranch Suite 909\nNew Clotilde, MT 59800	1974-08-23	male	1	1	9	21	2024-04-07 20:27:21	2024-04-07 20:27:21
251	Hayley Brekke	2007-10-30	918 Ebert Pike Suite 765\nHirammouth, ME 81226-3875	1974-12-27	female	1	1	23	170	2024-04-07 20:27:21	2024-04-07 20:27:21
252	Faustino Harris	1979-07-04	222 Rau Course Suite 395\nNorth Dakotaland, MN 32021	2018-12-26	male	1	3	48	140	2024-04-07 20:27:21	2024-04-07 20:27:21
253	Dr. Jedidiah Lueilwitz	1978-01-16	49402 Peggie Via Apt. 897\nRolfsonhaven, NM 81824	1974-05-24	female	1	3	32	116	2024-04-07 20:27:21	2024-04-07 20:27:21
254	Romaine Bauch II	1998-02-28	32868 Wisozk Brooks Suite 850\nWest Lewisport, WI 00178-6555	1972-08-09	male	1	2	35	46	2024-04-07 20:27:21	2024-04-07 20:27:21
255	Prof. Angelina Mann PhD	2004-07-06	9409 Stefanie Estates\nRaymundoshire, AL 19175	1986-10-08	male	1	4	15	106	2024-04-07 20:27:21	2024-04-07 20:27:21
256	Ms. Katrine Hirthe	1987-06-30	9673 Schamberger Ranch Apt. 470\nJaniyamouth, TX 87876	1973-09-21	male	1	1	28	88	2024-04-07 20:27:21	2024-04-07 20:27:21
257	Chauncey Morissette	1996-08-29	2853 Little Parks\nNew Faye, CT 19001-2870	1971-09-07	male	1	2	1	140	2024-04-07 20:27:21	2024-04-07 20:27:21
258	Dr. Eladio Berge	1982-08-19	9246 Everette Crest Suite 410\nNew Gerardo, RI 43893-6002	1970-02-13	male	1	4	13	122	2024-04-07 20:27:21	2024-04-07 20:27:21
259	Dr. Camylle Stark III	1986-08-06	5665 Kulas Stream\nLake Joanhaven, CA 64830	1979-08-25	male	1	3	45	77	2024-04-07 20:27:21	2024-04-07 20:27:21
260	Prof. Dangelo Cormier MD	2023-08-05	80819 Feil Land Suite 649\nSouth Kale, ME 22640-6005	2010-01-01	male	1	2	29	120	2024-04-07 20:27:21	2024-04-07 20:27:21
261	Ellen Pacocha	1988-07-29	57308 Elvera Brook\nNorth Eldaside, LA 06286-9371	1998-07-31	female	1	1	26	114	2024-04-07 20:27:21	2024-04-07 20:27:21
262	Mr. Dagmar Gulgowski V	1995-10-26	74183 Kihn Pine\nWinstonborough, IL 62736	2009-12-26	male	1	1	9	80	2024-04-07 20:27:21	2024-04-07 20:27:21
263	Prof. Miguel Padberg IV	2012-10-02	325 Hodkiewicz Flats\nHellerville, WA 11815	1982-01-27	male	1	1	38	9	2024-04-07 20:27:21	2024-04-07 20:27:21
264	Prof. Geovany DuBuque IV	1983-05-09	47558 Daniella Island Suite 546\nPort Joyceland, ND 12672	1972-06-04	male	1	2	2	36	2024-04-07 20:27:21	2024-04-07 20:27:21
265	Miss Antonietta Raynor V	1978-01-07	2386 Mayert Road Apt. 918\nNorth Heavenfurt, CA 57004-1837	1971-02-20	male	1	3	5	84	2024-04-07 20:27:21	2024-04-07 20:27:21
266	Prof. Dell Greenholt DDS	2001-09-05	8563 Lockman Crossroad\nDarenborough, TN 69885	1989-07-29	female	1	3	44	165	2024-04-07 20:27:21	2024-04-07 20:27:21
267	Letha Russel	1997-06-12	173 Verner Parkway\nBettefurt, RI 67549	2002-12-08	female	1	4	42	4	2024-04-07 20:27:21	2024-04-07 20:27:21
268	Frederique Hoeger	1987-02-22	569 Jerde Circles\nSouth Foster, AL 45163	2020-05-12	female	1	2	18	79	2024-04-07 20:27:21	2024-04-07 20:27:21
269	Leilani Friesen	2017-07-17	573 Rhea Islands\nEast Agnes, CA 93883-3047	2007-01-31	female	1	2	43	198	2024-04-07 20:27:21	2024-04-07 20:27:21
270	Davin Stroman	1990-09-10	449 Hettinger Trail\nPaytonport, NV 36071-7764	2012-12-10	female	1	4	49	104	2024-04-07 20:27:21	2024-04-07 20:27:21
271	Gaetano Funk	1994-02-02	2701 Juliet Mission Apt. 420\nEast Katherynstad, AR 62803	2020-07-11	female	1	1	4	110	2024-04-07 20:27:21	2024-04-07 20:27:21
272	Kyleigh Mayert Jr.	2018-09-10	613 Beatty Mills\nWest Madonna, IL 65232	2021-12-05	male	1	3	14	158	2024-04-07 20:27:21	2024-04-07 20:27:21
273	Leonard Barton	2019-10-26	880 Issac Station\nLake Savannahborough, FL 94537	1992-02-28	male	1	3	26	72	2024-04-07 20:27:21	2024-04-07 20:27:21
274	Dr. Lukas Hudson Jr.	1978-03-06	75635 Emie Forest\nEast Cassandraborough, NY 52122-6310	1984-08-01	male	1	4	29	51	2024-04-07 20:27:21	2024-04-07 20:27:21
275	Dr. Augustus Schulist IV	2017-01-24	612 Deckow Bypass\nSouth Zaria, OH 77891-0926	1975-12-23	female	1	1	39	13	2024-04-07 20:27:21	2024-04-07 20:27:21
276	Dr. Roslyn Purdy Jr.	2007-11-06	5492 Ernie Parkway\nSouth Kentonshire, DC 71884-5860	2014-07-10	male	1	3	38	15	2024-04-07 20:27:21	2024-04-07 20:27:21
277	Prof. Harold Leffler DDS	1996-04-19	25127 Christy Crest Apt. 466\nChesleymouth, WY 82218	2000-03-04	female	1	4	2	110	2024-04-07 20:27:21	2024-04-07 20:27:21
278	Joy Hudson	2008-12-09	601 Savannah Rapid\nSamsonport, FL 77352-8011	1981-06-24	female	1	3	34	27	2024-04-07 20:27:21	2024-04-07 20:27:21
279	Dr. Haley Luettgen MD	2013-12-10	54402 Cyril Roads Suite 466\nHalvorsonhaven, TN 23056-4387	1998-01-03	female	1	4	39	130	2024-04-07 20:27:21	2024-04-07 20:27:21
280	Meagan Sawayn II	2011-02-05	927 Zieme Park\nLake Aylin, RI 75991	1985-10-30	male	1	2	38	85	2024-04-07 20:27:21	2024-04-07 20:27:21
281	Mr. Evans Walsh IV	2015-02-09	25279 Mervin Circle Apt. 116\nNew Lysannehaven, NV 32152-5306	2012-10-21	male	1	3	34	200	2024-04-07 20:27:21	2024-04-07 20:27:21
282	Nathanial Simonis	1973-12-25	2347 Marlene Trail\nAlenestad, CO 35646-1588	2018-05-12	male	1	4	39	15	2024-04-07 20:27:21	2024-04-07 20:27:21
283	Prof. Cleo Oberbrunner PhD	1993-09-24	626 Vandervort Shoals Apt. 913\nSouth Cristobalstad, ND 14883	1971-04-19	male	1	4	13	43	2024-04-07 20:27:21	2024-04-07 20:27:21
284	Gabriella Rogahn	1976-06-27	55780 Ellen Manors\nLake Hayleyland, AR 63557-6061	1993-11-02	female	1	3	21	92	2024-04-07 20:27:21	2024-04-07 20:27:21
285	Dr. Lamar Goyette V	2005-12-04	5623 Jefferey Hills\nFritschburgh, MS 41624	2015-11-24	female	1	4	29	200	2024-04-07 20:27:21	2024-04-07 20:27:21
286	Dr. Alexane Bechtelar	2011-10-07	484 Lubowitz Trafficway\nHammesville, ME 04241-8571	1980-10-01	female	1	4	10	138	2024-04-07 20:27:21	2024-04-07 20:27:21
287	Ms. Vida Hyatt Jr.	1977-02-02	994 Rashawn Ferry Suite 182\nWeberchester, OK 70632-7918	1975-01-08	female	1	1	29	145	2024-04-07 20:27:21	2024-04-07 20:27:21
288	Dr. Buddy Donnelly DVM	1992-02-14	7912 Berge Squares Suite 277\nDemarcusbury, WI 14338-0679	2012-03-06	female	1	2	18	41	2024-04-07 20:27:21	2024-04-07 20:27:21
289	Van Kovacek	1987-05-11	10127 Rae Ford\nLacyport, NE 63638-9335	2008-03-22	male	1	1	16	107	2024-04-07 20:27:21	2024-04-07 20:27:21
290	Prof. Clinton Heller DDS	1977-11-21	904 Windler Ports\nMillsberg, IL 64533	1984-06-07	female	1	2	35	162	2024-04-07 20:27:21	2024-04-07 20:27:21
291	Jamel Connelly	2020-02-15	84629 Rowena Course\nMullerchester, PA 47753-1264	1980-02-29	male	1	4	8	194	2024-04-07 20:27:21	2024-04-07 20:27:21
292	Mrs. Shany Schneider	1999-05-11	4363 Dessie Freeway\nRoobtown, SC 33954	2015-03-16	male	1	3	14	155	2024-04-07 20:27:21	2024-04-07 20:27:21
293	Ewald Medhurst	1979-01-12	1140 Aryanna Spring Apt. 701\nNorth Milliehaven, RI 22753	2007-02-24	male	1	1	6	60	2024-04-07 20:27:21	2024-04-07 20:27:21
294	Raymond Brown	2008-05-30	6310 Kade Circles Suite 506\nMeredithside, AL 58778	1993-08-08	male	1	1	31	29	2024-04-07 20:27:21	2024-04-07 20:27:21
295	Sydnee Kassulke	1992-02-14	9194 Selina Points Apt. 110\nGilbertoborough, MT 33596	2009-10-05	male	1	4	28	60	2024-04-07 20:27:21	2024-04-07 20:27:21
296	Prof. Edwin Jaskolski	1995-06-27	997 Sandrine Valley\nStantonhaven, GA 57901-0447	2014-03-26	female	1	2	16	165	2024-04-07 20:27:21	2024-04-07 20:27:21
297	Dr. Osborne Goldner I	1992-04-27	192 Jesse Haven\nO'Reillyberg, AK 97630	2004-06-25	male	1	1	21	47	2024-04-07 20:27:21	2024-04-07 20:27:21
298	Dr. Therese Schneider	2019-02-13	505 Kallie Key\nLake Bo, KS 22520	2006-10-30	female	1	4	32	118	2024-04-07 20:27:21	2024-04-07 20:27:21
299	Karlie O'Connell	2007-02-01	70820 Schumm Ports\nKalebview, NV 00663	1998-03-11	female	1	1	25	36	2024-04-07 20:27:21	2024-04-07 20:27:21
300	Chauncey Connelly	1975-06-16	641 Marielle Inlet\nPort Websterburgh, MD 17163-1387	2018-08-09	female	1	2	46	59	2024-04-07 20:27:21	2024-04-07 20:27:21
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, first_name, second_name, third_name, forth_name, phone, address, date_of_birth, date_of_hiring, learning, reiligon, postion, email_verified_at, email, "isAdmin", login_allow, password, remember_token, created_at, updated_at) FROM stdin;
1	Oleta	Cormier	Sister	Tremblay	\N	9799 Wilson Fork\nEast Cordia, WA 90479-6080	1973-10-12	\N	High School	\N	\N	1979-07-07 20:41:56	a@a.com	t	t	$2y$12$5Uq4xYMI5uZgq2ZPIUPlTuU/76H5HF.ws9EsbCqpcrOKr90o9ygfq	\N	2024-04-07 20:27:16	2024-04-07 20:27:16
\.


--
-- Name: backups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.backups_id_seq', 1, false);


--
-- Name: class_rooms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.class_rooms_id_seq', 50, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: grades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.grades_id_seq', 5, true);


--
-- Name: images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.images_id_seq', 100, true);


--
-- Name: ltu_contributors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ltu_contributors_id_seq', 1, false);


--
-- Name: ltu_invites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ltu_invites_id_seq', 1, false);


--
-- Name: ltu_languages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ltu_languages_id_seq', 1, false);


--
-- Name: ltu_phrases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ltu_phrases_id_seq', 1, false);


--
-- Name: ltu_translation_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ltu_translation_files_id_seq', 1, false);


--
-- Name: ltu_translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ltu_translations_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 21, true);


--
-- Name: parents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parents_id_seq', 200, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, false);


--
-- Name: pulse_aggregates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pulse_aggregates_id_seq', 3836, true);


--
-- Name: pulse_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pulse_entries_id_seq', 710, true);


--
-- Name: pulse_values_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pulse_values_id_seq', 1, false);


--
-- Name: school_fees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.school_fees_id_seq', 12, true);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.settings_id_seq', 1, true);


--
-- Name: students_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.students_id_seq', 300, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: class_rooms class_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_rooms
    ADD CONSTRAINT class_rooms_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: grades grades_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_pkey PRIMARY KEY (id);


--
-- Name: images images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- Name: ltu_contributors ltu_contributors_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_contributors
    ADD CONSTRAINT ltu_contributors_email_unique UNIQUE (email);


--
-- Name: ltu_contributors ltu_contributors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_contributors
    ADD CONSTRAINT ltu_contributors_pkey PRIMARY KEY (id);


--
-- Name: ltu_invites ltu_invites_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_invites
    ADD CONSTRAINT ltu_invites_email_unique UNIQUE (email);


--
-- Name: ltu_invites ltu_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_invites
    ADD CONSTRAINT ltu_invites_pkey PRIMARY KEY (id);


--
-- Name: ltu_invites ltu_invites_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_invites
    ADD CONSTRAINT ltu_invites_token_unique UNIQUE (token);


--
-- Name: ltu_languages ltu_languages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_languages
    ADD CONSTRAINT ltu_languages_pkey PRIMARY KEY (id);


--
-- Name: ltu_phrases ltu_phrases_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_phrases
    ADD CONSTRAINT ltu_phrases_pkey PRIMARY KEY (id);


--
-- Name: ltu_translation_files ltu_translation_files_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_translation_files
    ADD CONSTRAINT ltu_translation_files_pkey PRIMARY KEY (id);


--
-- Name: ltu_translations ltu_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_translations
    ADD CONSTRAINT ltu_translations_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: parents parents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parents
    ADD CONSTRAINT parents_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: pulse_aggregates pulse_aggregates_bucket_period_type_aggregate_key_hash_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pulse_aggregates
    ADD CONSTRAINT pulse_aggregates_bucket_period_type_aggregate_key_hash_unique UNIQUE (bucket, period, type, aggregate, key_hash);


--
-- Name: pulse_aggregates pulse_aggregates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pulse_aggregates
    ADD CONSTRAINT pulse_aggregates_pkey PRIMARY KEY (id);


--
-- Name: pulse_entries pulse_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pulse_entries
    ADD CONSTRAINT pulse_entries_pkey PRIMARY KEY (id);


--
-- Name: pulse_values pulse_values_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pulse_values
    ADD CONSTRAINT pulse_values_pkey PRIMARY KEY (id);


--
-- Name: pulse_values pulse_values_type_key_hash_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pulse_values
    ADD CONSTRAINT pulse_values_type_key_hash_unique UNIQUE (type, key_hash);


--
-- Name: school_fees school_fees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.school_fees
    ADD CONSTRAINT school_fees_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ltu_languages_code_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ltu_languages_code_index ON public.ltu_languages USING btree (code);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: pulse_aggregates_period_bucket_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pulse_aggregates_period_bucket_index ON public.pulse_aggregates USING btree (period, bucket);


--
-- Name: pulse_aggregates_period_type_aggregate_bucket_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pulse_aggregates_period_type_aggregate_bucket_index ON public.pulse_aggregates USING btree (period, type, aggregate, bucket);


--
-- Name: pulse_aggregates_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pulse_aggregates_type_index ON public.pulse_aggregates USING btree (type);


--
-- Name: pulse_entries_key_hash_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pulse_entries_key_hash_index ON public.pulse_entries USING btree (key_hash);


--
-- Name: pulse_entries_timestamp_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pulse_entries_timestamp_index ON public.pulse_entries USING btree ("timestamp");


--
-- Name: pulse_entries_timestamp_type_key_hash_value_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pulse_entries_timestamp_type_key_hash_value_index ON public.pulse_entries USING btree ("timestamp", type, key_hash, value);


--
-- Name: pulse_entries_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pulse_entries_type_index ON public.pulse_entries USING btree (type);


--
-- Name: pulse_values_timestamp_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pulse_values_timestamp_index ON public.pulse_values USING btree ("timestamp");


--
-- Name: pulse_values_type_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pulse_values_type_index ON public.pulse_values USING btree (type);


--
-- Name: class_rooms class_rooms_grade_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_rooms
    ADD CONSTRAINT class_rooms_grade_id_foreign FOREIGN KEY (grade_id) REFERENCES public.grades(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: class_rooms class_rooms_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_rooms
    ADD CONSTRAINT class_rooms_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: grades grades_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grades
    ADD CONSTRAINT grades_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ltu_phrases ltu_phrases_phrase_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_phrases
    ADD CONSTRAINT ltu_phrases_phrase_id_foreign FOREIGN KEY (phrase_id) REFERENCES public.ltu_phrases(id) ON DELETE CASCADE;


--
-- Name: ltu_phrases ltu_phrases_translation_file_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_phrases
    ADD CONSTRAINT ltu_phrases_translation_file_id_foreign FOREIGN KEY (translation_file_id) REFERENCES public.ltu_translation_files(id) ON DELETE CASCADE;


--
-- Name: ltu_phrases ltu_phrases_translation_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ltu_phrases
    ADD CONSTRAINT ltu_phrases_translation_id_foreign FOREIGN KEY (translation_id) REFERENCES public.ltu_translations(id) ON DELETE CASCADE;


--
-- Name: parents parents_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parents
    ADD CONSTRAINT parents_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: school_fees school_fees_classroom_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.school_fees
    ADD CONSTRAINT school_fees_classroom_id_foreign FOREIGN KEY (classroom_id) REFERENCES public.class_rooms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: school_fees school_fees_grade_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.school_fees
    ADD CONSTRAINT school_fees_grade_id_foreign FOREIGN KEY (grade_id) REFERENCES public.grades(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: school_fees school_fees_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.school_fees
    ADD CONSTRAINT school_fees_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: students students_classroom_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_classroom_id_foreign FOREIGN KEY (classroom_id) REFERENCES public.class_rooms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: students students_grade_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_grade_id_foreign FOREIGN KEY (grade_id) REFERENCES public.grades(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: students students_parent_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_parent_id_foreign FOREIGN KEY (parent_id) REFERENCES public.parents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: students students_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

